<?php
/*
        _               _                  _____        _     _ _     _   _   _                         
       (_)             | |                | ____|      | |   (_) |   | | | | | |                        
  _ __  _  ___ ___  ___| |_ _ __ __ _ _ __| |__     ___| |__  _| | __| | | |_| |__   ___ _ __ ___   ___ 
 | '_ \| |/ __/ _ \/ __| __| '__/ _` | '_ \___ \   / __| '_ \| | |/ _` | | __| '_ \ / _ \ '_ ` _ \ / _ \
 | |_) | | (_| (_) \__ \ |_| | | (_| | |_) |__) | | (__| | | | | | (_| | | |_| | | |  __/ | | | | |  __/
 | .__/|_|\___\___/|___/\__|_|  \__,_| .__/____/   \___|_| |_|_|_|\__,_|  \__|_| |_|\___|_| |_| |_|\___|
 | |                                 | |                                                                
 |_|                                 |_|                                                                

                                                       
*************************************** WELCOME TO PICOSTRAP ***************************************

********************* THE BEST WAY TO EXPERIENCE SASS, BOOTSTRAP AND WORDPRESS *********************

    PLEASE WATCH THE VIDEOS FOR BEST RESULTS:
    https://www.youtube.com/playlist?list=PLtyHhWhkgYU8i11wu-5KJDBfA9C-D4Bfl

*/

// INCLUDE HELPER FILES FOR BETTER CODE ORGANIZATION
require_once get_stylesheet_directory() . '/inc/performance-optimizations.php';
require_once get_stylesheet_directory() . '/inc/acf-helpers.php';
require_once get_stylesheet_directory() . '/inc/url-helpers.php';
require_once get_stylesheet_directory() . '/inc/custom-queries.php';

// DE-ENQUEUE PARENT THEME BOOTSTRAP JS BUNDLE
add_action( 'wp_print_scripts', function(){
    wp_dequeue_script( 'bootstrap5' );
    //wp_dequeue_script( 'dark-mode-switch' );  //optionally
}, 100 );

// ENQUEUE THE BOOTSTRAP JS BUNDLE (AND EVENTUALLY MORE LIBS) FROM THE CHILD THEME DIRECTORY
add_action( 'wp_enqueue_scripts', function() {
    //enqueue js in footer, defer
    wp_enqueue_script( 'bootstrap5-childtheme', get_stylesheet_directory_uri() . "/js/bootstrap.bundle.min.js", array(), null, array('strategy' => 'defer', 'in_footer' => true)  );
    
    //optional: example of how to globally load js files eg  lottie player
    //wp_enqueue_script( 'lottie-player', 'https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js', array(), null, array('strategy' => 'defer', 'in_footer' => true)  );
}, 101);

// HACK HERE: ENQUEUE YOUR CUSTOM JS FILES, IF NEEDED 
add_action( 'wp_enqueue_scripts', function() {	   
    
    //UNCOMMENT next row to include the js/custom.js file globally
    wp_enqueue_script('custom', get_stylesheet_directory_uri() . '/js/custom.js', array(/* 'jquery' */), null, array('strategy' => 'defer', 'in_footer' => true) ); 

    //UNCOMMENT next 3 rows to load the js file only on one page
    //if (is_page('mypageslug')) {
    //    wp_enqueue_script('custom', get_stylesheet_directory_uri() . '/js/custom.js', array(/* 'jquery' */), null, array('strategy' => 'defer', 'in_footer' => true) ); 
    //}  
    
    // Enqueue centralized Splide initialization
    wp_enqueue_script('splide-init', get_stylesheet_directory_uri() . '/js/splide-init.js', array('splide-js'), null, array('strategy' => 'defer', 'in_footer' => true) );

}, 102);

function add_splide_slider_assets() {
    wp_enqueue_style('splide-css', 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.3/dist/css/splide.min.css');
    wp_enqueue_script('splide-js', 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.3/dist/js/splide.min.js', [], null, true);
}
add_action('wp_enqueue_scripts', 'add_splide_slider_assets');

// OPTIONAL: ADD MORE NAV MENUS
//register_nav_menus( array( 'third' => __( 'Third Menu', 'picostrap' ), 'fourth' => __( 'Fourth Menu', 'picostrap' ), 'fifth' => __( 'Fifth Menu', 'picostrap' ), ) );
// THEN USE SHORTCODE:  [lc_nav_menu theme_location="third" container_class="" container_id="" menu_class="navbar-nav"]


// CHECK PARENT THEME VERSION
add_action( 'admin_notices', function  () {
    if( (pico_get_parent_theme_version())>=3.0) return; 
	$message = __( 'This Child Theme requires at least Picostrap Version 3.0.0  in order to work properly. Please update the parent theme.', 'picostrap' );
	printf( '<div class="%1$s"><h1>%2$s</h1></div>', esc_attr( 'notice notice-error' ), esc_html( $message ) );
} );

// FOR SECURITY: DISABLE APPLICATION PASSWORDS. Remove if needed (unlikely!)
add_filter( 'wp_is_application_passwords_available', '__return_false' );

function kill_theme_wpse_188906($themes) {
  unset($themes['picostrap5']);
  return $themes;
}
add_filter('wp_prepare_themes_for_js','kill_theme_wpse_188906');

// SVG SUPPORT //
function add_file_types_to_uploads($file_types){
$new_filetypes = array();
$new_filetypes['svg'] = 'image/svg+xml';
$new_filetypes['svgz'] = 'image/svg+xml';
$file_types = array_merge($file_types, $new_filetypes );
return $file_types;
}
add_action('upload_mimes', 'add_file_types_to_uploads');



/*
*
* 	Custom post type PROGETTO
*
*/

function progetto() {

	$labels = array(
		'name'                  => _x( 'Progetti', 'Post Type General Name', 'pdr' ),
		'singular_name'         => _x( 'Progetto', 'Post Type Singular Name', 'pdr' ),
		'menu_name'             => __( 'Progetti', 'pdr' ),
		'name_admin_bar'        => __( 'Progetti', 'pdr' ),
		'archives'              => __( 'Archivio progetti', 'pdr' ),
		'attributes'            => __( 'Attributi progetto', 'pdr' ),
		'parent_item_colon'     => __( 'Progetto madre:', 'pdr' ),
		'all_items'             => __( 'Tutti i progetti', 'pdr' ),
		'add_new_item'          => __( 'Aggiungi nuovo progetto', 'pdr' ),
		'add_new'               => __( 'Aggiungi nuovo', 'pdr' ),
		'new_item'              => __( 'Nuovo progetto', 'pdr' ),
		'edit_item'             => __( 'Modifica progetto', 'pdr' ),
		'update_item'           => __( 'Aggiorna progetto', 'pdr' ),
		'view_item'             => __( 'Vedi progetto', 'pdr' ),
		'view_items'            => __( 'Vedi progetti', 'pdr' ),
		'search_items'          => __( 'Cerca progetto', 'pdr' ),
		'not_found'             => __( 'Non trovato', 'pdr' ),
		'not_found_in_trash'    => __( 'Non trovato nel cestino', 'pdr' ),
		'featured_image'        => __( 'Immagine in evidenza', 'pdr' ),
		'set_featured_image'    => __( 'Imposta immagine in evidenza', 'pdr' ),
		'remove_featured_image' => __( 'Rimuovi immagine in evidenza', 'pdr' ),
		'use_featured_image'    => __( 'Usa come immagine in evidenza', 'pdr' ),
		'insert_into_item'      => __( 'Inserisci dentro progetto', 'pdr' ),
		'uploaded_to_this_item' => __( 'Caricato inprogetto', 'pdr' ),
		'items_list'            => __( 'Lista progetti', 'pdr' ),
		'items_list_navigation' => __( 'Navigazione lista progetti', 'pdr' ),
		'filter_items_list'     => __( 'Filtra lista progetti', 'pdr' ),
	);
	$rewrite = array(
        'slug' => 'progetti',
        'with_front' => false,
    );

	$args = array(
		'label'                 => __( 'Progetto', 'pdr' ),
		'description'           => __( 'Progetti Pdr', 'pdr' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'taxonomies'            => array( 'categoria_progetto' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive' => true,
        'rewrite' => $rewrite,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
		'show_in_rest'          => true,
	);
	register_post_type( 'progetto', $args );

}
add_action( 'init', 'progetto', 0 );


/*
*
* 	Custom taxonomy TAG IMMAGINI
*
*/
function register_pdr_image_tag_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Tag immagini', 'Taxonomy General Name', 'pdr' ),
		'singular_name'              => _x( 'Tag immagini', 'Taxonomy Singular Name', 'pdr' ),
		'menu_name'                  => __( 'Tag immagine', 'pdr' ),
		'all_items'                  => __( 'All Items', 'pdr' ),
		'parent_item'                => __( 'Parent Item', 'pdr' ),
		'parent_item_colon'          => __( 'Parent Item:', 'pdr' ),
		'new_item_name'              => __( 'New Item Name', 'pdr' ),
		'add_new_item'               => __( 'Add New Item', 'pdr' ),
		'edit_item'                  => __( 'Edit Item', 'pdr' ),
		'update_item'                => __( 'Update Item', 'pdr' ),
		'view_item'                  => __( 'View Item', 'pdr' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'pdr' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'pdr' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'pdr' ),
		'popular_items'              => __( 'Popular Items', 'pdr' ),
		'search_items'               => __( 'Search Items', 'pdr' ),
		'not_found'                  => __( 'Not Found', 'pdr' ),
		'no_terms'                   => __( 'No items', 'pdr' ),
		'items_list'                 => __( 'Items list', 'pdr' ),
		'items_list_navigation'      => __( 'Items list navigation', 'pdr' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'pdr_image_tag', array( 'attachment' ), $args );

}
add_action( 'init', 'register_pdr_image_tag_taxonomy', 0 );


/*
*
* 	Custom taxonomy CATEGORIA PROGETTI
*
*/
function categorie_progetti() {

	$labels = array(
		'name'                       => _x( 'Categorie progetto', 'Taxonomy General Name', 'pdr' ),
		'singular_name'              => _x( 'Categoria progetto', 'Taxonomy Singular Name', 'pdr' ),
		'menu_name'                  => __( 'Categoria progetto', 'pdr' ),
		'all_items'                  => __( 'All Items', 'pdr' ),
		'parent_item'                => __( 'Parent Item', 'pdr' ),
		'parent_item_colon'          => __( 'Parent Item:', 'pdr' ),
		'new_item_name'              => __( 'New Item Name', 'pdr' ),
		'add_new_item'               => __( 'Add New Item', 'pdr' ),
		'edit_item'                  => __( 'Edit Item', 'pdr' ),
		'update_item'                => __( 'Update Item', 'pdr' ),
		'view_item'                  => __( 'View Item', 'pdr' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'pdr' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'pdr' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'pdr' ),
		'popular_items'              => __( 'Popular Items', 'pdr' ),
		'search_items'               => __( 'Search Items', 'pdr' ),
		'not_found'                  => __( 'Not Found', 'pdr' ),
		'no_terms'                   => __( 'No items', 'pdr' ),
		'items_list'                 => __( 'Items list', 'pdr' ),
		'items_list_navigation'      => __( 'Items list navigation', 'pdr' ),
	);
	$rewrite = array(
		'slug'                       => 'categoria-progetto',
		'with_front'                 => true,
		'hierarchical'               => true,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'                    => $rewrite,
	);
	register_taxonomy( 'categoria_progetto', array( 'progetto' ), $args );

}
add_action( 'init', 'categorie_progetti', 0 );



/*
*
* 	Custom taxonomy TAG PROGETTI
*
*/
function tag_progetti() {

	$labels = array(
		'name'                       => _x( 'Tag progetto', 'Taxonomy General Name', 'pdr' ),
		'singular_name'              => _x( 'Tag progetto', 'Taxonomy Singular Name', 'pdr' ),
		'menu_name'                  => __( 'Tag progetto', 'pdr' ),
		'all_items'                  => __( 'All Items', 'pdr' ),
		'parent_item'                => __( 'Parent Item', 'pdr' ),
		'parent_item_colon'          => __( 'Parent Item:', 'pdr' ),
		'new_item_name'              => __( 'New Item Name', 'pdr' ),
		'add_new_item'               => __( 'Add New Item', 'pdr' ),
		'edit_item'                  => __( 'Edit Item', 'pdr' ),
		'update_item'                => __( 'Update Item', 'pdr' ),
		'view_item'                  => __( 'View Item', 'pdr' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'pdr' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'pdr' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'pdr' ),
		'popular_items'              => __( 'Popular Items', 'pdr' ),
		'search_items'               => __( 'Search Items', 'pdr' ),
		'not_found'                  => __( 'Not Found', 'pdr' ),
		'no_terms'                   => __( 'No items', 'pdr' ),
		'items_list'                 => __( 'Items list', 'pdr' ),
		'items_list_navigation'      => __( 'Items list navigation', 'pdr' ),
	);
	$rewrite = array(
		'slug'                       => 'tag-progetto',
		'with_front'                 => true,
		'hierarchical'               => false,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'                    => $rewrite,
	);
	register_taxonomy( 'tag_progetto', array( 'progetto' ), $args );

}
add_action( 'init', 'tag_progetti', 0 );

add_action( 'init', 'cptui_register_my_cpts_video_podcast' );

function cptui_register_my_cpts_video_podcast() {
    $labels = array(
        "name" => __( 'Video' ),
        "singular_name" => __( 'Video' ),
        "add_new" => "Aggiungi Video"
    );
    $args = array(
        "label" => __( 'Video' ),
        "labels" => $labels,
        'menu_icon' => 'dashicons-format-video',
        "description" => "",
        "public" => false,
        "publicly_queryable" => false,
        "show_ui" => true,
        "show_in_rest" => false,
        "rest_base" => "",
        "has_archive" => false,
        "show_in_menu" => true,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => true,
        "rewrite" => array( "slug" => "video-podcast", "with_front" => true ),
        "query_var" => false,
        "menu_position" => 10,
        "supports" => array( "title", "thumbnail", "editor" ),
    );
    register_post_type( "video-podcast", $args );

    $labels = array(
        'name' => __('Tipologia formato', 'b4st'),
        'singular_name' => __('Tipologia formato', 'b4st'),
        'menu_name' => __('Tipologia formato', 'b4st'),
        'show_ui' => true,
        'show_admin_column' => true,
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'rewrite' => array('slug' => 'tipologia-formato')
    );
    register_taxonomy( "tipologia-formato", array( "video-podcast" ), $args );
}

add_action('acf/init', 'my_acfe_modules');
function my_acfe_modules(){

    // enable performance mode with ultra engine (default)
    acf_update_setting('acfe/modules/performance', true);
    
}


/**
 * Aggiunge stili CSS personalizzati alla navbar su tutte le pagine tranne la home.
 */
function my_custom_navbar_styles() {
    // Controlla se la pagina corrente NON è la pagina iniziale (sia che sia una pagina statica che l'indice dei post del blog).
    if ( ! is_front_page() && ! is_home() ) {
        // Definisci gli stili CSS.
        $custom_css = "
        .navbar.navbar-expand-xxl.fixed-top.bg-transparent {
            background-color: rgba(30, 30, 30, 0.70) !important;
            backdrop-filter: blur(10px);
        }";
        // Inietta gli stili direttamente nell'head della pagina.
        echo '<style type="text/css">' . $custom_css . '</style>';
    }
}
// Aggancia la funzione all'hook 'wp_head' in modo che venga eseguita nell'head di ogni pagina.
add_action( 'wp_head', 'my_custom_navbar_styles' );

// Shortcode: [cart_cross_sells]
add_shortcode('cart_cross_sells', function() {
    if ( ! WC()->cart ) return '';

    $cross_sell_ids = pdr_get_cross_sells(4);
    if ( empty($cross_sell_ids) ) return '<p>Nessun prodotto consigliato.</p>';

    // Query prodotti cross-sell
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => 4,
        'post__in'       => $cross_sell_ids,
        'orderby'        => 'post__in'
    );
    $loop = new WP_Query($args);

    ob_start();
    if ( $loop->have_posts() ) {
		echo '<div class="clear"></div>';
		echo '<hr class="divider my-3 mx-auto">';
		echo '<div class="clear"></div>';
        echo '<div class="woocommerce cart-cross-sells">';
        echo '<ul class="products">';
        while ( $loop->have_posts() ) : $loop->the_post();
            wc_get_template_part( 'content', 'product' );
        endwhile;
        echo '</ul>';
        echo '</div>';
    }
    wp_reset_postdata(); // ADDED: Reset post data after custom query
    return ob_get_clean();
});

add_action( 'after_setup_theme', 'custom_remove_product_zoom', 11 );

function custom_remove_product_zoom() {
  remove_theme_support( 'wc-product-gallery-zoom' );
}

add_filter( 'woocommerce_product_tabs', 'inverti_tabs_woocommerce_con_contenuto', 99 );
function inverti_tabs_woocommerce_con_contenuto( $tabs ) {
    // Salva i dati originali
    $desc_tab = isset($tabs['description']) ? $tabs['description'] : null;
    $info_tab = isset($tabs['additional_information']) ? $tabs['additional_information'] : null;

    // Inverti titoli e callback
    if ( $desc_tab && $info_tab ) {
        // Scambia titoli con traduzioni WPML
        $tabs['description']['title'] = apply_filters( 'wpml_translate_single_string', 'Informazioni tecniche', 'pietre-rapolano', 'Product Tab: Technical Info' );
        $tabs['additional_information']['title'] = apply_filters( 'wpml_translate_single_string', 'Utile da sapere', 'pietre-rapolano', 'Product Tab: Useful Info' );

        // Scambia callback e priority
        $tabs['description']['callback'] = $info_tab['callback'];
        $tabs['description']['priority'] = 5;
        $tabs['additional_information']['callback'] = $desc_tab['callback'];
        $tabs['additional_information']['priority'] = 10;
    }

    // Riordina le tab: prima description (ora Info utili), poi additional_information (ora Descrizione)
    $new_tabs = [];
    if ( isset( $tabs['description'] ) ) {
        $new_tabs['description'] = $tabs['description'];
    }
    if ( isset( $tabs['additional_information'] ) ) {
        $new_tabs['additional_information'] = $tabs['additional_information'];
    }
    // Aggiungi eventuali altre tab (es: recensioni)
    foreach ( $tabs as $key => $tab ) {
        if ( ! isset( $new_tabs[$key] ) ) {
            $new_tabs[$key] = $tab;
        }
    }

    return $new_tabs;
}

add_filter( 'woocommerce_product_tabs', 'aggiungi_tab_ar_se_acf', 100, 1 );
function aggiungi_tab_ar_se_acf( $tabs ) {
    global $product;

    if ( ! $product ) {
        $product = wc_get_product( get_the_ID() );
    }

    // Campo ACF true/false
    $prodotto_ar = get_field( 'prodotto_ar', $product->get_id() );

    if ( $prodotto_ar ) {

        $icon = '<img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/07/tabler_augmented-reality-2.svg" style="width:25px;" />';

        $tabs['ar_tab'] = array(
            'title'    => sprintf(
                '%s %s',
                esc_html__( 'Visualizza in realtà aumentata', 'pietre-rapolano' ),
                $icon
            ),
            'priority' => 15,
            'callback' => function() use ( $product ) {
                echo do_shortcode( '[ar-display id="' . $product->get_id() . '"]' );
            }
        );
    }

    return $tabs;
}


add_filter( 'woocommerce_product_tabs', function( $tabs ) {
    global $post;

    $url_ai = get_field( 'url_piattaforma_ai', $post->ID );

    if ( $url_ai ) {

        $icon = '<img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/07/ai-ico.svg" style="width:25px;" />';

        $tabs['configura_ambiente'] = array(
            'title'    => sprintf(
                '%s %s',
                esc_html__( 'Configura il tuo ambiente', 'pietre-rapolano' ),
                $icon
            ),
            'priority' => 50,
            'callback' => function() use ( $url_ai ) {

                echo '<div class="woocommerce-Tabs-panel--configura_ambiente">';

                echo '<p class="uppercase" style="margin-bottom:10px;font-size:20px;">
                        <strong>' . esc_html__( 'Configura il tuo ambiente', 'pietre-rapolano' ) . '</strong>
                      </p>';

                echo '<p>' . esc_html__( 
                    'Scatta una foto e visualizza questo materiale sulla superficie che vuoi. Prova il nostro configuratore per ambienti che sfrutta la potenza dell’intelligenza artificiale.',
                    'pietre-rapolano'
                ) . '</p>';

                echo '<a href="' . esc_url( $url_ai ) . '" class="btn btn-primary uppercase" style="width:100%;">'
                        . esc_html__( 'Visualizza sulla tua superficie', 'pietre-rapolano' ) .
                     '</a>';

                echo '</div>';
            }
        );
    }

    return $tabs;
});


add_action( 'wp', function() {

    if ( is_product() ) {

        add_action( 'woocommerce_single_product_summary', function() {

            global $post;

            $prodotto_a_catalogo = get_field( 'prodotto_a_catalogo', $post->ID );

            if ( $prodotto_a_catalogo ) {

                echo '<div class="banner-info container my-4">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-xs-12">

                                <p class="uppercase text-center" style="margin-bottom:0;font-size:20px;">
                                    <strong>' . esc_html__( 'Per informazioni su questo prodotto', 'pietre-rapolano' ) . '</strong>
                                </p>

                                <p class="text-center uppercase" style="font-weight:700;font-size:30px;margin-bottom:0;">
                                    ' . esc_html__( 'Chiamaci', 'pietre-rapolano' ) . '
                                </p>

                                <p class="text-center" style="font-size:30px;margin-bottom:0;font-weight:700">
                                    <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/10/mynaui_telephone-out.svg"
                                         alt="' . esc_attr__( 'Icona telefono', 'pietre-rapolano' ) . '"
                                         style="width:25px;" />
                                    <u>055.232.6120</u>
                                </p>

                            </div>
                        </div>
                      </div>';

                // CSS inline (non necessita traduzione)
                echo '<style>
                    .pisol-ppscw-container,
                    .cart,
                    .woocommerce div.product p.stock {
                        display: none !important;
                    }

                    .wpcf7-form-control-wrap {
                        position: relative;
                        display: flex;
                    }

                    .wpcf7-form.init p {
                        margin: 0;
                    }

                    .wpcf7-list-item-label {
                        font-family: Roboto;
                        font-weight: 400;
                        font-size: 12px;
                        line-height: 150%;
                        color: #555;
                    }

                    .wpcf7-list-item {
                        margin: 0;
                    }
                </style>';

                echo '<div class="contatto-prodotto container my-4">
                        <p class="uppercase text-center" style="margin-bottom:0;font-size:20px;">
                            <strong>' . esc_html__( 'Richiedi un preventivo', 'pietre-rapolano' ) . '</strong>
                        </p>';

                echo do_shortcode( '[contact-form-7 id="0251251" title="Prodotto catalogo"]' );

                echo '</div>';
            }

        }, 39 ); // subito prima dei meta prodotto
    }
});


 
add_action( 'woocommerce_before_shop_loop_item_title', 'bbloomer_show_sale_percentage_loop', 25 );
 
function bbloomer_show_sale_percentage_loop() {
	global $product;
	if ( $product->is_on_sale() ) {
		if ( ! $product->is_type( 'variable' ) ) {
			$regular_price = $product->get_regular_price();
			$sale_price = $product->get_sale_price();
			$max_percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
	} else {
	foreach ( $product->get_children() as $child_id ) :
		$variation = $product->get_child( $child_id );
		$price = $variation->get_regular_price();
		$sale = $variation->get_sale_price();
		$percentage = $price != 0 && ! empty( $sale ) ? ( ( $price - $sale ) / $price * 100 ) : $max_percentage;
		$highest_percentage = null;
		if ( $percentage >= $highest_percentage ) :
		    $max_percentage = $percentage;
		    $regular_price = $product->get_variation_regular_price( 'min' );
		    $sale_price = $product->get_variation_sale_price( 'min' );
		endif;
		endforeach;
	}
	echo "<span class='percentage'>-" . round($max_percentage) . "%</span>";
	}
}

add_filter( 'woocommerce_upsell_display_args', 'pdr_limit_upsell_products', 10, 1 );
function pdr_limit_upsell_products( $args ) {
    $args['posts_per_page'] = 2; // Mostra solo 2 prodotti
    $args['columns'] = 2;        // 2 colonne (opzionale, per l'aspetto)
    return $args;
}

add_filter( 'woocommerce_display_product_attributes', function( $product_attributes ) {
    foreach ( $product_attributes as &$attribute ) {
        if ( isset( $attribute['value'] ) ) {
            $attribute['value'] = wp_strip_all_tags( $attribute['value'] );
        }
    }
    return $product_attributes;
}, 10, 1 );

/**
 * Riordina i prodotti:
 * - Search & Filter Pro (query ID = 1)
 * - Archive /catalogo/
 * mantenendo lo stesso ordine in tutte le lingue WPML
 */

/* ---------------------------------------------------------
 * 1) Helper WPML: restituisce l'ID del termine nella lingua corrente
 * --------------------------------------------------------- */


/* ---------------------------------------------------------
 * 2) Riordina array di product IDs secondo gerarchia categorie
 * --------------------------------------------------------- */


/* ---------------------------------------------------------
 * 3) Search & Filter Pro – Query ID = 1
 * --------------------------------------------------------- */
add_action(
    'search-filter/query/query_args',
    function ( $query_args, $search_filter_query ) {

        $target_sfid = 1;

        $query_id = method_exists( $search_filter_query, 'get_id' )
            ? $search_filter_query->get_id()
            : null;

        if ( $query_id !== $target_sfid ) {
            return $query_args;
        }

        // Query temporanea per ottenere TUTTI gli ID filtrati
        $temp_args                   = $query_args;
        $temp_args['posts_per_page'] = -1;
        $temp_args['fields']         = 'ids';
        $temp_args['post_status']    = 'publish';

        $temp_query  = new WP_Query( $temp_args );
        $matched_ids = $temp_query->posts;
        wp_reset_postdata();

        if ( empty( $matched_ids ) ) {
            return $query_args;
        }

        $final_ids = pdr_order_ids_by_category_hierarchy( $matched_ids );

        // Forza ordine
        $query_args['post__in'] = $final_ids;
        $query_args['orderby']  = 'post__in';

        return $query_args;

    },
    10,
    2
);

/* ---------------------------------------------------------
 * 4) Archive /catalogo/ – Main Query
 * --------------------------------------------------------- */
add_action(
    'pre_get_posts',
    function ( $query ) {

        if ( is_admin() || ! $query->is_main_query() ) {
            return;
        }

        // Solo prodotti
        if ( ! ( $query->is_post_type_archive( 'product' ) || $query->get( 'post_type' ) === 'product' ) ) {
            return;
        }

        // Pagina catalogo (slug: catalogo)
        $catalog_page = get_page_by_path( 'catalogo' );
        if ( ! $catalog_page ) {
            return;
        }

        $queried_id = get_queried_object_id();
        if (
            intval( $queried_id ) !== intval( $catalog_page->ID ) &&
            ! $query->is_post_type_archive( 'product' )
        ) {
            return;
        }

        // Query temporanea senza paginazione
        $temp_args                   = $query->query_vars;
        $temp_args['posts_per_page'] = -1;
        $temp_args['fields']         = 'ids';
        $temp_args['post_status']    = 'publish';

        unset( $temp_args['paged'], $temp_args['offset'] );

        $temp_query  = new WP_Query( $temp_args );
        $matched_ids = $temp_query->posts;
        wp_reset_postdata();

        if ( empty( $matched_ids ) ) {
            return;
        }

        $final_ids = pdr_order_ids_by_category_hierarchy( $matched_ids );

        // Forza ordine
        $query->set( 'post__in', $final_ids );
        $query->set( 'orderby', 'post__in' );

    },
    20
);

/**
 * Ottimizzazione avanzata di mPDF per DK PDF
 */
add_action( 'dkpdf_mpdf', 'custom_dkpdf_optimize_mpdf_advanced' );

function custom_dkpdf_optimize_mpdf_advanced( $mpdf ) {

    /**------------------------------------------
     * IMMAGINI
     *------------------------------------------*/
    // Qualità JPEG ridotta
    $mpdf->jpeg_quality = 60;

    // Limita DPI per ridurre peso immagini
    $mpdf->img_dpi = 72;

    // Riduce ulteriormente la memoria usata dalle immagini
    $mpdf->useSubstitutions = false;

    /**------------------------------------------
     * COMPRESSIONE
     *------------------------------------------*/
    $mpdf->setCompression(true); // abilita compressione PDF
    $mpdf->dpi = 72;             // DPI globale più basso
    $mpdf->showImageErrors = false;

    /**------------------------------------------
     * CSS / HTML / TABELLE
     *------------------------------------------*/
    // Riduce l’impatto della gestione CSS complessa
    $mpdf->use_kwt = false; 

    // Evita loop su tabelle molto larghe
    $mpdf->shrink_tables_to_fit = 1;

    // Disabilita stretching tabelle (costoso in memoria)
    $mpdf->packTableData = false;

    // Riduce profondità HTML interna (più leggero)
    $mpdf->simpleTables = true;

    /**------------------------------------------
     * CACHE / OTTIMIZZAZIONI MEMORIA
     *------------------------------------------*/
    $mpdf->useCache = true;
    $mpdf->useGraphs = false;     // disattiva grafici
    $mpdf->useLang = false;       // disattiva parsing lingue
    $mpdf->useSubstitutions = false;  // no font substitution
    $mpdf->useFixedNormalLineHeight = true;
    $mpdf->useFixedTextBaseline = true;

    /**------------------------------------------
     * DEBUG (opzionale)
     *------------------------------------------*/
    // ATTENZIONE: abilitarlo solo per test
    // $mpdf->debug = true;
    // $mpdf->showImageErrors = true;
}

add_filter( 'woocommerce_product_tabs', 'display_empty_additional_info_tab', 99, 1 );
function display_empty_additional_info_tab( $tabs ) {
    // Check if the tab is already present and has content.
    if ( !isset( $tabs['description'] ) ) {
        // If not, add a blank one (or add your specific data here).
        $tabs['description'] = array(
            'title' => __( 'Utile da sapere', 'woocommerce' ),
            'priority' => 30,
            'callback' => 'woocommerce_product_description_tab', // Use the default callback
        );
    }
    return $tabs;
}

add_action( 'init', function() {

    if ( function_exists( 'icl_register_string' ) ) {

        // URL
        icl_register_string( 'pietre-rapolano', 'Account URL', 'https://pdr.demo-dirweb.it/mio-account/' );
        icl_register_string( 'pietre-rapolano', 'Wishlist URL', 'https://pdr.demo-dirweb.it/preferiti/' );
        icl_register_string( 'pietre-rapolano', 'Cart URL', 'https://pdr.demo-dirweb.it/carrello/' );

        // Testi
        icl_register_string( 'pietre-rapolano', 'Account Text', 'ACCOUNT' );
        icl_register_string( 'pietre-rapolano', 'Search Text', 'Cerca' );
        icl_register_string( 'pietre-rapolano', 'Skip to content', 'Skip to content' );

   // Travertino
        icl_register_string( 'pietre-rapolano', 'Bagno Travertino URL', 'https://pdr.demo-dirweb.it/bagno/' );
        icl_register_string( 'pietre-rapolano', 'Cucina Travertino URL', 'https://pdr.demo-dirweb.it/cucina/' );
        icl_register_string( 'pietre-rapolano', 'Soggiorno Travertino URL', 'https://pdr.demo-dirweb.it/soggiorno/' );
        icl_register_string( 'pietre-rapolano', 'Piscina Travertino URL', 'https://pdr.demo-dirweb.it/piscine/' );
        icl_register_string( 'pietre-rapolano', 'Esterni Travertino URL', 'https://pdr.demo-dirweb.it/esterni/' );

        // Marmo
        icl_register_string( 'pietre-rapolano', 'Bagno Marmo URL', 'https://pdr.demo-dirweb.it/bagni-in-marmo/' );
        icl_register_string( 'pietre-rapolano', 'Cucina Marmo URL', 'https://pdr.demo-dirweb.it/cucine-in-marmo/' );
        icl_register_string( 'pietre-rapolano', 'Soggiorno Marmo URL', 'https://pdr.demo-dirweb.it/soggiorni-in-marmo/' );

        // Catalogo
        icl_register_string( 'pietre-rapolano', 'Catalogo URL', 'https://pdr.demo-dirweb.it/catalogo/' );

        icl_register_string(
            'pietre-rapolano',
            'Progettazione URL',
            'https://pdr.demo-dirweb.it/progettazione/'
        );

        icl_register_string(
            'pietre-rapolano',
            'Progettazione Text',
            'PROGETTAZIONE'
        );

        icl_register_string(
            'pietre-rapolano',
            'Progettazione Title',
            'Pagina progettazione'
        );
    // CONTATTI
        icl_register_string( 'pietre-rapolano', 'Contatti URL', 'https://pdr.demo-dirweb.it/contatti/' );
        icl_register_string( 'pietre-rapolano', 'Contatti Text', 'CONTATTACI' );
        icl_register_string( 'pietre-rapolano', 'Contatti Title', 'Pagina contatti' );

        // FORNITURA E POSA IN OPERA
        icl_register_string( 'pietre-rapolano', 'Posa Opera URL', 'https://pdr.demo-dirweb.it/fornitura-e-posa-in-opera/' );
        icl_register_string( 'pietre-rapolano', 'Posa Opera Text', 'FORNITURA E POSA IN OPERA' );
        icl_register_string( 'pietre-rapolano', 'Posa Opera Title', 'Pagina fornitura e posa in opera' );

        // PROGETTAZIONE
        icl_register_string( 'pietre-rapolano', 'Progettazione URL', 'https://pdr.demo-dirweb.it/progettazione/' );
        icl_register_string( 'pietre-rapolano', 'Progettazione Text', 'PROGETTAZIONE' );
        icl_register_string( 'pietre-rapolano', 'Progettazione Title', 'Pagina progettazione' );

        $default_text = get_option('dkpdf_pdfbutton_text', 'PDF Button');
        icl_register_string('DK PDF', 'PDF Button Text', $default_text);
    }


});

add_filter( 'woocommerce_enqueue_styles', function( $styles ) {
    if ( is_product() ) {
        return array(); // disattiva gli stili solo nella scheda prodotto
    }

    return $styles; // mantiene gli stili WooCommerce nel resto del sito
});

// Product page specific styles moved to separate CSS file
// See css/inline-styles.css for product page customizations

/* Sincronizzazione immagini in evidenza e contneuti tradotti con WPML */

add_action('save_post', function ($post_id) {

    if (wp_is_post_revision($post_id)) return;

    $allowed_post_types = ['post', 'progetto', 'product'];
    $post_type = get_post_type($post_id);

    if (!in_array($post_type, $allowed_post_types, true)) return;

    // Prendo solo la lingua originale
    $default_lang = apply_filters('wpml_default_language', null);
    $post_lang = apply_filters('wpml_post_language_details', null, $post_id);

    if (empty($post_lang['language_code']) || $post_lang['language_code'] !== $default_lang) {
        return;
    }

    $thumbnail_id = get_post_thumbnail_id($post_id);
    if (!$thumbnail_id) return;

    $trid = apply_filters('wpml_element_trid', null, $post_id, 'post_' . $post_type);
    if (!$trid) return;

    $translations = apply_filters('wpml_get_element_translations', null, $trid, 'post_' . $post_type);

    foreach ($translations as $translation) {
        if ($translation->element_id != $post_id) {
            if (!get_post_thumbnail_id($translation->element_id)) {
                set_post_thumbnail($translation->element_id, $thumbnail_id);
            }
        }
    }
});

/* Fix breadcrumb Yoast SEO per WooCommerce + WPML */

add_filter('wpseo_breadcrumb_links', function ($links) {

    if (!function_exists('wc_get_page_id')) {
        return $links;
    }

    // Solo WooCommerce
    if (
        !is_shop() &&
        !is_product() &&
        !is_product_category() &&
        !is_product_tag()
    ) {
        return $links;
    }

    $shop_page_id = wc_get_page_id('shop');
    if (!$shop_page_id || $shop_page_id < 0) {
        return $links;
    }

    $shop_url   = get_permalink($shop_page_id);
    $shop_title = get_the_title($shop_page_id);

    $cleaned = [];
    $shop_inserted = false;

    foreach ($links as $index => $link) {

        // 🔥 RIMUOVE QUALSIASI SHOP (qualunque lingua / URL / tipo)
        if (
            (isset($link['text']) && mb_strtolower(trim($link['text'])) === mb_strtolower(trim($shop_title))) ||
            (isset($link['ptarchive']) && $link['ptarchive'] === 'product')
        ) {
            continue;
        }

        // Inseriamo lo Shop SUBITO DOPO Home
        if ($index === 1 && !$shop_inserted) {
            $cleaned[] = [
                'url'  => $shop_url,
                'text' => $shop_title,
            ];
            $shop_inserted = true;
        }

        $cleaned[] = $link;
    }

    // Fallback: se per qualche motivo non è stato inserito
    if (!$shop_inserted && count($cleaned) > 0) {
        array_splice($cleaned, 1, 0, [[
            'url'  => $shop_url,
            'text' => $shop_title,
        ]]);
    }

    return $cleaned;
});


  
// Parte 1 
// Mostra la casella di controllo
add_action( 'woocommerce_review_order_before_payment', 'bbloomer_checkout_checkbox_choice' );

function bbloomer_checkout_checkbox_choice() {
    $chosen = WC()->session->get( 'checkbox_chosen' );
    $chosen = empty( $chosen ) ? WC()->checkout->get_value( 'checkbox_choice' ) : $chosen;
    $chosen = empty( $chosen ) ? '0' : $chosen;
        
    $args = array(
        'type' => 'checkbox',
        'class' => array( 'form-row-wide', 'update_totals_on_change' ),
        'label' => __( 'Assicurazione (€3)', 'pietre-rapolano' )
    );
     
    echo '<div id="checkout-checkbox">';
    woocommerce_form_field( 'checkbox_choice', $args, false ); // Impostato su false per evitare selezione predefinita
    echo '<p style="color:red; display:none;font-size: 15px;" id="additional-fee-text">' . __( 'Per garantire la possibilità di avanzare eventuali reclami nei confronti della compagnia assicurativa, è necessario che:<br> -Verifichi attentamente le condizioni del pacco al momento della ricezione. In caso di anomalie visibili sull\'imballaggio, accetti la consegna apponendo la firma sul documento di trasporto con la dicitura "<b>ACCETTO CON RISERVA PER IMBALLO DANNEGGIATO</b>".<br>È fondamentale disporre di una prova scritta sui documenti di trasporto per far valere i propri diritti. Senza tale documentazione, non sarà possibile ottenere la sostituzione o il rimborso della merce danneggiata dalla compagnia assicurativa.', 'pietre-rapolano' ) . '</p>';
    echo '</div>';
}

// Parte 2 
// Aggiungi la fee e calcola il totale
add_action( 'woocommerce_cart_calculate_fees', 'bbloomer_checkout_checkbox_choice_fee', 20, 1 );

function bbloomer_checkout_checkbox_choice_fee( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
    
    $checkbox = WC()->session->get( 'checkbox_chosen' );
     
    if ( $checkbox == '1' ) {
        $cart->add_fee( __( 'Assicurazione', 'pietre-rapolano' ), 3 );
    }
}

// Parte 3 
// Aggiungi la scelta della casella di controllo alla sessione
add_action( 'woocommerce_checkout_update_order_review', 'bbloomer_checkout_checkbox_choice_set_session' );

function bbloomer_checkout_checkbox_choice_set_session( $posted_data ) {
    parse_str( $posted_data, $output );
    $checkbox_choice = isset( $output['checkbox_choice'] ) ? '1' : '0';
    $order_id = isset( $output['post_data']['post_id'] ) ? $output['post_data']['post_id'] : false;
    if ( $order_id ) {
        update_post_meta( $order_id, 'checkbox_chosen', $checkbox_choice );
    }
    WC()->session->set( 'checkbox_chosen', $checkbox_choice );
}

// Parte 4
// Aggiungi jQuery per mostrare il testo aggiuntivo solo quando la casella di controllo è selezionata
add_action( 'wp_footer', 'bbloomer_checkbox_choice_jquery_script' );

function bbloomer_checkbox_choice_jquery_script() {
    if (is_checkout()) { ?>
        <script type="text/javascript">
            jQuery(document).ready(function($){
                $('#checkbox_choice').change(function(){
                    if($(this).is(':checked')) {
                        $('#additional-fee-text').show();
                    } else {
                        $('#additional-fee-text').hide();
                    }
                });
            });
        </script>
    <?php }
}

// Parte 5
// Aggiungi il campo nella vista dettagli ordine nel backend e nelle email
add_action( 'woocommerce_checkout_update_order_meta', 'save_assicurazione_in_order_meta' );

function save_assicurazione_in_order_meta( $order_id ) {
    if ( empty( $_POST['checkbox_choice'] ) ) return;

    // Salva il valore della casella di controllo "assicurazione" nei metadati dell'ordine
    update_post_meta( $order_id, '_checkbox_choice', sanitize_text_field( $_POST['checkbox_choice'] ) );
}


add_action( 'woocommerce_admin_order_data_after_billing_address', 'display_assicurazione_in_order_details', 10, 1 );

function display_assicurazione_in_order_details( $order ) {
    // Recupera il valore del campo "assicurazione" dai metadati dell'ordine
    $assicurazione = get_post_meta( $order->get_id(), '_checkbox_choice', true );

    // Visualizza il valore del campo "assicurazione"
    if ( $assicurazione == '1' ) {
        printf( '<p><strong>%s:</strong> %s</p>', __( 'Assicurazione (€3)', 'pietre-rapolano' ), __( 'Selezionata', 'pietre-rapolano' ) );
    } else {
        printf( '<p><strong>%s:</strong> %s</p>', __( 'Assicurazione (€3)', 'pietre-rapolano' ), __( 'Non selezionata', 'pietre-rapolano' ) );
    }
}

/**
 * Salva l'ultima scheda prodotto visitata
 */
function pdr_store_last_product_url() {
    if ( is_singular('product') ) {
        setcookie(
            'pdr_last_product',
            get_permalink(),
            time() + 3600,
            COOKIEPATH,
            COOKIE_DOMAIN
        );
    }
}
add_action('template_redirect', 'pdr_store_last_product_url');


/**
 * Shortcode: [pdr_back_to_product]
 */
function pdr_back_to_product_shortcode() {

    $back_url = '';

    if ( isset($_COOKIE['pdr_last_product']) ) {
        $back_url = esc_url($_COOKIE['pdr_last_product']);
    }

    // Fallback sicurezza
    if ( empty($back_url) ) {
        $back_url = 'javascript:history.back()';
    }

    ob_start();
    ?>
    <div class="back">
        <a href="<?php echo $back_url; ?>">
            <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-left.svg" width="24px" />
            Torna indietro
        </a>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('pdr_back_to_product', 'pdr_back_to_product_shortcode');
