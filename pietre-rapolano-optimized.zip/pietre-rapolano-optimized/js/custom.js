// to enable the enqueue of this optional JS file, 
// you'll have to uncomment a row in the functions.php file
// just read the comments in there mate

// Remove console.log in production
// console.log("Custom js file loaded");

//add here your own js code. Vanilla JS welcome.

// Search overlay functionality
const openSearchOverlay = document.getElementById('openSearchOverlay');
const closeSearchOverlay = document.getElementById('closeSearchOverlay');
const searchOverlay = document.getElementById('searchOverlay');

if (openSearchOverlay && searchOverlay) {
  openSearchOverlay.addEventListener('click', function (e) {
    e.preventDefault();
    searchOverlay.style.display = 'flex';
    const searchInput = searchOverlay.querySelector('.search-input');
    if (searchInput) searchInput.focus();
  });
}

if (closeSearchOverlay && searchOverlay) {
  closeSearchOverlay.addEventListener('click', function () {
    searchOverlay.style.display = 'none';
  });
}

// Close search overlay with ESC
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && searchOverlay) {
    searchOverlay.style.display = 'none';
  }
});

// Menu search modal functionality
document.addEventListener('DOMContentLoaded', function () {
    const openBtn = document.getElementById('openMenuSearchModal');
    const closeBtn = document.getElementById('closeMenuSearchModal');
    const modal = document.getElementById('menuSearchModal');

    if (openBtn && modal) {
        openBtn.addEventListener('click', function (e) {
            e.preventDefault();
            modal.classList.add('active');

            // focus input if present
            const input = modal.querySelector('input');
            if (input) setTimeout(() => input.focus(), 150);
        });
    }

    if (closeBtn && modal) {
        closeBtn.addEventListener('click', function () {
            modal.classList.remove('active');
        });
    }

    if (modal) {
        modal.addEventListener('click', function (e) {
            if (e.target === this) modal.classList.remove('active');
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && modal) modal.classList.remove('active');
    });
});
