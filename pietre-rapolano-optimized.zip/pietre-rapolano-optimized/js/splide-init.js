/**
 * Splide Carousel Initialization
 * Centralized initialization for all Splide carousels
 * 
 * @package Pietre-Rapolano
 */

document.addEventListener('DOMContentLoaded', function () {
    
    /**
     * Initialize Gallery Splide (generale.php)
     */
    const gallerySplide = document.getElementById('gallerySplide');
    if (gallerySplide) {
        const splide = new Splide('#gallerySplide', {
            type: 'loop',
            perPage: 5,
            perMove: 5,
            gap: '1rem',
            autoplay: true,
            interval: 5000,
            pauseOnHover: true,
            arrows: false,
            pagination: false,
            breakpoints: {
                1200: { perPage: 3, perMove: 3 },
                768: { perPage: 1, perMove: 1 }
            }
        }).mount();

        // Custom arrows
        const prevBtn = document.querySelector('.splide-arrow-custom.prev');
        const nextBtn = document.querySelector('.splide-arrow-custom.next');
        
        if (prevBtn) prevBtn.addEventListener('click', () => splide.go('<'));
        if (nextBtn) nextBtn.addEventListener('click', () => splide.go('>'));

        // Custom page numbers
        const pageNums = document.querySelectorAll('.splide-page-num');
        pageNums.forEach((num, idx) => {
            num.addEventListener('click', () => splide.go(idx * 5));
        });

        splide.on('move', (newIndex) => {
            const groupSize = 5;
            const page = Math.floor(newIndex / groupSize);
            pageNums.forEach((num, idx) => {
                num.classList.toggle('active', idx === page);
            });
        });

        // Lightbox functionality
        initGalleryLightbox();
    }

    /**
     * Initialize Products Splide
     */
    const prodottiSplide = document.getElementById('prodottiSplide');
    if (prodottiSplide) {
        new Splide('#prodottiSplide', {
            type: 'loop',
            perPage: 5,
            perMove: 1,
            gap: '2rem',
            autoplay: true,
            interval: 7000,
            pauseOnHover: true,
            arrows: false,
            pagination: false,
            breakpoints: {
                1200: { perPage: 3 },
                768: { perPage: 1 }
            }
        }).mount();
    }

    /**
     * Initialize Projects Splide
     */
    const progettiSplide = document.getElementById('progettiSplide');
    if (progettiSplide) {
        new Splide('#progettiSplide', {
            type: 'loop',
            perPage: 3,
            perMove: 1,
            gap: '2rem',
            autoplay: true,
            interval: 6000,
            pauseOnHover: true,
            arrows: false,
            pagination: false,
            breakpoints: {
                1200: { perPage: 2 },
                768: { perPage: 1 }
            }
        }).mount();
    }

    /**
     * Initialize Blog/Feedback Splide (home.php)
     */
    const feedbackSplide = document.getElementById('feedbackSplide');
    if (feedbackSplide) {
        const splide = new Splide('#feedbackSplide', {
            type: 'loop',
            perPage: 4,
            perMove: 1,
            gap: '2rem',
            autoplay: true,
            interval: 5000,
            pauseOnHover: true,
            arrows: false,
            pagination: false,
            breakpoints: {
                1200: { perPage: 3, perMove: 3 },
                993: { perPage: 3, perMove: 3 },
                992: { perPage: 2, perMove: 2 },
                768: { perPage: 1, perMove: 1 }
            }
        }).mount();

        // Custom arrows
        const prevBtn = document.querySelector('.splide-arrow-custom.prev');
        const nextBtn = document.querySelector('.splide-arrow-custom.next');
        
        if (prevBtn) prevBtn.addEventListener('click', () => splide.go('<'));
        if (nextBtn) nextBtn.addEventListener('click', () => splide.go('>'));

        // Custom page numbers
        const pageNums = document.querySelectorAll('.splide-page-num');
        pageNums.forEach((num, idx) => {
            num.addEventListener('click', () => splide.go(idx));
        });

        splide.on('move', (newIndex) => {
            const total = pageNums.length;
            const realIndex = (newIndex % total + total) % total;
            pageNums.forEach((num, idx) => {
                num.classList.toggle('active', idx === realIndex);
            });
        });
    }
});

/**
 * Gallery Lightbox Initialization
 */
function initGalleryLightbox() {
    const galleryLinks = Array.from(document.querySelectorAll('#gallerySplide a[data-bs-toggle="modal"]'));
    
    if (galleryLinks.length === 0) return;
    
    let currentIndex = 0;
    const lightboxModal = document.getElementById('lightboxModal');
    const lightboxImage = document.getElementById('lightboxImage');
    const lightboxCaption = document.getElementById('lightboxCaption');
    const lightboxPrev = document.getElementById('lightboxPrev');
    const lightboxNext = document.getElementById('lightboxNext');

    if (!lightboxModal || !lightboxImage) return;

    function showImage(idx) {
        if (idx < 0) idx = galleryLinks.length - 1;
        if (idx >= galleryLinks.length) idx = 0;
        currentIndex = idx;
        
        const link = galleryLinks[currentIndex];
        const img = link.getAttribute('data-bs-img');
        const caption = link.getAttribute('data-bs-caption') || '';
        
        lightboxImage.src = img;
        if (lightboxCaption) lightboxCaption.textContent = caption;
    }

    galleryLinks.forEach((link, idx) => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            showImage(idx);
            if (typeof bootstrap !== 'undefined') {
                const modal = bootstrap.Modal.getOrCreateInstance(lightboxModal);
                modal.show();
            }
        });
    });

    if (lightboxPrev) {
        lightboxPrev.addEventListener('click', (e) => {
            e.preventDefault();
            showImage(currentIndex - 1);
        });
    }

    if (lightboxNext) {
        lightboxNext.addEventListener('click', (e) => {
            e.preventDefault();
            showImage(currentIndex + 1);
        });
    }

    // Keyboard navigation
    function lightboxKeyHandler(e) {
        if (e.key === 'ArrowLeft') showImage(currentIndex - 1);
        else if (e.key === 'ArrowRight') showImage(currentIndex + 1);
    }

    lightboxModal.addEventListener('shown.bs.modal', () => {
        document.addEventListener('keydown', lightboxKeyHandler);
    });

    lightboxModal.addEventListener('hidden.bs.modal', () => {
        lightboxImage.src = '';
        if (lightboxCaption) lightboxCaption.textContent = '';
        document.removeEventListener('keydown', lightboxKeyHandler);
    });

    // Show zoom icon on hover
    document.querySelectorAll('.gallery-img-link').forEach((link) => {
        link.addEventListener('mouseenter', function () {
            const icon = this.querySelector('.zoom-icon');
            if (icon) icon.style.display = 'block';
        });
        
        link.addEventListener('mouseleave', function () {
            const icon = this.querySelector('.zoom-icon');
            if (icon) icon.style.display = 'none';
        });
    });
}
