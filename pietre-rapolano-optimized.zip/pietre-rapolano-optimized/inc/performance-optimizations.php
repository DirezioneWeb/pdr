<?php
/**
 * Performance Optimizations
 * 
 * Centralizes performance-related optimizations including:
 * - Lazy loading images
 * - Preload critical resources
 * - Script optimization (defer/async)
 * - Transient cache helpers
 * 
 * @package Pietre-Rapolano
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Add lazy loading to all images
 */
add_filter('wp_get_attachment_image_attributes', 'pdr_add_lazy_loading', 10, 3);
function pdr_add_lazy_loading($attr, $attachment, $size) {
    // Skip if already has loading attribute
    if (isset($attr['loading'])) {
        return $attr;
    }
    
    // Add lazy loading
    $attr['loading'] = 'lazy';
    
    return $attr;
}

/**
 * Add lazy loading to content images
 */
add_filter('the_content', 'pdr_lazy_load_content_images');
function pdr_lazy_load_content_images($content) {
    // Add loading="lazy" to img tags that don't have it
    $content = preg_replace('/<img((?![^>]*loading=)[^>]*)>/i', '<img loading="lazy"$1>', $content);
    
    return $content;
}

/**
 * Preload critical resources
 */
add_action('wp_head', 'pdr_preload_critical_resources', 1);
function pdr_preload_critical_resources() {
    // Preload Splide CSS
    echo '<link rel="preload" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.3/dist/css/splide.min.css" as="style">' . "\n";
    
    // Preload Bootstrap JS
    $bootstrap_url = get_stylesheet_directory_uri() . '/js/bootstrap.bundle.min.js';
    echo '<link rel="preload" href="' . esc_url($bootstrap_url) . '" as="script">' . "\n";
}

/**
 * Optimize script loading - add defer to non-critical scripts
 */
add_filter('script_loader_tag', 'pdr_defer_scripts', 10, 3);
function pdr_defer_scripts($tag, $handle, $src) {
    // Scripts to defer (non-critical)
    $defer_scripts = array(
        'splide-js',
        'splide-init',
    );
    
    if (in_array($handle, $defer_scripts)) {
        // Add defer if not already present
        if (strpos($tag, 'defer') === false) {
            $tag = str_replace(' src', ' defer src', $tag);
        }
    }
    
    return $tag;
}

/**
 * Transient Cache Helper - Get or Set
 * 
 * @param string $key Cache key
 * @param callable $callback Function to generate data if cache miss
 * @param int $expiration Cache expiration in seconds (default: 1 hour)
 * @return mixed Cached or fresh data
 */
function pdr_cache_get_or_set($key, $callback, $expiration = HOUR_IN_SECONDS) {
    $cached = get_transient($key);
    
    if (false !== $cached) {
        return $cached;
    }
    
    $data = call_user_func($callback);
    set_transient($key, $data, $expiration);
    
    return $data;
}

/**
 * Clear all PDR transient caches
 * Useful for debugging or when content is updated
 */
function pdr_clear_all_caches() {
    global $wpdb;
    
    // Delete all transients starting with 'pdr_'
    $wpdb->query(
        "DELETE FROM {$wpdb->options} 
        WHERE option_name LIKE '_transient_pdr_%' 
        OR option_name LIKE '_transient_timeout_pdr_%'"
    );
    
    // Clear object cache if available
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
}

/**
 * Clear caches when products are updated
 */
add_action('save_post_product', 'pdr_clear_product_caches', 10, 3);
function pdr_clear_product_caches($post_id, $post, $update) {
    // Clear product ordering cache
    delete_transient('pdr_ordered_product_ids');
    
    // Clear category-specific caches
    $terms = wp_get_post_terms($post_id, 'product_cat', array('fields' => 'ids'));
    foreach ($terms as $term_id) {
        delete_transient('pdr_category_products_' . $term_id);
    }
}

/**
 * Clear caches when posts are updated
 */
add_action('save_post_post', 'pdr_clear_post_caches');
add_action('save_post_progetto', 'pdr_clear_post_caches');
function pdr_clear_post_caches($post_id) {
    // Clear blog posts cache
    delete_transient('pdr_blog_posts_home');
    delete_transient('pdr_progetti_archive');
}

/**
 * Disable emoji scripts (performance optimization)
 */
add_action('init', 'pdr_disable_emojis');
function pdr_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}

/**
 * Remove query strings from static resources (better caching)
 */
add_filter('script_loader_src', 'pdr_remove_query_strings', 15, 1);
add_filter('style_loader_src', 'pdr_remove_query_strings', 15, 1);
function pdr_remove_query_strings($src) {
    if (strpos($src, '?ver=')) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}

/**
 * Optimize ACF performance
 */
add_filter('acf/settings/remove_wp_meta_box', '__return_true');

/**
 * Limit post revisions
 */
if (!defined('WP_POST_REVISIONS')) {
    define('WP_POST_REVISIONS', 5);
}

/**
 * Increase autosave interval
 */
if (!defined('AUTOSAVE_INTERVAL')) {
    define('AUTOSAVE_INTERVAL', 300); // 5 minutes
}
