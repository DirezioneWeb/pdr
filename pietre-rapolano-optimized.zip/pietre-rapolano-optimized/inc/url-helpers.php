<?php
/**
 * URL Helper Functions
 * 
 * Centralized URL management with WPML support
 * Replaces hardcoded URLs throughout the theme
 * 
 * @package Pietre-Rapolano
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Get translated URL with WPML support
 * 
 * @param string $path URL path (e.g., '/catalogo/')
 * @param string $context Translation context
 * @param string $name Translation name
 * @return string Full URL
 */
function pdr_get_url($path, $context = 'pietre-rapolano', $name = '') {
    // Build full URL from path
    $url = home_url($path);
    
    // Apply WPML translation if available
    if (function_exists('apply_filters')) {
        $name = $name ?: ucfirst(trim($path, '/')) . ' URL';
        $url = apply_filters('wpml_translate_single_string', $url, $context, $name);
    }
    
    return $url;
}

/**
 * Get catalog URL
 */
function pdr_catalog_url() {
    return pdr_get_url('/catalogo/', 'pietre-rapolano', 'Catalogo URL');
}

/**
 * Get contacts URL
 */
function pdr_contacts_url() {
    return pdr_get_url('/contatti/', 'pietre-rapolano', 'Contatti URL');
}

/**
 * Get account URL
 */
function pdr_account_url() {
    return pdr_get_url('/mio-account/', 'pietre-rapolano', 'Account URL');
}

/**
 * Get wishlist URL
 */
function pdr_wishlist_url() {
    return pdr_get_url('/preferiti/', 'pietre-rapolano', 'Wishlist URL');
}

/**
 * Get cart URL
 */
function pdr_cart_url() {
    return pdr_get_url('/carrello/', 'pietre-rapolano', 'Cart URL');
}

/**
 * Get progettazione URL
 */
function pdr_progettazione_url() {
    return pdr_get_url('/progettazione/', 'pietre-rapolano', 'Progettazione URL');
}

/**
 * Get posa opera URL
 */
function pdr_posa_opera_url() {
    return pdr_get_url('/fornitura-e-posa-in-opera/', 'pietre-rapolano', 'Posa Opera URL');
}

/**
 * Travertino environment URLs
 */
function pdr_bagno_travertino_url() {
    return pdr_get_url('/bagno/', 'pietre-rapolano', 'Bagno Travertino URL');
}

function pdr_cucina_travertino_url() {
    return pdr_get_url('/cucina/', 'pietre-rapolano', 'Cucina Travertino URL');
}

function pdr_soggiorno_travertino_url() {
    return pdr_get_url('/soggiorno/', 'pietre-rapolano', 'Soggiorno Travertino URL');
}

function pdr_piscina_travertino_url() {
    return pdr_get_url('/piscine/', 'pietre-rapolano', 'Piscina Travertino URL');
}

function pdr_esterni_travertino_url() {
    return pdr_get_url('/esterni/', 'pietre-rapolano', 'Esterni Travertino URL');
}

/**
 * Marmo environment URLs
 */
function pdr_bagno_marmo_url() {
    return pdr_get_url('/bagni-in-marmo/', 'pietre-rapolano', 'Bagno Marmo URL');
}

function pdr_cucina_marmo_url() {
    return pdr_get_url('/cucine-in-marmo/', 'pietre-rapolano', 'Cucina Marmo URL');
}

function pdr_soggiorno_marmo_url() {
    return pdr_get_url('/soggiorni-in-marmo/', 'pietre-rapolano', 'Soggiorno Marmo URL');
}

/**
 * Pietra environment URLs
 */
function pdr_caminetti_url() {
    return pdr_get_url('/caminetti-in-pietra/', 'pietre-rapolano', 'Caminetti URL');
}

function pdr_copertine_cordoli_url() {
    return pdr_get_url('/copertine-e-cordoli/', 'pietre-rapolano', 'Copertine e Cordoli URL');
}

function pdr_pavimenti_rivestimenti_url() {
    return pdr_get_url('/pavimenti-e-rivestimenti-in-pietra/', 'pietre-rapolano', 'Pavimenti e Rivestimenti URL');
}

function pdr_scale_url() {
    return pdr_get_url('/scale-in-pietra-serena/', 'pietre-rapolano', 'Scale in Pietra Serena URL');
}

function pdr_soglie_davanzali_url() {
    return pdr_get_url('/soglie-e-davanzali-in-pietra/', 'pietre-rapolano', 'Soglie e Davanzali URL');
}

/**
 * Falegnameria URLs
 */
function pdr_falegnameria_url() {
    return pdr_get_url('/falegnameria-artigianale/', 'pietre-rapolano', 'Falegnameria URL');
}

function pdr_arredi_bagno_url() {
    return pdr_get_url('/arredi-bagno-in-legno/', 'pietre-rapolano', 'Arredi Bagno URL');
}

function pdr_arredi_cucina_url() {
    return pdr_get_url('/arredi-cucina-in-legno/', 'pietre-rapolano', 'Arredi Cucina URL');
}

/**
 * Get media URL from theme directory
 * 
 * @param string $filename Filename in media folder
 * @return string Full URL to media file
 */
function pdr_media_url($filename) {
    return get_template_directory_uri() . '/media/' . ltrim($filename, '/');
}

/**
 * Get asset URL (images, icons, etc.)
 * Replaces hardcoded pdr.demo-dirweb.it URLs
 * 
 * @param string $path Path to asset
 * @return string Full URL
 */
function pdr_asset_url($path) {
    // Remove any existing domain
    $path = preg_replace('#^https?://[^/]+#', '', $path);
    
    // Remove /wp-content/uploads/ prefix if present
    $path = str_replace('/wp-content/uploads/', '', $path);
    
    return wp_upload_dir()['baseurl'] . '/' . ltrim($path, '/');
}
