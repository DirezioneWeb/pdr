<?php
/**
 * ACF Helper Functions
 * 
 * Safe wrapper functions for ACF fields with fallbacks
 * Prevents errors if ACF is deactivated
 * 
 * @package Pietre-Rapolano
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Safe get_field with fallback
 * 
 * @param string $field Field name
 * @param mixed $post_id Post ID or false for current post
 * @param mixed $default Default value if field doesn't exist
 * @return mixed Field value or default
 */
function pdr_get_field($field, $post_id = false, $default = '') {
    if (!function_exists('get_field')) {
        return $default;
    }
    
    $value = get_field($field, $post_id);
    return ($value !== false && $value !== null) ? $value : $default;
}

/**
 * Safe get_sub_field with fallback
 * 
 * @param string $field Field name
 * @param mixed $default Default value if field doesn't exist
 * @return mixed Field value or default
 */
function pdr_get_sub_field($field, $default = '') {
    if (!function_exists('get_sub_field')) {
        return $default;
    }
    
    $value = get_sub_field($field);
    return ($value !== false && $value !== null) ? $value : $default;
}

/**
 * Safe have_rows check
 * 
 * @param string $field Field name
 * @param mixed $post_id Post ID or false for current post
 * @return bool
 */
function pdr_have_rows($field, $post_id = false) {
    if (!function_exists('have_rows')) {
        return false;
    }
    
    return have_rows($field, $post_id);
}

/**
 * Safe the_row wrapper
 * 
 * @return bool
 */
function pdr_the_row() {
    if (!function_exists('the_row')) {
        return false;
    }
    
    return the_row();
}

/**
 * Safe get_row_layout wrapper
 * 
 * @return string|false
 */
function pdr_get_row_layout() {
    if (!function_exists('get_row_layout')) {
        return false;
    }
    
    return get_row_layout();
}

/**
 * Get ACF image with safe fallback
 * 
 * @param string $field Field name
 * @param mixed $post_id Post ID or false for current post
 * @param string $size Image size
 * @return array|false Image array or false
 */
function pdr_get_image($field, $post_id = false, $size = 'full') {
    $image = pdr_get_field($field, $post_id, false);
    
    if (!$image || !is_array($image)) {
        return false;
    }
    
    // Ensure required keys exist
    $defaults = array(
        'url' => '',
        'alt' => '',
        'title' => '',
        'width' => 0,
        'height' => 0,
    );
    
    return wp_parse_args($image, $defaults);
}

/**
 * Output ACF image tag safely
 * 
 * @param string $field Field name
 * @param mixed $post_id Post ID or false for current post
 * @param string $size Image size
 * @param array $attr Additional attributes
 * @return string Image HTML or empty string
 */
function pdr_image_tag($field, $post_id = false, $size = 'full', $attr = array()) {
    $image = pdr_get_image($field, $post_id, $size);
    
    if (!$image) {
        return '';
    }
    
    $defaults = array(
        'src' => $image['url'],
        'alt' => $image['alt'],
        'title' => $image['title'],
        'loading' => 'lazy',
        'class' => '',
    );
    
    $attr = wp_parse_args($attr, $defaults);
    
    $html = '<img';
    foreach ($attr as $name => $value) {
        if ($value) {
            $html .= ' ' . esc_attr($name) . '="' . esc_attr($value) . '"';
        }
    }
    $html .= ' />';
    
    return $html;
}

/**
 * Check if ACF is active
 * 
 * @return bool
 */
function pdr_is_acf_active() {
    return function_exists('get_field');
}

/**
 * Get ACF repeater count safely
 * 
 * @param string $field Field name
 * @param mixed $post_id Post ID or false for current post
 * @return int Count of repeater rows
 */
function pdr_get_repeater_count($field, $post_id = false) {
    if (!function_exists('get_field')) {
        return 0;
    }
    
    $rows = get_field($field, $post_id);
    
    if (!is_array($rows)) {
        return 0;
    }
    
    return count($rows);
}
