<?php
/**
 * Custom Queries with Caching
 * 
 * Optimized query functions for products, posts, and projects
 * Implements transient caching to reduce database load
 * 
 * @package Pietre-Rapolano
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Get translated term ID for WPML
 * 
 * @param int $term_id Original term ID
 * @param string $taxonomy Taxonomy name
 * @return int Translated term ID
 */
function pdr_get_translated_term_id($term_id, $taxonomy = 'product_cat') {
    if (function_exists('apply_filters')) {
        $translated_id = apply_filters('wpml_object_id', $term_id, $taxonomy, true);
        return $translated_id ? (int) $translated_id : (int) $term_id;
    }
    return (int) $term_id;
}

/**
 * Order product IDs by category hierarchy with caching
 * 
 * @param array $matched_ids Array of product IDs to order
 * @return array Ordered product IDs
 */
function pdr_order_ids_by_category_hierarchy($matched_ids) {
    
    if (empty($matched_ids) || !is_array($matched_ids)) {
        return $matched_ids;
    }
    
    // Try to get from cache first
    $cache_key = 'pdr_ordered_ids_' . md5(serialize($matched_ids));
    $cached = get_transient($cache_key);
    
    if (false !== $cached && is_array($cached)) {
        return $cached;
    }
    
    /**
     * Category order - Italian IDs (WPML default language)
     */
    $category_order_it = [
        82,  // lavabi-da-bagno
        147, // lavelli-da-cucina
        123, // mosaici
        143, // pavimenti-e-rivestimenti
        153, // piatti-doccia
        211, // vasche
        90,  // accessori-da-bagno
    ];
    
    // Translate IDs to current language
    $category_order = array_map(function ($term_id) {
        return pdr_get_translated_term_id($term_id, 'product_cat');
    }, $category_order_it);
    
    $ordered = [];
    $matched_map = array_flip($matched_ids);
    
    // Order by category
    foreach ($category_order as $cat_id) {
        foreach ($matched_ids as $product_id) {
            if (
                isset($matched_map[$product_id]) &&
                has_term($cat_id, 'product_cat', $product_id)
            ) {
                $ordered[] = $product_id;
                unset($matched_map[$product_id]);
            }
        }
    }
    
    // Add remaining products (not in hierarchy)
    if (!empty($matched_map)) {
        foreach ($matched_ids as $product_id) {
            if (isset($matched_map[$product_id])) {
                $ordered[] = $product_id;
            }
        }
    }
    
    // Cache for 1 hour
    set_transient($cache_key, $ordered, HOUR_IN_SECONDS);
    
    return $ordered;
}

/**
 * Get blog posts for homepage with caching
 * 
 * @param int $posts_per_page Number of posts to retrieve
 * @return WP_Query Query object
 */
function pdr_get_homepage_posts($posts_per_page = 16) {
    $current_language = apply_filters('wpml_current_language', null);
    $cache_key = 'pdr_blog_posts_home_' . $current_language . '_' . $posts_per_page;
    
    // Try cache first
    $cached_ids = get_transient($cache_key);
    
    if (false !== $cached_ids && is_array($cached_ids)) {
        // Return query with cached IDs
        return new WP_Query([
            'post_type' => 'post',
            'post__in' => $cached_ids,
            'orderby' => 'post__in',
            'posts_per_page' => $posts_per_page,
        ]);
    }
    
    // Fresh query
    $args = [
        'post_type' => 'post',
        'posts_per_page' => $posts_per_page,
        'fields' => 'ids',
        'language' => $current_language,
    ];
    
    $query = new WP_Query($args);
    $post_ids = $query->posts;
    
    // Cache post IDs for 30 minutes
    set_transient($cache_key, $post_ids, 30 * MINUTE_IN_SECONDS);
    
    wp_reset_postdata();
    
    // Return full query
    return new WP_Query([
        'post_type' => 'post',
        'post__in' => $post_ids,
        'orderby' => 'post__in',
        'posts_per_page' => $posts_per_page,
    ]);
}

/**
 * Get related posts with caching
 * 
 * @param int $post_id Current post ID
 * @param int $posts_per_page Number of posts to retrieve
 * @return WP_Query Query object
 */
function pdr_get_related_posts($post_id, $posts_per_page = 3) {
    $cache_key = 'pdr_related_posts_' . $post_id;
    $cached_ids = get_transient($cache_key);
    
    if (false !== $cached_ids && is_array($cached_ids)) {
        return new WP_Query([
            'post_type' => 'post',
            'post__in' => $cached_ids,
            'orderby' => 'post__in',
            'posts_per_page' => $posts_per_page,
        ]);
    }
    
    // Get categories of current post
    $categories = wp_get_post_categories($post_id);
    
    if (empty($categories)) {
        return new WP_Query(['post__in' => [0]]); // Empty query
    }
    
    $args = [
        'post_type' => 'post',
        'posts_per_page' => $posts_per_page,
        'post__not_in' => [$post_id],
        'category__in' => $categories,
        'orderby' => 'rand',
        'fields' => 'ids',
    ];
    
    $query = new WP_Query($args);
    $post_ids = $query->posts;
    
    // Cache for 1 hour
    set_transient($cache_key, $post_ids, HOUR_IN_SECONDS);
    
    wp_reset_postdata();
    
    // Return full query
    return new WP_Query([
        'post_type' => 'post',
        'post__in' => $post_ids,
        'orderby' => 'post__in',
        'posts_per_page' => $posts_per_page,
    ]);
}

/**
 * Get progetti (projects) with caching
 * 
 * @param array $args Query arguments
 * @return WP_Query Query object
 */
function pdr_get_progetti($args = []) {
    $defaults = [
        'post_type' => 'progetto',
        'posts_per_page' => 12,
        'orderby' => 'date',
        'order' => 'DESC',
    ];
    
    $args = wp_parse_args($args, $defaults);
    $cache_key = 'pdr_progetti_' . md5(serialize($args));
    
    $cached_ids = get_transient($cache_key);
    
    if (false !== $cached_ids && is_array($cached_ids)) {
        $args['post__in'] = $cached_ids;
        $args['orderby'] = 'post__in';
        unset($args['fields']);
        return new WP_Query($args);
    }
    
    // Fresh query
    $temp_args = $args;
    $temp_args['fields'] = 'ids';
    
    $query = new WP_Query($temp_args);
    $post_ids = $query->posts;
    
    // Cache for 1 hour
    set_transient($cache_key, $post_ids, HOUR_IN_SECONDS);
    
    wp_reset_postdata();
    
    // Return full query
    $args['post__in'] = $post_ids;
    $args['orderby'] = 'post__in';
    
    return new WP_Query($args);
}

/**
 * Get WooCommerce cross-sells with limit
 * Optimized version of cart cross-sells
 * 
 * @param int $limit Number of products to show
 * @return array Product IDs
 */
function pdr_get_cross_sells($limit = 4) {
    if (!function_exists('WC') || !WC()->cart) {
        return [];
    }
    
    $cross_sell_ids = WC()->cart->get_cross_sells();
    
    if (empty($cross_sell_ids)) {
        return [];
    }
    
    // Limit results
    return array_slice($cross_sell_ids, 0, $limit);
}
