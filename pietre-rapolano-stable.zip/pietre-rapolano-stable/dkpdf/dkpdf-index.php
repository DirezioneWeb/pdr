<?php
/**
* dkpdf-index.php
* This template is used to display the content in the PDF
*
* Do not edit this template directly,
* copy this template and paste in your theme inside a directory named dkpdf
*/
?>

<html>
    <head>
        <?php // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet ?>
      	<link type="text/css" rel="stylesheet" href="<?php echo esc_url(get_bloginfo( 'stylesheet_url' )); ?>" media="all" />
      	<?php
      		$wp_head = get_option( 'dkpdf_print_wp_head', '' );
      		if( $wp_head == 'on' ) {
      			wp_head();
      		}
      	?>
      	<style type="text/css">
      		body {
      			background:#FFF;
      			font-size: 100%;
      		}
          /* fontawesome compatibility */
          .fa {
              font-family: fontawesome;
              display: inline-block;
              font: normal normal normal 14px/1 FontAwesome;
              font-size: inherit;
              text-rendering: auto;
              -webkit-font-smoothing: antialiased;
              -moz-osx-font-smoothing: grayscale;
              transform: translate(0, 0);
          }

			<?php
				// get pdf custom css option
				$css = get_option( 'dkpdf_pdf_custom_css', '' );
				echo $css;
			?>

		</style>

   	</head>

     <body>

	    <?php

	    global $post;
	    $pdf  = get_query_var( 'pdf' );
	    $post_type = get_post_type( $pdf );

	    // if is attachment
	    if( $post_type == 'attachment') { ?>

	    	<div style="width:100%;float:left;">

	    		<?php
	    			// image
	    			$image = wp_get_attachment_image( $post->ID, 'full' );

	    			if( $image ) {

	    				echo $image;

	    			}

	    		?>

	    		<?php
	    			// caption, description
		    		$thumb_img = get_post( get_post_thumbnail_id() );

		    		if( $thumb_img ) {

						echo '<p style="margin-top:30px;">Caption: ' . $thumb_img->post_excerpt .'</p>';
						echo '<p>Description: ' . $thumb_img->post_content .'</p>';

		    		}

	    		?>

	    		<?php
	    			// metadata
	    			$metadata =  wp_get_attachment_metadata( $post->ID );

	    			if( $metadata ) {

	    				$metadata_width = $metadata['width'];
	    				$metadata_height = $metadata['height'];
	    				$image_meta = $metadata['image_meta'];

	    				echo '<p style="margin-top:30px;">Dimensions: '. $metadata_width .' x '. $metadata_height .'</p>';

	    				// image metadata
	    				foreach ($image_meta as $key => $value) {

	    				 	echo $key. ': '. $value .'<br>';

	    				}

	    			}

	    		?>

	    	</div>

	    	<?php

	    } else {

  			$args = array(
  			 	'p' => $pdf,
  			 	'post_type' => $post_type,
  			 	'post_status' => 'publish'
  			);

		    $the_query = new WP_Query( apply_filters( 'dkpdf_query_args', $args ) );

		    if ( $the_query->have_posts() ) {

		    	while ( $the_query->have_posts() ) {
		    	    $the_query->the_post();
		    	    global $post;
		    	    global $product;
    	    		//the_content(); 
    	    		$short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt );
		    	    ?>

		    	    <div class="dkpdf-content">
		    	    	<h2>
		    	    		<?php 
		    	    			echo get_the_title();
		    	    		?>
		    	    	</h2>
		    	    	<div class="image_pdf">
		    	    		<?php 
		    	    			the_post_thumbnail( 'large' );
		    	    		?>
		    	    	</div>
		    	    	<p>
		    	    		<?php 
		    	    			echo $short_description;
		    	    		?>
		    	    	</p>
						<hr/>
		    	    
		    	    	<?php 
		    	    		

		    	    		$peso = wc_format_weight($product->get_weight());
		    	    		$dimensioni =  wc_format_dimensions($product->get_dimensions(false));
		    	    		$trattamento = $product->get_attribute( 'trattamento' );
		    	    		$formato = $product->get_attribute( 'formati-disponibili' );
		    	    		$finitura = $product->get_attribute( 'finitura' );
		    	    		$trattamento = $product->get_attribute( 'trattamento' );
		    	    		$imballo = $product->get_attribute( 'imballo' );
		    	    		
							$pulizia = $product->get_attribute( 'pulizia' );
							$trattamento = $product->get_attribute( 'trattamento' );


		    	    		if($dimensioni):
		    	    			echo '<div class="pdr_tab_value">';
		    	    			echo '<h3>'. __('Dimensioni', 'pdr') .'</h3><p>' . $dimensioni . '</p>';
		    	    			echo '</div>';
		    	    		endif;

		    	    		if($product->has_weight()):
		    	    			echo '<div class="pdr_tab_value">';
		    	    			echo '<h3>'. __('Peso', 'pdr') .'</h3><p>' . $peso . '</p>';
		    	    			echo '</div>';
		    	    		endif;


		    	    		if($formato):
		    	    			echo '<div class="pdr_tab_value">';
		    	    			echo '<h3>'. __('Formato', 'pdr') .'</h3><p>' . $formato . '</p>';
		    	    			echo '</div>';
		    	    		endif;


		    	    		if($finitura):
		    	    			echo '<div class="pdr_tab_value">';
		    	    			echo '<h3>'. __('Finitura', 'pdr') .'</h3><p>' . $finitura . '</p>';
		    	    			echo '</div>';
		    	    		endif;

		    	    		if($imballo):
		    	    			echo '<div class="pdr_tab_value">';
		    	    			echo '<h3>'. __('Dimensioni imballo/scatola', 'pdr') .'</h3><p>' . $imballo . '</p>';
		    	    			echo '</div>';
		    	    		endif;

							if($pulizia):
								echo '<div class="pdr_tab_value">';
								echo '<h3>'. __('Pulizia', 'pdr') .'</h3><p>' . $pulizia . '</p>';
								echo '</div>';
							endif;

							if($trattamento):
								echo '<div class="pdr_tab_value">';
								echo '<h3>'. __('Trattamento', 'pdr') .'</h3><p>' . $trattamento . '</p>';
								echo '</div>';
							endif;

		    	    	?>

		    	    	<p style="font-size: 12px;">
		    	    		<span>
		    	    		<?php 
		    	    			echo __('Questo pdf è stato generato dalla pagina: ', 'pdr');
		    	    		?>		    	    			
		    	    		</span>		    	    		
		    	    		<span>
		    	    		<?php 
		    	    			echo get_the_permalink( $post );
		    	    		?>	
		    	    		</span>
		    	    	</p>

		    		</div>

		    	<?php }

		    } else {

		    	echo 'no results';
		    }

		    wp_reset_postdata();

	    }

		?>

    </body>

</html>
