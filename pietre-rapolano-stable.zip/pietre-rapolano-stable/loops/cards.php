<?php 
/*
This loop is used in the Archive and in the Home [.php] templates.
*/
?>
<div class="col-md-4 col-sm-6 py-2">
  <div class="article-card" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>');">
              <div class="article-overlay">
                <div class="article-category">
                  <?php
                  $category = get_the_category();
                  if ($category) {
                    echo esc_html($category[0]->name);
                  }
                  ?>
                </div>
                <div class="article-title">
                  <?php the_title(); ?>
                </div>
                <div class="article-bottom">
                  <span class="article-date">
                    <?php echo get_the_date('j F Y'); ?>
                  </span>
                  <a href="<?php the_permalink(); ?>" class="article-link"><?php _e( 'Leggi di più', 'pietre-rapolano' ); ?></a>
                </div>
              </div>
            </div>
</div>