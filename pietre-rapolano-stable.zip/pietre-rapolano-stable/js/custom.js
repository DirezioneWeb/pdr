// to enable the enqueue of this optional JS file, 
// you'll have to uncomment a row in the functions.php file
// just read the comments in there mate

console.log("Custom js file loaded");

//add here your own js code. Vanilla JS welcome.

  document.getElementById('openSearchOverlay').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('searchOverlay').style.display = 'flex';
    document.querySelector('.search-input').focus();
  });

  document.getElementById('closeSearchOverlay').addEventListener('click', function () {
    document.getElementById('searchOverlay').style.display = 'none';
  });

  // Chiudi con ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.getElementById('searchOverlay').style.display = 'none';
    }
  });

document.addEventListener('DOMContentLoaded', function () {
    const openBtn = document.getElementById('openMenuSearchModal');
    const closeBtn = document.getElementById('closeMenuSearchModal');
    const modal = document.getElementById('menuSearchModal');

    if (openBtn && modal) {
        openBtn.addEventListener('click', function (e) {
            e.preventDefault();
            modal.classList.add('active');

            // focus input se presente
            const input = modal.querySelector('input');
            if (input) setTimeout(() => input.focus(), 150);
        });
    }

    if (closeBtn && modal) {
        closeBtn.addEventListener('click', function () {
            modal.classList.remove('active');
        });
    }

    if (modal) {
        modal.addEventListener('click', function (e) {
            if (e.target === this) modal.classList.remove('active');
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && modal) modal.classList.remove('active');
    });
});

