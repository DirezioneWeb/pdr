<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();


// Loop through posts if there are any
if (have_posts()):
    while (have_posts()): the_post(); ?>

        <section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center"><small><?php the_title(); ?></small></h1>
				<div class="extender-mini my-3 mx-auto"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
				}
				?>
				
				<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
        
    
    <div id="container-content-single" class="container position-relative p-5 bg-body text-body-emphasis" >
        
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <?php 
                
                the_content();
                
                if( get_theme_mod("enable_sharing_buttons")) picostrap_the_sharing_buttons();
                
                edit_post_link( __( 'Edit this post', 'picostrap5' ), '<p class="text-end">', '</p>' );
                
                // If comments are open or we have at least one comment, load up the comment template.
                if (!get_theme_mod("singlepost_disable_comments")) if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }
                
                ?>

            </div><!-- /col -->
        </div>
    </div>

<?php
    endwhile;
 else :
     _e( 'Sorry, no posts matched your criteria.', 'picostrap5' );
 endif;
 ?>


 

<?php get_footer();
