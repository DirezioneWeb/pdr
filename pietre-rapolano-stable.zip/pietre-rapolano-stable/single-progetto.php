<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

get_header();


// Loop through posts if there are any
if (have_posts()):
	while (have_posts()): the_post(); ?>

		<?php
		// Recupera l'URL dell'immagine dal campo ACF 'immagine_testata'
		$immagine_testata_url = get_field('immagine_testata');
		$head_style = '';
		if ($immagine_testata_url) {
			$head_style = "position: relative; background: url('{$immagine_testata_url}') no-repeat right center / cover #f8f9fa;padding-top: 100px;overflow: visible !important;";
		}
		?>
		<section id="head" class="bg-light head-progetti" style="<?php echo esc_attr($head_style); ?>">
			<?php if ($immagine_testata_url): ?>
				<div style="
			position: absolute;
			inset: 0;
			pointer-events: none;
			background: linear-gradient(180deg,rgba(0, 0, 0, 0.4) 0%, rgba(102, 102, 102, 0) 100%), linear-gradient(to right, #f5f5f5 55%, transparent 100%);
			backdrop-filter: blur(2px);
			z-index: 1;
			
		"></div>
			<?php endif; ?>
			<div class="container px-xl-3">
				<div class="row">
					<div class="col-lg-6 my-auto">
						<p class="tag-progetto"><strong><?php _e( 'PROGETTO', 'pietre-rapolano' ); ?></strong></p>
						<h1 class="page-title"><?php the_title(); ?></h1>
						<div class="d-flex blocco-desktop" id="riga-dati">
							<p class="uppercase"><?php echo (get_field('titolo_blocco_1')); ?> <strong><?php echo (get_field('valore_blocco_1')); ?></strong></p>
							<p class="mx-4 uppercase"><strong><?php _e( 'ANNO', 'pietre-rapolano' ); ?></strong> <?php echo (get_field('valore_blocco_3')); ?></p>
							<p class="mx-4 uppercase"><strong><?php echo (get_field('valore_blocco_2')); ?></strong></p>
						</div>
						<?php
						if (function_exists('yoast_breadcrumb')) {
							yoast_breadcrumb('<p class="blocco-mobile bread-about" id="breadcrumbs">', '</p>');
						}
						?>
						<div class="extender my-3" id="extender-left"></div>
						<div class="d-flex blocco-mobile" id="riga-dati">
							<p class="uppercase"><?php echo (get_field('titolo_blocco_1')); ?> <strong><?php echo (get_field('valore_blocco_1')); ?></strong></p>
							<p class="mx-4 uppercase"><strong><?php _e( 'ANNO', 'pietre-rapolano' ); ?></strong> <?php echo (get_field('valore_blocco_3')); ?></p>
							<p class="mx-4 uppercase"><strong><?php echo (get_field('valore_blocco_2')); ?></strong></p>
						</div>
						<?php
						if (function_exists('yoast_breadcrumb')) {
							yoast_breadcrumb('<p class="blocco-desktop" id="breadcrumbs">', '</p>');
						}
						?>
					</div>
					<div class="col-lg-6">
						<?php
						$prev_post = get_previous_post();
						$next_post = get_next_post(); ?>
						<div id="nav-project" class="d-flex justify-content-end align-items-start" style="position: relative;
  bottom: -20px;">
							<?php if ($next_post): ?>
								<a href="<?php echo esc_url(get_permalink($next_post->ID)); ?>" class="d-flex align-items-center text-white">
									<img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/prec.svg" alt="Precedente" style="width:42px; margin-right: 0.5em;">
									<?php _e( 'Precedente', 'pietre-rapolano' ); ?>
								</a>
								<span style="color: white;margin: 0 40px;height: 40px;border-left: 1px solid white;"></span>
							<?php endif; ?>

							<a href="<?php echo get_permalink($prev_post->ID); ?>" class="d-flex align-items-center text-white">
								<?php _e( 'Prossimo', 'pietre-rapolano' ); ?>
								<img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/succ.svg" alt="Successivo" style="width:42px; margin-left: 0.5em;">
							</a>
						</div>

						<?php
						$image_url = get_field('immagine_progetto');

						if ($image_url): ?>
							<div class="featured-image-square" style="background-image: url('<?php echo esc_url($image_url); ?>');"></div>
						<?php endif; ?>

					</div>
				</div>
			</div>
		</section>

		<section class="py-6">
			<div class="container px-xl-3">
				<div class="row align-items-stretch">
					<div class="col-lg-6 d-flex align-items-end">
						<div class="px-5 py-5 text-col" style="padding-left:0!important;">
							<h3><?php echo esc_html(get_field('titolo_1')); ?></h3>
							<?php echo wp_kses_post(get_field('testo_1')); ?>
						</div>
					</div>

					<div id="mobile-full" class="col-lg-6 d-flex justify-content-start">
						<?php
						$immagine1 = get_field('immagine_1');

						if ($immagine1):
							$image_id = attachment_url_to_postid($immagine1);
							$alt_text = $image_id ? get_post_meta($image_id, '_wp_attachment_image_alt', true) : '';
							if (empty($alt_text)) {
								$alt_text = get_the_title();
							}
						?>

							<div
								class="immagine1-wrapper"
								id="mobile-full"
								role="img"
								aria-label="<?php echo esc_attr($alt_text); ?>"
								style="
				background: url('<?php echo esc_url($immagine1); ?>') center center / cover no-repeat;
				width: 400px;
				height: 400px;
				transition: all 0.3s ease;
				align-self: flex-start;
			">
							</div>

						<?php endif; ?>
					</div>
				</div>

				<script>
					document.addEventListener("DOMContentLoaded", function() {
						const textCol = document.querySelector('.text-col');
						const imgWrapper = document.querySelector('.immagine1-wrapper');

						if (textCol && imgWrapper) {
							const textHeight = textCol.offsetHeight;
							if (textHeight > 400) {
								imgWrapper.style.width = textHeight + 'px';
								imgWrapper.style.height = textHeight + 'px';
							}
						}
					});
				</script>


			</div>
		</section>
		<section id="progetto" class="py-5">
			<div class="container px-xl-3">
				<div class="row equal-height flex-column-reverse flex-lg-row">
					<div class="col-lg-6 p-0">
						<?php
						$gallery = get_field('immagini_progetto');
						$second_image = (is_array($gallery) && isset($gallery[1])) ? $gallery[1] : null;

						if (!empty($second_image)):
							$image_url = esc_url($second_image['url']);
							$image_alt = esc_attr($second_image['alt']);
						?>
							<div
								class="image-column"
								role="img"
								aria-label="<?php echo $image_alt; ?>"
								style="background-image: url('<?php echo $image_url; ?>');">
							</div>
						<?php endif; ?>
					</div>

					<div class="col-lg-6 d-flex">
						<div class="text-col px-5 my-auto w-100">
							<h3><?php echo esc_html(get_field('titolo_2')); ?></h3>
							<?php echo wp_kses_post(get_field('testo_2')); ?>
						</div>
					</div>
				</div>

			</div>
		</section>
		<section class="py-5">
			<div class="container px-xl-3">
				<div class="row equal-height">
					<div class="col-lg-6 d-flex">
						<div class="text-col px-5 my-auto w-100">
							<h3><?php echo esc_html(get_field('titolo_3')); ?></h3>
							<?php echo wp_kses_post(get_field('testo_3')); ?>
						</div>
					</div>

					<div class="col-lg-6 p-0">
						<?php
						$gallery = get_field('immagini_progetto');
						$six_image = (is_array($gallery) && isset($gallery[6])) ? $gallery[6] : null;

						if (!empty($six_image)):
							$image_url = esc_url($six_image['url']);
							$image_alt = esc_attr($six_image['alt']);
						?>
							<div
								class="image-column"
								role="img"
								aria-label="<?php echo $image_alt; ?>"
								style="background-image: url('<?php echo $image_url; ?>');">
							</div>
						<?php endif; ?>
					</div>
				</div>

			</div>
		</section>
		<?php if (get_field('titolo_4')) : ?>
		<section class="py-5">
			<div class="container px-xl-3">
				<div class="row equal-height">
					

					<div class="col-lg-6 p-0">
						<?php
						$gallery = get_field('immagini_progetto');
						$six_image = (is_array($gallery) && isset($gallery[2])) ? $gallery[2] : null;

						if (!empty($six_image)):
							$image_url = esc_url($six_image['url']);
							$image_alt = esc_attr($six_image['alt']);
						?>
							<div
								class="image-column"
								role="img"
								aria-label="<?php echo $image_alt; ?>"
								style="background-image: url('<?php echo $image_url; ?>');">
							</div>
						<?php endif; ?>
					</div>
					<div class="col-lg-6 d-flex">
						<div class="text-col px-5 my-auto w-100">
							<h3><?php echo esc_html(get_field('titolo_4')); ?></h3>
							<?php echo wp_kses_post(get_field('testo_4')); ?>
						</div>
					</div>
				</div>

			</div>
		</section>
		<?php endif; ?>
		<?php if (get_field('titolo_5')) : ?>
		<section class="py-5">
			<div class="container px-xl-3">
				<div class="row equal-height">
					<div class="col-lg-6 d-flex">
						<div class="text-col px-5 my-auto w-100">
							<h3><?php echo esc_html(get_field('titolo_5')); ?></h3>
							<?php echo wp_kses_post(get_field('testo_5')); ?>
						</div>
					</div>

					<div class="col-lg-6 p-0">
						<?php
						$gallery = get_field('immagini_progetto');
						$six_image = (is_array($gallery) && isset($gallery[10])) ? $gallery[10] : null;

						if (!empty($six_image)):
							$image_url = esc_url($six_image['url']);
							$image_alt = esc_attr($six_image['alt']);
						?>
							<div
								class="image-column"
								role="img"
								aria-label="<?php echo $image_alt; ?>"
								style="background-image: url('<?php echo $image_url; ?>');">
							</div>
						<?php endif; ?>
					</div>
					
				</div>

			</div>
		</section>
		<?php endif; ?>
		<?php if (get_field('titolo_6')) : ?>
		<section class="py-5">
			<div class="container px-xl-3">
				<div class="row equal-height">
					

					<div class="col-lg-6 p-0">
						<?php
						$gallery = get_field('immagini_progetto');
						$six_image = (is_array($gallery) && isset($gallery[12])) ? $gallery[12] : null;

						if (!empty($six_image)):
							$image_url = esc_url($six_image['url']);
							$image_alt = esc_attr($six_image['alt']);
						?>
							<div
								class="image-column"
								role="img"
								aria-label="<?php echo $image_alt; ?>"
								style="background-image: url('<?php echo $image_url; ?>');">
							</div>
						<?php endif; ?>
					</div>
					<div class="col-lg-6 d-flex">
						<div class="text-col px-5 my-auto w-100">
							<h3><?php echo esc_html(get_field('titolo_6')); ?></h3>
							<?php echo wp_kses_post(get_field('testo_6')); ?>
						</div>
					</div>
				</div>

			</div>
		</section>
		<?php endif; ?>
		<section id="gallery-progetto" class="bg-grey py-5">
			<div class="container-fluid px-xl-3">
				<div class="row">
					<div id="mobile-full" class="col-lg-12">
						<h3 class="text-center py-5"><?php _e( 'Idee e spunti: gallery del progetto', 'pietre-rapolano' ); ?></h3>
						<hr class="divider my-3 mx-auto" />
						<?php
						$gallery = get_field('immagini_progetto');
						if ($gallery && is_array($gallery)) :
							$slide_count = count($gallery);
						?>
							<div id="gallerySplide" class="py-5 splide custom-splide" aria-label="Gallery Carousel">
								<div class="splide__track">
									<ul class="splide__list">
										<?php foreach ($gallery as $img): ?>
											<li class="splide__slide text-center">
												<a
													href="<?php echo esc_url($img['url']); ?>"
													data-bs-toggle="modal"
													data-bs-target="#lightboxModal"
													data-bs-img="<?php echo esc_url($img['url']); ?>"
													data-bs-caption="<?php echo esc_attr($img['caption']); ?>"
													class="gallery-img-link position-relative d-inline-block"
													style="overflow:visible;">
													<!-- Zoom Icon -->
													<span class="zoom-icon" style="
											position: absolute;
											top: 16px;
											right: 16px;
											z-index: 2;
											display: none;
											transition: opacity 0.2s;
										">
														<img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/mage_zoom-in.svg" alt="Zoom" style="width:38px;height:38px;">
													</span>
													<img
														src="<?php echo esc_url($img['url']); ?>"
														alt="<?php echo esc_attr($img['alt']); ?>"
														class="img-fluid mb-3"
														style="width:380px; height:530px; object-fit:cover;">
												</a>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
							</div>

							<!-- PAGINAZIONE CUSTOM SLIDE -->
							<?php
							$group_size = 5;
							$page_count = ceil($slide_count / $group_size);
							?>
							<div class="splide-pagination-custom mt-3 d-flex flex-column align-items-center">
								<div class="d-flex align-items-center justify-content-center">
									<button class="splide-arrow-custom prev" aria-label="Precedente">&larr;</button>
									<?php for ($i = 1; $i <= $page_count; $i++): ?>
										<span class="splide-page-num<?php if ($i == 1) echo ' active'; ?>"><?php echo sprintf('%02d', $i); ?></span>
									<?php endfor; ?>
									<button class="splide-arrow-custom next" aria-label="Successivo">&rarr;</button>
								</div>
							</div>

							<!-- Bootstrap Lightbox Modal -->
							<div class="modal fade" id="lightboxModal" tabindex="-1" aria-labelledby="lightboxModalLabel" aria-hidden="true">
								<button type="button" class="btn btn-light position-absolute top-50 start-20 translate-middle-y ms-2" id="lightboxPrev" style="z-index:10;">&#8592;</button>
								<button type="button" class="btn btn-light position-absolute top-50 end-20 translate-middle-y me-2" id="lightboxNext" style="z-index:10;">&#8594;</button>
								<div class="modal-dialog modal-dialog-centered modal-lg">
									<div class=" bg-transparent border-0" style="width: 100%;">
										<div class="modal-body p-0 text-center">
											<img src="" id="lightboxImage" class="img-fluid" style="max-width:100%; max-height:80vh;" alt="">
											<p id="lightboxCaption" class="mt-3 text-light"></p>
										</div>
										<button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
									</div>
								</div>
							</div>

							<script>
								document.addEventListener('DOMContentLoaded', function() {
									var splide = new Splide('#gallerySplide', {
										type: 'loop',
										perPage: 5,
										perMove: 1,
										gap: '1rem',
										autoplay: true,
										interval: 5000,
										pauseOnHover: true,
										arrows: false,
										pagination: false,
										breakpoints: {
											1400: {
												perPage: 4
											},
											1200: {
												perPage: 3
											},
											992: {
												perPage: 2
											},
											768: {
												perPage: 1
											}
										}
									}).mount();

									// Custom arrows
									document.querySelector('.splide-arrow-custom.prev').addEventListener('click', function() {
										splide.go('<');
									});
									document.querySelector('.splide-arrow-custom.next').addEventListener('click', function() {
										splide.go('>');
									});

									// Custom page numbers
									var pageNums = document.querySelectorAll('.splide-page-num');
									pageNums.forEach(function(num, idx) {
										num.addEventListener('click', function() {
											splide.go(idx);
										});
									});
									splide.on('move', function(newIndex) {
										var total = pageNums.length;
										var realIndex = (newIndex % total + total) % total;
										pageNums.forEach(function(num, idx) {
											num.classList.toggle('active', idx === realIndex);
										});
									});

									// Bootstrap Lightbox
									var lightboxModal = document.getElementById('lightboxModal');
									var lightboxImage = document.getElementById('lightboxImage');
									var lightboxCaption = document.getElementById('lightboxCaption');
									var currentImageIndex = 0;
									var galleryImages = [];

									document.querySelectorAll('#gallerySplide a[data-bs-toggle="modal"]').forEach(function(link, index) {
										galleryImages.push({
											src: link.getAttribute('data-bs-img'),
											caption: link.getAttribute('data-bs-caption') || ''
										});

										link.addEventListener('click', function(e) {
											currentImageIndex = index;
											updateLightboxImage();
										});
									});

									document.getElementById('lightboxPrev').addEventListener('click', function() {
										currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
										updateLightboxImage();
									});

									document.getElementById('lightboxNext').addEventListener('click', function() {
										currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
										updateLightboxImage();
									});

									function updateLightboxImage() {
										lightboxImage.src = galleryImages[currentImageIndex].src;
										lightboxCaption.textContent = galleryImages[currentImageIndex].caption;
									}

									// Clear image on close
									lightboxModal.addEventListener('hidden.bs.modal', function() {
										lightboxImage.src = '';
										lightboxCaption.textContent = '';
									});

									// Show zoom icon on hover
									document.querySelectorAll('.gallery-img-link').forEach(function(link) {
										link.addEventListener('mouseenter', function() {
											var icon = this.querySelector('.zoom-icon');
											if (icon) icon.style.display = 'block';
										});
										link.addEventListener('mouseleave', function() {
											var icon = this.querySelector('.zoom-icon');
											if (icon) icon.style.display = 'none';
										});
									});
								});
							</script>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section>
<?php if(get_field('prodotti_progetto')) : ?>
		<section id="prodotti-progetto" class="py-6">
			<div class="container px-xl-3">
				<div class="row">
					<div class="col-lg-12">
						<h3 class="text-center"><?php _e( 'Scopri i nostri prodotti', 'pietre-rapolano' ); ?></h3>
						<p class="text-center"><?php _e( 'SCEGLI IL PRODOTTO E CALCOLA IL PREVENTIVO', 'pietre-rapolano' ); ?></p>
						<div class="clearx2"></div>
						<hr class="divider my-3 mx-auto">
						<div class="clearx2"></div>
						<?php
						$prodotti = get_field('prodotti_progetto');
						if ($prodotti && is_array($prodotti)) :
							$prodotti_count = count($prodotti);
						?>
							<div
								id="prodottiSplide"
								class="<?php echo ($prodotti_count >= 6) ? 'splide custom-splide' : 'custom-splide-static'; ?>"
								aria-label="Prodotti Carousel">
								<div class="splide__track">
									<ul class="splide__list d-flex flex-wrap justify-content-center gap-4">
										<?php foreach ($prodotti as $prodotto) :
											$prodotto_id = $prodotto->ID;
											$img_url = get_the_post_thumbnail_url($prodotto_id, 'full');
											$titolo = get_the_title($prodotto_id);
											$link = get_permalink($prodotto_id);
										?>
											<li class="splide__slide text-center" style="flex: 0 0 auto;">
												<?php if ($img_url): ?>
													<a href="<?php echo esc_url($link); ?>">
														<img
															src="<?php echo esc_url($img_url); ?>"
															alt="<?php echo esc_attr($titolo); ?>"
															class="img-fluid mb-3"
															id="img-prodotto"
															style="height:250px;width:250px;object-fit:cover;">
													</a>
												<?php endif; ?>
												<div class="prodotto-details">
													<a href="<?php echo esc_url($link); ?>" class="prodotto-title d-block mt-2" style="font-weight:600;">
														<?php echo esc_html($titolo); ?>
													</a>
												</div>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
							</div>

							<?php if ($prodotti_count >= 5): ?>
								<script>
									document.addEventListener('DOMContentLoaded', function() {
										var splide = new Splide('#prodottiSplide', {
											type: 'loop',
											perPage: 5,
											perMove: 1,
											gap: '2rem',
											autoplay: true,
											interval: 7000,
											pauseOnHover: true,
											arrows: false,
											pagination: false,
											breakpoints: {
												1200: {
													perPage: 3
												},
												768: {
													perPage: 1
												}
											}
										}).mount();
									});
								</script>
							<?php endif; ?>

						<?php endif; ?>

					</div>
				</div>
			</div>
		</section>
		<?php endif; ?>

<?php
	endwhile;
else :
	_e('Sorry, no posts matched your criteria.', 'picostrap5');
endif;
?>
<section id="cta-footer-contact" class="py-150">
	<!-- Overlay per l'effetto blur -->
	<div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center text-light"><?php _e( 'Contattaci per informazioni', 'pietre-rapolano' ); ?></h3>
				<p class="text-center text-light uppercase"><?php _e( 'o per richiedere un preventivo personalizzato', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php echo (do_shortcode('[contact-form-7 id="5fbf157" title="Modulo di contatto CTA ITA"]')); ?>
			</div>
		</div>
	</div>
</section>


<?php get_footer();
