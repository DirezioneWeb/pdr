<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header(); ?>

<?php if (is_single()) : ?>
  <style>
    #breadcrumbs a {
      color: white;
      text-decoration: underline;
    }
  </style>
<?php endif; ?>
<?php // Loop through posts if there are any
if (have_posts()):
    while (have_posts()): the_post(); ?>

<section id="head" class="bg-light position-relative"
  <?php
    $img_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
    if ($img_url) {
      echo 'style="background: url(' . esc_url($img_url) . ') center center no-repeat; background-size: cover;"';
    }
  ?>
>
  <?php if ($img_url): ?>
    <div class="bg-overlay"></div>
  <?php endif; ?>
	<div class="container px-xl-3 position-relative" style="z-index:2;">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center text-light"><?php _e( 'BLOG', 'pietre-rapolano' ); ?></h1>
				<div class="extender-mini my-3 mx-auto" style="background: #fff;"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;color: #fff;">','</p>' );
				}
				?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
    
    <div id="container-content-single" class="container position-relative p-5 bg-body text-body-emphasis" >
        <div class="row text-center mb-2">
            
            <div class="col-md-12">

                <h1 class="display-4"><?php the_title(); ?></h1>
                <div class="clear"></div>
            </div><!-- /col -->
        </div>
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <?php 
                
                the_content();
                
                if( get_theme_mod("enable_sharing_buttons")) picostrap_the_sharing_buttons();
                
                edit_post_link( __( 'Edit this post', 'picostrap5' ), '<p class="text-end">', '</p>' );
                
                // If comments are open or we have at least one comment, load up the comment template.
                if (!get_theme_mod("singlepost_disable_comments")) if ( comments_open() || get_comments_number() ) {
                    comments_template();
                }
                
                ?>

            </div><!-- /col -->
        </div>
    </div>
    
    <section>
    <div class="container-fluid">
        <div class="extender-mini my-3 mx-auto"></div>
        <div class="row">
            <h4 class="text-center"><?php _e( 'ARTICOLI CORRELATI', 'pietre-rapolano' ); ?></h4>
            <div class="clear"></div>
        </div>

        <?php
        $categories = get_the_category();
        if ( $categories ) {
            $category_id = $categories[0]->term_id;

            $related_args = array(
                'category__in'         => array( $category_id ),
                'post__not_in'         => array( get_the_ID() ),
                'posts_per_page'       => 4,
                'ignore_sticky_posts'  => 1,
            );
            $related_query = new WP_Query( $related_args );

            if ( $related_query->have_posts() ) : ?>
                <div class="row" id="related-articles-row">
                    <?php while ( $related_query->have_posts() ) : $related_query->the_post(); ?>
                        <div class="related-article-item col-sm-6 col-md-4 col-lg-4 mb-4">
                            <div class="article-card" style="background-image: url('<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'full' ) ); ?>');min-height: 650px;">
                                <div class="article-overlay">
                                    <div class="article-category">
                                        <?php
                                        $category = get_the_category();
                                        if ( $category ) {
                                            echo esc_html( $category[0]->name );
                                        }
                                        ?>
                                    </div>
                                    <div class="article-title">
                                        <?php the_title(); ?>
                                    </div>
                                    <div class="article-bottom">
                                        <span class="article-date">
                                            <?php echo get_the_date( 'j F Y' ); ?>
                                        </span>
                                        <a href="<?php the_permalink(); ?>" class="article-link"><?php _e( 'Leggi di più', 'pietre-rapolano' ); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php
            endif;
            wp_reset_postdata();
        }
        ?>
    </div>
</section>

<style>
    /* Default: da 768px a 1799.98px = 3 articoli per riga (33.33%) */
    #related-articles-row .related-article-item {
        flex: 0 0 33.3333%;
        max-width: 33.3333%;
        display: block;
    }

    /* Sotto 768px: 2 articoli per riga (50%) */
    @media (max-width: 767.98px) {
        #related-articles-row .related-article-item {
            flex: 0 0 50%;
            max-width: 50%;
        }
    }

    /* Sopra 1800px: 4 articoli per riga (25%) */
    @media (min-width: 1800px) {
        #related-articles-row .related-article-item {
            flex: 0 0 25%;
            max-width: 25%;
        }
    }
</style>

			    

<?php
    endwhile;
 else :
     _e( 'Sorry, no posts matched your criteria.', 'picostrap5' );
 endif;
 ?>


 

<?php get_footer();
