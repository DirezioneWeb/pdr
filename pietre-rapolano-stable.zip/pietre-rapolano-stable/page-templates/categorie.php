<?php

/**
 * Template Name: Category Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

get_header();

if (have_posts()) :
    while (have_posts()) : the_post(); ?>

        <?php
        // Recupera l'URL dell'immagine in evidenza (featured image) della pagina
        $featured_image_id = get_post_thumbnail_id(get_the_ID());
        $featured_image_url = $featured_image_id ? wp_get_attachment_image_url($featured_image_id, 'full') : '';
        $head_style = '';
        if ($featured_image_url) {
            $head_style = "position: relative; background: url('{$featured_image_url}') no-repeat right center / cover #f8f9fa;";
        }
        ?>
        <section id="head" class="bg-light" style="padding-top: 120px; padding-bottom: 40px; <?php echo esc_attr($head_style); ?>">
            <?php if ($featured_image_url): ?>
                <div style="
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: rgba(0,0,0,0.7);
            z-index: 1;
        "></div>
            <?php endif; ?>
            <div class="container px-xl-3" style="position: relative; z-index: 2;">
                <div class="row d-flex align-items-end">
                    <div class="col-lg-7 ">
                        <h1 class="page-title text-white"><?php the_title(); ?></h1>
                        <div class="extender border-white my-3"></div>
                        <?php
                        if (function_exists('yoast_breadcrumb')) {
                            echo '<style>
                    #breadcrumbs.text-white a { color: #fff !important; }
                    #breadcrumbs.text-white a:hover, #breadcrumbs.text-white a:focus { color: #eaeaea !important; }
                  </style>';
                            yoast_breadcrumb('<p id="breadcrumbs" class="text-white">', '</p>');
                        }
                        ?>
                    </div>
                    <div class="col-lg-5">
                        <?php if ($featured_image_url): ?>
                            <img src="<?php echo esc_url($featured_image_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" class="img-fluid w-100">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <section class="py-8" style="padding-top:0 !important;">
            <div class="container px-xl-3">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="text-center py-5 internal-h3"><?php echo esc_html(get_field('titolo_categoria')); ?></h2>
                        <?php echo wp_kses_post(get_field('testo_categoria')); ?>
                        <div class="extender-mini my-3 mx-auto"></div>
                        <?php
                        $boxes = get_field('box_sotto_pagine');
                        if ($boxes) {
                            $total = count($boxes);

                            // Se ci sono esattamente 4 box, tutti col-3 in una sola riga
                            if ($total === 4) {
                                echo '<div class="row mb-5">';
                                for ($i = 0; $i < 4; $i++) {
                                    $box = $boxes[$i];
                                    $img_url = !empty($box['immagine_box']['url']) ? esc_url($box['immagine_box']['url']) : '';
                                    $titolo = !empty($box['titolo_box']) ? esc_html($box['titolo_box']) : '';
                                    $testo = $box['testo_box'] ?? '';
                                    $link = $box['link_box'] ?? '';
                                    echo '<div class="col-md-3 col-xs-12 d-flex flex-column align-items-stretch mb-4">';
                                    // Box principale con hover
                                    echo '<div class="acf-box-hover position-relative d-flex flex-column justify-content-between align-items-center text-center h-100" style="min-height: 320px; box-shadow: 0 2px 16px rgba(0,0,0,0.08);">';
                                    // Sfondo immagine
                                    echo "<div class=\"acf-box-bg\" style=\"background-image: url('{$img_url}');\"></div>";
                                    // Overlay
                                    echo '<div class="w-100" style="position: absolute; inset: 0; background: rgba(123,113,98,0.3); z-index:1;"></div>';
                                    // Contenuto centrato verticalmente
                                    echo '<div class="acf-box-content w-100 px-3 py-4 d-flex flex-column justify-content-center align-items-center" style="position: relative; z-index:2; flex: 1 1 auto; min-height: 0;">';
                                    echo '<div class="w-100 d-flex flex-column justify-content-center align-items-center" style="min-height: 120px;">';
                                    echo "<h5 class=\"text-white mb-2 uppercase\" style=\"letter-spacing:2px;\">{$titolo}</h5>";
                                    echo '<div class="mx-auto mb-3" style="width: 50%; height: 1px; background: #fff;"></div>';
                                    echo '</div>';
                                    echo '</div>';
                                    // Pulsante centrato in basso
                                    if ($link) {
                                        echo '<div style="position: relative; left: 0; right: 0; bottom: 25px; z-index:2; display: flex; justify-content: center;">';
                                        echo '<a href="' . esc_url($link) . '" class="btn mb-2 btn-outline-light" style="padding-top: 7px;padding-bottom: 7px;">' . esc_html(__('SCOPRI DI PIÙ', 'pietre-rapolano')) . '</a>';
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                    // Testo fuori dal box
                                    if ($testo) {
                                        echo '<div class="extender-grey mx-auto"></div>';
                                        echo '<div class="text-start mt-2 px-4 text-center">' . wp_kses_post($testo) . '</div>';
                                    }
                                    echo '</div>';
                                }
                                echo '</div>';
                            } else {
                                // Prima riga: col-2 vuota, poi 3 box col-3, col-2 vuota
                                echo '<div class="row mb-5">';
                                echo '<div class="col-md-2 col-xs-12"></div>';
                                for ($i = 0; $i < 3 && $i < $total; $i++) {
                                    $box = $boxes[$i];
                                    $img_url = !empty($box['immagine_box']['url']) ? esc_url($box['immagine_box']['url']) : '';
                                    $titolo = !empty($box['titolo_box']) ? esc_html($box['titolo_box']) : '';
                                    $testo = $box['testo_box'] ?? '';
                                    $link = $box['link_box'] ?? '';
                                    echo '<div class="col-md-3 col-xs-12 d-flex flex-column align-items-stretch mb-4">';
                                    // Box principale con hover
                                    echo '<div class="acf-box-hover position-relative d-flex flex-column justify-content-between align-items-center text-center h-100" style="min-height: 320px; box-shadow: 0 2px 16px rgba(0,0,0,0.08);">';
                                    // Sfondo immagine
                                    echo "<div class=\"acf-box-bg\" style=\"background-image: url('{$img_url}');\"></div>";
                                    // Overlay
                                    echo '<div class="w-100" style="position: absolute; inset: 0; background: rgba(123,113,98,0.3); z-index:1;"></div>';
                                    // Contenuto centrato verticalmente
                                    echo '<div class="acf-box-content w-100 px-3 py-4 d-flex flex-column justify-content-center align-items-center" style="position: relative; z-index:2; flex: 1 1 auto; min-height: 0;">';
                                    echo '<div class="w-100 d-flex flex-column justify-content-center align-items-center" style="min-height: 120px;">';
                                    echo "<h5 class=\"text-white mb-2 uppercase\" style=\"letter-spacing:2px;\">{$titolo}</h5>";
                                    echo '<div class="mx-auto mb-3" style="width: 50%; height: 1px; background: #fff;"></div>';
                                    echo '</div>';
                                    echo '</div>';
                                    // Pulsante centrato in basso
                                    if ($link) {
                                        echo '<div style="position: relative; left: 0; right: 0; bottom: 25px; z-index:2; display: flex; justify-content: center;">';
                                        echo '<a href="' . esc_url($link) . '" class="btn mb-2 btn-outline-light" style="padding-top: 7px;padding-bottom: 7px;">' . esc_html(__('SCOPRI DI PIÙ', 'pietre-rapolano')) . '</a>';
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                    // Testo fuori dal box
                                    if ($testo) {
                                        echo '<div class="extender-grey mx-auto"></div>';
                                        echo '<div class="text-start mt-2 px-4 text-center">' . wp_kses_post($testo) . '</div>';
                                    }
                                    echo '</div>';
                                }
                                echo '<div class="col-2"></div>';
                                echo '</div>';

                                // Seconda riga: tutti box col-3
                                if ($total > 3) {
                                    echo '<div class="row">';
                                    for ($i = 3; $i < $total; $i++) {
                                        $box = $boxes[$i];
                                        $img_url = !empty($box['immagine_box']['url']) ? esc_url($box['immagine_box']['url']) : '';
                                        $titolo = !empty($box['titolo_box']) ? esc_html($box['titolo_box']) : '';
                                        $testo = $box['testo_box'] ?? '';
                                        $link = $box['link_box'] ?? '';
                                        echo '<div class="col-md-3 col-xs-12 d-flex flex-column align-items-stretch mb-4">';
                                        // Box principale con hover
                                        echo '<div class="acf-box-hover position-relative d-flex flex-column justify-content-between align-items-center text-center h-100" style="min-height: 320px; box-shadow: 0 2px 16px rgba(0,0,0,0.08);">';
                                        // Sfondo immagine
                                        echo "<div class=\"acf-box-bg\" style=\"background-image: url('{$img_url}');\"></div>";
                                        // Overlay
                                        echo '<div class="w-100" style="position: absolute; inset: 0; background: rgba(123,113,98,0.3); z-index:1;"></div>';
                                        // Contenuto centrato verticalmente
                                        echo '<div class="acf-box-content w-100 px-3 py-4 d-flex flex-column justify-content-center align-items-center" style="position: relative; z-index:2; flex: 1 1 auto; min-height: 0;">';
                                        echo '<div class="w-100 d-flex flex-column justify-content-center align-items-center" style="min-height: 120px;">';
                                        echo "<h5 class=\"text-white mb-2 uppercase\" style=\"letter-spacing:2px;\">{$titolo}</h5>";
                                        echo '<div class="mx-auto mb-3" style="width: 50%; height: 1px; background: #fff;"></div>';
                                        echo '</div>';
                                        echo '</div>';
                                        // Pulsante centrato in basso
                                        if ($link) {
                                            echo '<div style="position: relative; left: 0; right: 0; bottom: 25px; z-index:2; display: flex; justify-content: center;">';
                                            echo '<a href="' . esc_url($link) . '" class="btn mb-2 btn-outline-light" style="padding-top: 7px;padding-bottom: 7px;">' . esc_html(__('SCOPRI DI PIÙ', 'pietre-rapolano')) . '</a>';
                                            echo '</div>';
                                        }
                                        echo '</div>';
                                        // Testo fuori dal box
                                        if ($testo) {
                                            echo '<div class="extender-grey mx-auto"></div>';
                                            echo '<div class="text-start mt-2 px-4 text-center">' . wp_kses_post($testo) . '</div>';
                                        }
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                }
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
<?php endwhile;

else :
    _e('Sorry, no posts matched your criteria.', 'pietre-rapolano');
endif;

get_footer();
