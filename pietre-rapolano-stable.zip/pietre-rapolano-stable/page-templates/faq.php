<?php
/**
 * Template Name: FAQ Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-3 my-auto">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
				}
				?>
			</div>
			<div class="col-lg-9 my-auto">
				
			</div>
		</div>
	</div>
</section>
<section id="sup-head-video"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-3 d-flex my-auto d-xs-none">
				<div class="px-5 py-10">
					<?php the_content();?>
					
				</div>
			</div>
			<div class="col-lg-9">
				<?php if( have_rows('contenuti_faq') ): ?>
					<div class="accordion" id="accordion-cwb">
					    <?php $i = 1; while( have_rows('contenuti_faq') ): the_row(); 
					        $titolo = get_sub_field('titolo_faq');
					        $testo = get_sub_field('testo_faq');
					        $is_first = ($i === 1);
					        $collapse_id = 'collapse-cwb-' . $i;
					        $heading_id = 'heading-cwb-' . $i;
					    ?>
					    <div class="accordion-item mb-3">
					        <h2 class="accordion-header" id="<?php echo $heading_id; ?>">
					            <button class="accordion-button<?php if(!$is_first) echo ' collapsed'; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $collapse_id; ?>" aria-expanded="<?php echo $is_first ? 'true' : 'false'; ?>" aria-controls="<?php echo $collapse_id; ?>">
					                <?php echo esc_html($titolo); ?>
					            </button>
					        </h2>
					        <div id="<?php echo $collapse_id; ?>" class="accordion-collapse collapse<?php if($is_first) echo ' show'; ?>" aria-labelledby="<?php echo $heading_id; ?>" data-bs-parent="#accordion-cwb">
					            <div class="accordion-body lc-block">
					                <div editable="rich">
					                    <?php echo $testo; ?>
					                </div>
					            </div>
					        </div>
					    </div>
					    <?php $i++; endwhile; ?>
					</div>

					<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<div class="clearx2"></div>
<div class="clearx2"></div>

    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
