<?php
/**
 * Template Name: Progetti
 Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<?php
$background_image = get_field('immagine_header');
$style = $background_image ? ' style="background-image: url(' . esc_url($background_image) . '); background-size: cover; background-position: center;"' : '';
?>
<section id="head" class="bg-light"<?php echo $style; ?>>
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center"><?php the_title(); ?></h1>
				<div class="extender-mini my-3 mx-auto"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
				}
				?>
			</div>
		</div>
	</div>
</section>

<section class="bg-grey py-8"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="text-center"><?php _e( 'Alcune nostre realizzazioni', 'pietre-rapolano' ); ?></h2>
                 <?php echo do_shortcode('[searchandfilter field="Categorie progetti"]'); ?>
				<div class="clearx2"></div>
            </div>
        </div>
    </div>
    <div id="progetti-results" class="container-fluid">
        <div class="row">
		<?php
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
            $args = array(
                'post_type' => 'progetto',
                'posts_per_page' => 21,
                'search_filter_query_id' => 2,
                'paged' => $paged
            );
            $query = new WP_Query($args);

            if ($query->have_posts()) : ?>

            <?php while ($query->have_posts()) : $query->the_post();
                // Recupera l'URL dell'immagine dal campo ACF
                $acf_img = get_field('immagine_progetto');
                $bg_url = '';
                if ($acf_img) {
                    // Se il campo restituisce un array (tipico per i campi immagine ACF)
                    $bg_url = is_array($acf_img) ? $acf_img['url'] : $acf_img;
                }
            ?>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
            <a style="color: white;text-decoration: none;" href="<?php the_permalink(); ?>">
                <div class="progetto-card">
                    <div class="progetto-bg" style="background-image: url('<?php echo esc_url($bg_url); ?>');"></div>
                    <div class="progetto-overlay"></div>
                    <h5 class="progetto-title"><?php the_title(); ?></h5>
                    <span class="progetto-scopri"><?php _e( 'Scopri il progetto', 'pietre-rapolano' ); ?> <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-blog.svg" aria-label="icona scopri" alt="icona scopri"/></span>
                </div>
            </a>
            <div class="clear"></div>
            </div>

            <?php endwhile; wp_reset_postdata(); ?>
            <?php endif; ?>
			</div>
		</div>
		<div class="row">
        <div class="col lead text-center w-100">
            <div class="d-inline-block"><?php
                // Passa il totale delle pagine e la pagina corrente alla funzione
                picostrap_pagination(array(
                    'total'   => $query->max_num_pages,
                    'current' => $paged
                ));
                ?></div>
        </div><!-- /col -->
        </div> <!-- /row -->
	</div>
</section>

<section id="cta-footer-contact" class="py-150">
    <!-- Overlay per l'effetto blur -->
    <div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center text-light"><?php _e( 'Contattaci per informazioni', 'pietre-rapolano' ); ?></h3>
				<p class="text-center text-light uppercase"><?php _e( 'o per richiedere un preventivo personalizzato', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php 
				$current_lang = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'it';
				if ($current_lang == 'en') {
					echo do_shortcode('[contact-form-7 id="143fa53" title="Modulo di contatto CTA ENG"]');
				} elseif ($current_lang == 'de') {
					echo do_shortcode('[contact-form-7 id="acc043e" title="Modulo di contatto CTA DEU"]');
				} else {
					echo do_shortcode('[contact-form-7 id="5fbf157" title="Modulo di contatto CTA ITA"]');
				}
				?>
			</div>
		</div>
	</div>
</section>

    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
