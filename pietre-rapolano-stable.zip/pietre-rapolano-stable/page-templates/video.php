<?php
/**
 * Template Name: Video Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-5 my-auto">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
				}
				?>
			</div>
			<div class="col-lg-7 my-auto">
				
			</div>
		</div>
	</div>
</section>
<section id="sup-head-video"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-5 d-flex my-auto">
				<div class="px-5 py-10">
					<?php the_content();?>
					
				</div>
			</div>
			<div class="col-lg-7">
				<?php 
				    $the_query = new WP_Query( array(
				        'post_type' => 'video-podcast',
				        'posts_per_page' => 12,
				        'tax_query' => array(
				            array (
				                'taxonomy' => 'tipologia-formato',
				                'field' => 'slug',
				                'terms' => 'orizzontale',
				            )
				        ),
				    )); 
				?>
				<?php $f=0; $posts = [];?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $f ++; ?>
				    <?php if($f == 1): ?>
				        <div class="col-sm-12 post-contenitore videofull post-<?php printf(get_the_ID());?>">
				            <div class="">
				                <div class="entry-content-post">
				                    <h5 class="text-center"><?php the_title(); ?></h5>
				                </div><!-- .entry-content -->
				                <?php remove_filter ('the_content', 'wpautop'); the_content(); ?>
				            </div>
				        </div>
				        <div class="clearx2"></div>
				    <?php else: ?>
				        <?php 
				            // Salvo i dati dei post successivi in un array
				            $posts[] = array(
				                'id' => get_the_ID(),
				                'title' => get_the_title(),
				                'content' => apply_filters('the_content', get_the_content()),
				            );
				        ?>
				    <?php endif; ?>
				<?php endwhile;?>
				
				<?php if(count($posts) > 0): ?>
				<div class="splide" id="splide-videopodcast">
				    <div class="splide__track">
				        <ul class="splide__list">
				            <?php for($i = 0; $i < count($posts); $i += 2): ?>
				                <li class="splide__slide">
				                    <div class="row">
				                        <?php for($j = 0; $j < 2; $j++): ?>
				                            <?php if(isset($posts[$i+$j])): $p = $posts[$i+$j]; ?>
				                                <div class="col-sm-6 post-contenitore videofull post-<?php echo $p['id']; ?>">
				                                    <div class="entry-content-post">
				                                        <h6 class="text-center"><?php echo $p['title']; ?></h6>
				                                    </div>
				                                    <?php echo $p['content']; ?>
				                                </div>
				                            <?php endif; ?>
				                        <?php endfor; ?>
				                    </div>
				                </li>
				            <?php endfor; ?>
				        </ul>
				    </div>
				</div>
				<script>
				document.addEventListener( 'DOMContentLoaded', function () {
				    if(window.Splide){
				        new Splide( '#splide-videopodcast', {
				            type   : 'loop',
				            perPage: 1,
				            perMove: 1,
				            gap: '1rem',
							autoplay   : true,
			   				interval   : 5000,
							pagination : true,
				            breakpoints: {
				                768: {
				                    gap: '0.5rem',
				                }
				            }
				        } ).mount();
				    }
				} );
				</script>
				<?php endif; ?>
				<?php wp_reset_postdata();?>
				<?php wp_reset_query(); ?>
			</div>
		</div>
	</div>
</section>
<div class="clearx2"></div>
<div class="clearx2"></div>
<section id="team" class="bg-grey py-5"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center py-5"><?php _e( 'Architalks<br/>Interviste', 'pietre-rapolano' ); ?></h3>
				<hr class="divider my-3 mx-auto"/>
				<?php 
				    $the_query = new WP_Query( array(
				        'post_type' => 'video-podcast',
				        'posts_per_page' => -1,
				        'tax_query' => array(
				            array (
				                'taxonomy' => 'tipologia-formato',
				                'field' => 'slug',
				                'terms' => 'verticale',
				            )
				        ),
				    )); 
				    if ($the_query->have_posts()) :
    $slide_count = $the_query->post_count;
				?>
				    <div id="feedbackSplide" class="py-5 splide custom-splide" aria-label="Team Carousel">
				        <div class="splide__track">
				            <ul class="splide__list">
				                <?php $f=0;?>
								<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $f ++; ?>
				                    <li class="splide__slide">

	                                    <?php remove_filter ('the_content', 'wpautop'); the_content(); ?>

				                    </li>
				                <?php endwhile; wp_reset_postdata(); ?>
				            </ul>
				        </div>
				    </div>
				
				<!-- PAGINAZIONE CUSTOM SLIDE -->
			    <div class="splide-pagination-custom mt-3 d-flex flex-column align-items-center">
			    <div class="d-flex align-items-center justify-content-center">
			        <button class="splide-arrow-custom prev" aria-label="Precedente"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-left.svg"/></button>
			        <?php for ($i = 1; $i <= $slide_count; $i++): ?>
			            <span class="splide-page-num<?php if ($i == 1) echo ' active'; ?>"><?php echo sprintf('%02d', $i); ?></span>
			        <?php endfor; ?>
			        <button class="splide-arrow-custom next" aria-label="Successivo"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-right.svg"/></button>
			        
			    </div>
			</div>
			<?php endif; ?>
			<script>
			document.addEventListener('DOMContentLoaded', function () {
			  var splide = new Splide('#feedbackSplide', {
			    type       : 'loop',
			    perPage    : 3,
			    perMove    : 1,
			    gap        : '2rem',
			    autoplay   : false,
			    interval   : 5000,
			    pauseOnHover: true,
			    arrows     : false, // Disabilita le frecce native Splide
			    pagination : false,
			    breakpoints: {
			      768: {
			        perPage: 1
			      }
			    }
			  }).mount();
			
			  // Gestione frecce custom
			  document.querySelector('.splide-arrow-custom.prev').addEventListener('click', function() {
			    splide.go('<');
			  });
			  document.querySelector('.splide-arrow-custom.next').addEventListener('click', function() {
			    splide.go('>');
			  });
			
			  // Gestione numeri custom
			  var pageNums = document.querySelectorAll('.splide-page-num');
			  pageNums.forEach(function(num, idx) {
			    num.addEventListener('click', function() {
			      splide.go(idx);
			    });
			  });
			
			  // Aggiorna attivo
			  splide.on('move', function(newIndex){
			    var total = pageNums.length;
			    var realIndex = (newIndex % total + total) % total; // per evitare indici negativi
			    pageNums.forEach(function(num, idx){
			      num.classList.toggle('active', idx === realIndex);
			    });
			  });
			});
			</script>
			</div>
		</div>
	</div>
</section>
    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
