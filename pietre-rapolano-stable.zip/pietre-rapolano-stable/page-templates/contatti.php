<?php
/**
 * Template Name: Contatti Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>
	<style>
	.wpcf7-form-control::placeholder {
  color: black;
}
	</style>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center"><?php the_title(); ?></h1>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
				}
				?>
				<div class="extender-mini my-3 mx-auto"></div>
				<div class="d-none d-md-flex justify-content-center align-items-center w-100">
					<a href="#firenze" title="Link azienda" class="btn mb-2 btn-outline-primary mx-2"><?php _e( 'SEDE DI FIRENZE', 'pietre-rapolano' ); ?></a> 
					<a href="#roma" title="Link azienda" class="btn mb-2 btn-outline-primary mx-2"><?php _e( 'SEDE DI ROMA', 'pietre-rapolano' ); ?></a> 
					<a href="#germania" title="Link azienda" class="btn mb-2 btn-outline-primary mx-2"><?php _e( 'MERCATI LINGUA TEDESCA', 'pietre-rapolano' ); ?></a>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
<section id="map-firenze">
	<div class="container-fluid px-0">
		<div class="row">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2882.616290721038!2d11.2609772!3d43.73929739999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132a53d0bdd18ecd%3A0xa129cf911ca2f56b!2sPDR%20S.r%20l.%20Pietre%20di%20Rapolano!5e0!3m2!1sit!2sit!4v1750254372607!5m2!1sit!2sit" width="100%" height="700" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
	</div>
</section>
<section id="sup-head-video"> 
	<div id="firenze" class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex my-auto">
				<div class="px-5 py-10">
					<p class="uppercase"><?php _e( 'FIRENZE', 'pietre-rapolano' ); ?></p>
					<h2><?php _e( 'Hai bisogno di una mano o sei in cerca di ispirazione?', 'pietre-rapolano' ); ?></h2>	
					<p><?php echo (get_field('frase_introduttiva')); ?></p>	
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/map.svg" alt="icona mappa"/>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo (get_field('indirizzo_firenze')); ?>
					<br/>
					<span style="font-size:20px;"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/phone.svg" alt="icona telefono"/>&nbsp;&nbsp;&nbsp;&nbsp;<b><a href="tel:<?php echo (get_field('numero_di_telefono_firenze')); ?>"><?php echo (get_field('numero_di_telefono_firenze')); ?></a></b></span>
					</p>
					<div class="clear"></div>
					<p><a target="_blank" href="https://www.google.com/maps/dir//<?php echo (get_field('indirizzo_firenze')); ?>" class="btn-mini-dark"><?php _e( 'Calcola il percorso', 'pietre-rapolano' ); ?></a></p>	
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/envelope.svg" alt="icona mail"/>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo (get_field('mail_firenze')); ?>"><?php echo (get_field('mail_firenze')); ?></a>
					<br/>
					<img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/envelope.svg" alt="icona pec"/>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo (get_field('pec_firenze')); ?>
					</p>
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/clock.svg" alt="icona orari"/>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php _e( 'Orari di apertura', 'pietre-rapolano' ); ?></b>
						<br/>
					<?php echo ( get_field('orari_di_apertura')); ?>
					</p>
					<div class="clear"></div>
					<p class="contact-text">Social&nbsp;&nbsp;&nbsp;&nbsp; <a href="https://www.facebook.com/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/facebook.svg" alt="icona Facebook"/></a>&nbsp;&nbsp;<a href="https://www.instagram.com/pietredirapolano/"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/instagram.svg" alt="icona Instagram"/></a>&nbsp;&nbsp;<a href="https://www.youtube.com/user/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/youtube.svg" alt="icona YouTube"/></a>&nbsp;&nbsp;<a href="https://www.tiktok.com/@pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/tiktok.svg" alt="icona TikTok"/></a>&nbsp;&nbsp;<a href="https://it.pinterest.com/pietrerapolano/"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/pinterest-logo.svg" width="22" alt="icona Pinterest"/></a>&nbsp;&nbsp;<a href="https://vimeo.com/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/vimeo.svg" width="22" alt="icona Vimeo"/></a>&nbsp;&nbsp;<a href="https://www.homify.it/esperti/13288/pietre-di-rapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/homify-svgrepo-com.svg" width="22" alt="icona Homify"/></a></p>
				</div>
			</div>
			<div class="col-lg-6">
				<div id="box-rounded" class="px-5 py-5 rounded shadow-sm bg-white w-100">
					<h5 class="text-center"><?php _e( 'Richiesta informazioni', 'pietre-rapolano' ); ?></h5>
					<p class="text-center uppercase"><?php _e( 'FIRENZE', 'pietre-rapolano' ); ?></p>
					<div class="clear"></div>
					<?php echo (do_shortcode('[contact-form-7 id="c54de72" title="Modulo di contatto Firenze ITA"]')); ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
<section id="map-roma">
	<div class="container-fluid px-0">
		<div class="row">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2967.2191917211085!2d12.758411976366666!3d41.95262677123364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132f795123dd24cb%3A0xe942770e79754779!2sPDR%20SRL%20Pietre%20di%20Rapolano!5e0!3m2!1sit!2sit!4v1750259371197!5m2!1sit!2sit" width="100%" height="700" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
	</div>
</section>
<section id="sup-head-video"> 
	<div id="roma" class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex my-auto">
				<div class="px-5 py-10">
					<p class="uppercase"><?php _e( 'ROMA', 'pietre-rapolano' ); ?></p>
					<h2><?php _e( 'Nuova sede nel Lazio, a Tivoli (Roma)', 'pietre-rapolano' ); ?></h2>	
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/map.svg" alt="icona mappa"/>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo (get_field('indirizzo_roma')); ?>
					<br/>
					<span style="font-size:20px;"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/phone.svg" alt="icona telefono"/>&nbsp;&nbsp;&nbsp;&nbsp;<b><a href="tel:<?php echo (get_field('numero_di_telefono_roma')); ?>"><?php echo (get_field('numero_di_telefono_roma')); ?></a></b></span>
					</p>
					<div class="clear"></div>
					<p><a target="_blank" href="https://www.google.com/maps/dir//<?php echo (get_field('indirizzo_roma')); ?>" class="btn-mini-dark"><?php _e( 'Calcola il percorso', 'pietre-rapolano' ); ?></a></p>
					<div class="clear"></div>	
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/envelope.svg" alt="icona mail"/>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo (get_field('mail_roma')); ?>"><?php echo (get_field('mail_roma')); ?></a>
					</p>
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/clock.svg" alt="icona orari"/>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php _e( 'Orari di apertura', 'pietre-rapolano' ); ?></b>
						<br/>
					<?php echo ( get_field('orari_di_apertura_roma')); ?>
					</p>
					<div class="clear"></div>
					<p class="contact-text">Social&nbsp;&nbsp;&nbsp;&nbsp; <a href="https://www.facebook.com/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/facebook.svg" alt="icona Facebook"/></a>&nbsp;&nbsp;<a href="https://www.instagram.com/pietredirapolano/"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/instagram.svg" alt="icona Instagram"/></a>&nbsp;&nbsp;<a href="https://www.youtube.com/user/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/youtube.svg" alt="icona YouTube"/></a>&nbsp;&nbsp;<a href="https://www.tiktok.com/@pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/tiktok.svg" alt="icona TikTok"/></a>&nbsp;&nbsp;<a href="https://it.pinterest.com/pietrerapolano/"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/pinterest-logo.svg" width="22" alt="icona Pinterest"/></a>&nbsp;&nbsp;<a href="https://vimeo.com/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/vimeo.svg" width="22" alt="icona Vimeo"/></a>&nbsp;&nbsp;<a href="https://www.homify.it/esperti/13288/pietre-di-rapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/homify-svgrepo-com.svg" width="22" alt="icona Homify"/></a></p>
				</div>
			</div>
			<div class="col-lg-6">
				<div id="box-rounded" class="px-5 py-5 rounded shadow-sm bg-white w-100">
					<h5 class="text-center"><?php _e( 'Richiesta informazioni', 'pietre-rapolano' ); ?></h5>
					<p class="text-center uppercase"><?php _e( 'ROMA', 'pietre-rapolano' ); ?></p>
					<div class="clear"></div>
					<?php echo (do_shortcode('[contact-form-7 id="e1ce785" title="Modulo di contatto Roma ITA"]')); ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
<section class="py-8"> 
	<div id="germania" class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex my-auto">
				<div class="px-5 py-10">
					<p class="uppercase"><?php _e( 'GERMANIA', 'pietre-rapolano' ); ?></p>
					<h2><?php _e( 'Ufficio di rappresentanza per la Germania', 'pietre-rapolano' ); ?></h2>	
					<h5><?php _e( '(Non aperto al pubblico)', 'pietre-rapolano' ); ?></h5>
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/map.svg" alt="icona mappa"/>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo (get_field('indirizzo_germania')); ?>
					<br/>
					<span style="font-size:20px;"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/phone.svg" alt="icona telefono"/>&nbsp;&nbsp;&nbsp;&nbsp;<b>Enrico Drahorad <a href="tel:<?php echo (get_field('numero_di_telefono_germania')); ?>"><?php echo (get_field('numero_di_telefono_germania')); ?></a></b></span>
					</p>
					<div class="clear"></div>
					<p><a target="_blank" href="https://www.google.com/maps?ll=47.874288,11.474339&z=17&t=m&hl=it&gl=IT&mapclient=embed&cid=6227754988418053815" class="btn-mini-dark"><?php _e( 'Calcola il percorso', 'pietre-rapolano' ); ?></a></p>	
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/envelope.svg" alt="icona mail"/>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo (get_field('mail_germania_1')); ?>"><?php echo (get_field('mail_germania_1')); ?></a><br/><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/envelope.svg" alt="icona mail"/>&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo (get_field('mail_germania_2')); ?>"><?php echo (get_field('mail_germania_2')); ?></a>
					</p>
					<div class="clear"></div>
					<p class="contact-text"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/clock.svg" alt="icona orari"/>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php _e( 'Orari di apertura', 'pietre-rapolano' ); ?></b>
						<br/>
					<?php echo ( get_field('orari_di_apertura_germania')); ?>
					</p>
					<div class="clear"></div>
					<p class="contact-text">Social&nbsp;&nbsp;&nbsp;&nbsp; <a href="https://www.facebook.com/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/facebook.svg" alt="icona Facebook"/></a>&nbsp;&nbsp;<a href="https://www.instagram.com/pietredirapolano/"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/instagram.svg" alt="icona Instagram"/></a>&nbsp;&nbsp;<a href="https://www.youtube.com/user/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/youtube.svg" alt="icona YouTube"/></a>&nbsp;&nbsp;<a href="https://www.tiktok.com/@pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/tiktok.svg" alt="icona TikTok"/></a>&nbsp;&nbsp;<a href="https://it.pinterest.com/pietrerapolano/"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/pinterest-logo.svg" width="22" alt="icona Pinterest"/></a>&nbsp;&nbsp;<a href="https://vimeo.com/pietredirapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/vimeo.svg" width="22" alt="icona Vimeo"/></a>&nbsp;&nbsp;<a href="https://www.homify.it/esperti/13288/pietre-di-rapolano"><img class="nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/12/homify-svgrepo-com.svg" width="22" alt="icona Homify"/></a></p>
				</div>
			</div>
			<div class="col-lg-6">
				<div id="box-rounded" class="px-5 py-5 rounded shadow-sm bg-white w-100">
					<h5 class="text-center"><?php _e( 'Richiesta informazioni', 'pietre-rapolano' ); ?></h5>
					<p class="text-center uppercase"><?php _e( 'Ufficio di rappresentanza per la Germania', 'pietre-rapolano' ); ?></p>
					<div class="clear"></div>
					<?php echo (do_shortcode('[contact-form-7 id="7300146" title="Modulo di contatto Germania ITA"]')); ?>
					
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
