<?php
/**
 * Template Name: Formazione Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
				}
				?>
			</div>
			<div class="col-lg-6 my-auto">
				
			</div>
		</div>
	</div>
</section>
<section id="sup-head-video"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex align-items-center">
				<div class="px-5 py-10">
					<h2><?php echo (get_field('titolo_1')); ?></h2>
					<p><?php echo (get_field('testo_1')); ?></p>
					<div class="clear"></div>
					<div class="row">
					<div class="col-md-6 col-xs-12 text-center">
					<a class="btn mb-2 btn-outline-primary" href="/category/formazione"><?php _e( 'ELENCO CORSI', 'pietre-rapolano' ); ?></a>
					</div>
					<div class="col-md-6 col-xs-12 text-center">
					<a class="btn mb-2 btn-outline-primary" href="#cta-footer-contact"><?php _e( 'ISCRIVITI ALLA NEWSLETTER', 'pietre-rapolano' ); ?></a>
					</div>
					</div>
					
				</div>
			</div>
			<div class="col-lg-6">
				<div class="px-2 py-2 bg-white">
				<?php 
					$image = get_field('immagine_1');
					if( !empty( $image ) ): ?>
					    <img title="<?php echo esc_attr($image['title']); ?>" class="align-center responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
					<?php endif; ?>
					</div>
					<div class="clear"></div>
					<div class="px-2 py-2 bg-white">
					<?php 
					$image = get_field('immagine_2');
					if( !empty( $image ) ): ?>
					    <img title="<?php echo esc_attr($image['title']); ?>" class="align-center responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
				<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="clearx2"></div>
<section class="bg-grey py-8"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex align-items-center">
				<div class="px-5 py-2">
					<h3><?php echo (get_field('titolo_2')); ?></h3>
					<p><?php echo (get_field('testo_2')); ?></p>
					<div class="clear"></div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="calendar px-6 py-6 bg-white rounded">
				<?php echo (do_shortcode('[qemcalendar]')); ?>
			</div>
		</div>
	</div>
</section>
<section class="bg-light py-8"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6">
				<div class="px-5 py-2">
					<h3><?php echo (get_field('titolo_3')); ?></h3>
					<p><?php echo (get_field('testo_3')); ?></p>
					<div class="clear"></div>
					<?php 
					$image = get_field('immagine_2b');
					if( !empty( $image ) ): ?>
					    <img title="<?php echo esc_attr($image['title']); ?>" class="align-center responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
				<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-6">
				<h3><?php echo (get_field('titolo_4')); ?></h3>
					<p><?php echo (get_field('testo_4')); ?></p>
					<div class="clear"></div>
			</div>
		</div>
	</div>
</section>
<section class="py-8"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6">
				<div class="px-5 py-2">
					<h3><?php echo (get_field('titolo_5')); ?></h3>
					<p><?php echo (get_field('testo_5')); ?></p>
					<div class="clear"></div>
				</div>
			</div>
			<div class="col-lg-6">
				<?php 
					$image = get_field('immagine_3');
					if( !empty( $image ) ): ?>
					    <img title="<?php echo esc_attr($image['title']); ?>" class="align-center responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>

<section id="cta-footer-contact" class="py-150">
    <!-- Overlay per l'effetto blur -->
    <div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center text-light"><?php _e( 'Compila il form', 'pietre-rapolano' ); ?></h3>
				<p class="text-center text-light uppercase"><?php _e( 'per ricevere una proposta formativa personalizzata', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php echo (do_shortcode('[contact-form-7 id="815dd3c" title="Modulo di contatto Formazione"]')); ?>
			</div>
		</div>
	</div>
</section>
    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
