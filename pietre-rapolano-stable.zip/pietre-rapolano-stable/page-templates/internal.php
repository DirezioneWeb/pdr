<?php
/**
 * Template Name: Internal Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
				}
				?>
			</div>
			<div class="col-lg-6 my-auto">
				
			</div>
		</div>
	</div>
</section>
<section id="sup-head-video"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex align-items-end">
				<div class="px-5 py-10">
					<h2><?php echo (get_field('titolo_blocco_1')); ?></h2>
					<?php echo (get_field('testo_blocco_1')); ?>
					<?php if (get_field('url_pulsante_1')) : ?>
					<a href="<?php echo (get_field('url_pulsante_1')); ?>" title="Link azienda" class="btn mb-2 btn-outline-primary"><?php echo (get_field('etichetta_pulsante_1')); ?></a>
					<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-6">
				<?php 
					$image = get_field('immagine_blocco_1');
					if( !empty( $image ) ): ?>
					    <img title="<?php echo esc_attr($image['title']); ?>" class="align-center responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
					<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<section class="py-8 bg-light"> 
	<div class="container px-xl-3">
		<div class="row">
			<?php if (get_field('titolo_sezione_grigia')) : ?>
			<div class="col-lg-12">
				<h2 class="text-center"><?php echo (get_field('titolo_sezione_grigia')); ?></h2>
				<div class="extender-mini my-3 mx-auto"></div>
			</div>
			<?php endif; ?>
		</div>
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-6 my-auto">
				<?php 
				$image = get_field('immagine_blocco_2');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
			<div class="col-lg-6 my-auto">
				<div class="px-5">
					<h3><?php echo (get_field('titolo_blocco_2')); ?></h3>
					<?php echo (get_field('testo_blocco_2')); ?>
					<a href="<?php echo (get_field('url_pulsante_2')); ?>" title="<?php echo (get_field('etichetta_pulsante_2')); ?>" class="btn mb-2 btn-outline-primary mx-2"><?php echo (get_field('etichetta_pulsante_2')); ?></a>	
					<?php if (get_field('url_pulsante_2b')) : ?>
					<a href="<?php echo (get_field('url_pulsante_2b')); ?>" title="<?php echo (get_field('etichetta_pulsante_2b')); ?>" class="btn mb-2 btn-outline-primary mx-2"><?php echo (get_field('etichetta_pulsante_2b')); ?></a>
					<?php endif; ?>
					<div class="clear"></div>
				</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="py-5 bg-white"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto">
				<div class="px-5">
					<h3><?php echo (get_field('titolo_blocco_3')); ?></h3>
					<?php echo (get_field('testo_blocco_3')); ?>
					<?php if (get_field('url_pulsante_3')): ?>
					<a href="<?php echo (get_field('url_pulsante_3')); ?>" title="Link azienda" class="btn mb-2 btn-outline-primary"><?php echo (get_field('etichetta_pulsante_3')); ?></a>	
					<?php endif; ?>
					<div class="clear"></div>
				</div>
			</div>
			
			<div class="col-lg-6 my-auto">
				<?php 
				$image = get_field('immagine_blocco_3');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<?php if (get_field('titolo_blocco_4')) : ?>
<section class="py-5 bg-white"> 
	<div class="container px-xl-3">
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-6 my-auto">
				<?php 
				$image = get_field('immagine_blocco_4');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
			<div class="col-lg-6 my-auto">
				<div class="px-5">
					<h3><?php echo (get_field('titolo_blocco_4')); ?></h3>
					<?php echo (get_field('testo_blocco_4')); ?>
					<?php if (get_field('url_pulsante_4')): ?>
					<a href="<?php echo (get_field('url_pulsante_4')); ?>" title="Link azienda" class="btn mb-2 btn-outline-primary"><?php echo (get_field('etichetta_pulsante_4')); ?></a>	
					<?php endif; ?>
					<div class="clear"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<?php if (get_field('titolo_blocco_5')) : ?>
<section class="py-8 bg-light"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<div class="px-5">
					<h3 class="text-center" ><?php echo (get_field('titolo_blocco_5')); ?></h3>
					<?php echo (get_field('testo_blocco_5')); ?>
					<?php if (get_field('url_pulsante_5')): ?>
					<a href="<?php echo (get_field('url_pulsante_5')); ?>" title="Link azienda" class="d-block mx-auto btn mb-2 btn-outline-primary" style="max-width: 250px;"><?php echo (get_field('etichetta_pulsante_5')); ?></a>	
					<?php endif; ?>
					<div class="clear"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<section id="cta-footer-contact" class="py-150">
    <!-- Overlay per l'effetto blur -->
    <div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center text-light"><?php _e( 'Compila il form per iscriverti alla newsletter', 'pietre-rapolano' ); ?></h3>
				<p class="text-center text-light uppercase"><?php _e( 'e ricevere informazioni sui prossimi corsi di formazione', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php 
				$current_lang = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'it';
				if ($current_lang == 'en') {
					echo do_shortcode('[contact-form-7 id="143fa53" title="Modulo di contatto CTA ENG"]');
				} elseif ($current_lang == 'de') {
					echo do_shortcode('[contact-form-7 id="acc043e" title="Modulo di contatto CTA DEU"]');
				} else {
					echo do_shortcode('[contact-form-7 id="5fbf157" title="Modulo di contatto CTA ITA"]');
				}
				?>
			</div>
		</div>
	</div>
</section>
    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
