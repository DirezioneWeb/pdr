<?php

/**
 * Template Name: General Page Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

get_header();
?>
<div class="py-5 py-xl-8 bg-light-subtle text-dark-emphasis">
    <div class="container text-center">
        <h1 class="display-4"><?php the_title(); ?></h1>
            <?php
            if (function_exists('yoast_breadcrumb')) {
                yoast_breadcrumb('<p id="breadcrumbs">', '</p>');
            }
            ?>
        </div>
  </div>
</div>

<?php
if (have_posts()) :
    while (have_posts()) : the_post();

        // Check value exists.
        if (have_rows('contenuto')):

            // Loop through rows.
            while (have_rows('contenuto')) : the_row();

                // Case: IMG + TXT + CATALOGO.
                if (get_row_layout() == 'img_+_txt_+_catalogo'):

                    $immagine_sx = get_sub_field('immagine_sx');
                    $titolo_dx = get_sub_field('titolo_dx');
                    $sottotitolo_dx = get_sub_field('sottotitolo_dx');
                    $testo_dx = get_sub_field('testo_dx');
                    $testo_cta_catalogo = get_sub_field('testo_cta_catalogo');
                    $url_catalogo = get_sub_field('url_catalogo');

        ?>

                    <section class="py-8" style="padding-bottom: 0px!important;">
                        <div class="container px-xl-3">
                            <div class="row flex-column-reverse flex-lg-row">
                                <div class="col-lg-6">
                                    <img title="<?php echo esc_attr($immagine_sx['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($immagine_sx['url']); ?>" alt="<?php echo esc_attr($immagine_sx['alt']); ?>" />
                                </div>
                                <div class="col-lg-6 d-flex align-items-center">
                                    <div class="px-5 my-auto">
                                        <h3 class="internal-h3"><?php echo $titolo_dx; ?></h3>
                                        <?php if ($sottotitolo_dx): ?>
                                            <p class="text-uppercase cta-catalog-text"><?php echo $sottotitolo_dx; ?></p>
                                        <?php endif; ?>
                                        <?php echo $testo_dx; ?>
                                        <?php if ($url_catalogo): ?>
                                            <hr />
                                            <p class="cta-catalog-text"><strong><?php _e( 'CATALOGO', 'pietre-rapolano' ); ?></strong></p>
                                            <div id="banner-catalogo" class="d-flex justify-content-between align-items-start">
                                                <p class="text-uppercase cta-catalog-text" style="max-width: 60%;"><?php echo $testo_cta_catalogo; ?></p>
                                                <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>" class="btn mb-2 btn-outline-primary" target="_blank"><?php _e( 'Vai allo shop', 'pietre-rapolano' ); ?></a>
                                            </div>
                                            <hr />
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'txt_+_contatti_+_img'):

                    // Case: TXT + CONTATTI + IMG.
                    $titolo_sx = get_sub_field('titolo_sx');
                    $sottotitolo_sx = get_sub_field('sottotitolo_sx');
                    $testo_sx = get_sub_field('testo_sx');
                    $immagine_dx = get_sub_field('immagine_dx');
                    $mostrare_box_contatti = get_sub_field('mostrare_box_contatti');
                    $mostrare_box_catalogo = get_sub_field('mostrare_box_catalogo');

                ?>
                    <section class="py-4">
                        <div class="container px-xl-3">
                            <div class="row">

                                <div class="col-lg-6 d-flex align-items-center">
                                    <div class="px-5 my-auto">
                                        <h3 class="internal-h3"><?php echo $titolo_sx; ?></h3>
                                        <?php if ($sottotitolo_sx): ?>
                                            <p class="text-uppercase cta-catalog-text"><?php echo $sottotitolo_sx; ?></p>
                                        <?php endif; ?>
                                        <?php echo $testo_sx; ?>
                                        <?php if ($mostrare_box_contatti) : ?>
                                            <div class="clearx2"></div>
                                            <div class="cta-contact">
                                                <p class="cta-contact-text"><?php _e( 'Hai bisogno di maggiori informazioni?', 'pietre-rapolano' ); ?></p>
                                                <p class="cta-contact-text"><a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/contatti/', 'pietre-rapolano', 'Contatti URL' ) ); ?>" title="<?php echo esc_attr( apply_filters( 'wpml_translate_single_string', 'Link contatti', 'pietre-rapolano', 'Link contatti' ) ); ?>" class="text-decoration-none"><u><?php _e( 'Contattaci', 'pietre-rapolano' ); ?> <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M4.1499 9.92383L16.186 9.92383M16.186 9.92383L11.6725 14.7383M16.186 9.92383L11.6725 5.10938" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                            </svg></u></a></p>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($mostrare_box_catalogo) : ?>
                                            <hr />
                                            <p class="cta-catalog-text"><strong><?php _e( 'CATALOGO', 'pietre-rapolano' ); ?></strong></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="text-uppercase cta-catalog-text" style="max-width: 60%;"><?php _e( 'Consulta il nostro catalogo e scopri tutte le nostre proposte', 'pietre-rapolano' ); ?></p>
                                                <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>" title="<?php echo esc_attr( apply_filters( 'wpml_translate_single_string', 'Link contatti', 'pietre-rapolano', 'Link contatti' ) ); ?>" class="btn mb-2 btn-outline-primary" target="_blank"><?php _e( 'Vai allo shop', 'pietre-rapolano' ); ?></a>
                                            </div>
                                            <hr />
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <img title="<?php echo esc_attr($immagine_dx['title']); ?>" class="align-left" src="<?php echo esc_url($immagine_dx['url']); ?>" alt="<?php echo esc_attr($immagine_dx['alt']); ?>" />
                                </div>
                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'immagine_fullwidth'):

                    // Case: Immagine FW.
                    $immagine_fw = get_sub_field('immagine_fw');
                ?>
                    <section>
                        <div class="container-fluid px-0 py-5">
                            <div class="row-fluid">
                                <img title="<?php echo esc_attr($immagine_fw['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($immagine_fw['url']); ?>" alt="<?php echo esc_attr($immagine_fw['alt']); ?>" />
                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'spazio_vuoto'):

                    // Case: Empty space.
                    $spazio = get_sub_field('classe_spazio_vuoto');
                ?>
                    <div class="<?php echo $spazio; ?>"></div>

                <?php elseif (get_row_layout() == 'faq'):

                    // Case: FAQ.
                    // 'blocco_faq' è un repeater field con sottocampi 'titolo_faq' e 'testo_faq'
                ?>
                    <section class="bg-dark-grey py-8">
                        <div class="container px-xl-3">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h3 class="px-4"><?php _e( 'FAQ', 'pietre-rapolano' ); ?></h3>
                                    <div class="extender-mini my-3 mx-4"></div>
                                    <?php if (have_rows('blocco_faq')): ?>
                                        <div class="accordion" id="accordion-cwb">
                                            <?php $i = 1;
                                            while (have_rows('blocco_faq')): the_row();
                                                $titolo = get_sub_field('titolo_faq');
                                                $testo = get_sub_field('testo_faq');
                                                $is_first = ($i === 1);
                                                $collapse_id = 'collapse-cwb-' . $i;
                                                $heading_id = 'heading-cwb-' . $i;
                                            ?>
                                                <div class="accordion-item mb-3">
                                                    <h2 class="accordion-header" id="<?php echo $heading_id; ?>">
                                                        <button class="accordion-button<?php if (!$is_first) echo ' collapsed'; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $collapse_id; ?>" aria-expanded="<?php echo $is_first ? 'true' : 'false'; ?>" aria-controls="<?php echo $collapse_id; ?>">
                                                            <?php echo esc_html($titolo); ?>
                                                        </button>
                                                    </h2>
                                                    <div id="<?php echo $collapse_id; ?>" class="accordion-collapse collapse<?php if ($is_first) echo ' show'; ?>" aria-labelledby="<?php echo $heading_id; ?>" data-bs-parent="#accordion-cwb">
                                                        <div class="accordion-body lc-block">
                                                            <div editable="rich">
                                                                <?php echo $testo; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php $i++;
                                            endwhile; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'img_+_txt_+_ctas'):

                    // Case: IMG + TXT + CTAs.
                    $immagine_sxb = get_sub_field('immagine_sxb');
                    $titolo_dxb = get_sub_field('titolo_dxb');
                    $sottotitolo_dxb = get_sub_field('sottotitolo_dxb');
                    $testo_dxb = get_sub_field('testo_dxb');
                    $etichetta_cta_1 = get_sub_field('etichetta_cta_1');
                    $etichetta_cta_2 = get_sub_field('etichetta_cta_2');
                    $url_cta_1 = get_sub_field('url_cta_1');
                    $url_cta_2 = get_sub_field('url_cta_2');
                    $mostrare_box_catalogo = get_sub_field('mostrare_box_catalogo');
                    $pulsante_progettazione = get_sub_field('pulsante_progettazione');

                ?>

                    <section class="py-8" style="padding-bottom: 0px!important;">
                        <div class="container px-xl-3">
                            <div class="row flex-column-reverse flex-lg-row">
                                <div class="col-lg-6">
                                    <img title="<?php echo esc_attr($immagine_sxb['title']); ?>" class="align-left" src="<?php echo esc_url($immagine_sxb['url']); ?>" alt="<?php echo esc_attr($immagine_sxb['alt']); ?>" />
                                </div>
                                <div class="col-lg-6 d-flex align-items-center">
                                    <div class="px-5 my-auto">
                                        <h3 class="internal-h3"><?php echo $titolo_dxb; ?></h3>
                                        <?php if ($sottotitolo_dxb): ?>
                                            <p class="text-uppercase cta-catalog-text"><?php echo $sottotitolo_dxb; ?></p>
                                        <?php endif; ?>
                                        <?php echo $testo_dxb; ?>
                                        <?php if ($url_cta_1): ?>
                                            <div class="d-flex justify-content-between align-items-center py-3 gap-3">
                                                <a href="<?php echo esc_url($url_cta_1); ?>" class="btn mb-2 btn-outline-primary" target="_blank" title="<?php echo $etichetta_cta_1; ?>"><?php echo $etichetta_cta_1; ?></a>
                                                <a href="<?php echo esc_url($url_cta_2); ?>" class="btn mb-2 btn-outline-primary" target="_blank" title="<?php echo $etichetta_cta_2; ?>"><?php echo $etichetta_cta_2; ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($mostrare_box_catalogo) : ?>
                                            <hr />
                                            <p class="cta-catalog-text"><strong><?php _e( 'CATALOGO', 'pietre-rapolano' ); ?></strong></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="text-uppercase cta-catalog-text" style="max-width: 60%;"><?php _e( 'Consulta il nostro catalogo e scopri tutte le nostre proposte', 'pietre-rapolano' ); ?></p>
                                                <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>" class="btn mb-2 btn-outline-primary" target="_blank"><?php _e( 'Vai allo shop', 'pietre-rapolano' ); ?></a>
                                            </div>
                                            <hr />
                                        <?php endif; ?>
                                        <?php if ($pulsante_progettazione) : ?>
                                            <div class="d-flex justify-content-between align-items-center py-3 gap-3">
                                                <a
                                                    href="<?php echo esc_url( apply_filters(
                                                        'wpml_translate_single_string',
                                                        'https://pdr.demo-dirweb.it/progettazione/',
                                                        'pietre-rapolano',
                                                        'Progettazione URL'
                                                    ) ); ?>"
                                                    class="btn mb-2 btn-outline-primary"
                                                    target="_blank"
                                                    title="<?php echo esc_attr( apply_filters(
                                                        'wpml_translate_single_string',
                                                        'Pagina progettazione',
                                                        'pietre-rapolano',
                                                        'Progettazione Title'
                                                    ) ); ?>"
                                                >
                                                    <?php echo esc_html( apply_filters(
                                                        'wpml_translate_single_string',
                                                        'PROGETTAZIONE',
                                                        'pietre-rapolano',
                                                        'Progettazione Text'
                                                    ) ); ?>
                                                </a>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'txt_ctas_img'):

                    // Case: TXT + CTAs + IMG.
                    $immagine_dxb = get_sub_field('immagine_dxb');
                    $titolo_sxb = get_sub_field('titolo_sxb');
                    $sottotitolo_sxb = get_sub_field('sottotitolo_sxb');
                    $testo_sxb = get_sub_field('testo_sxb');
                    $etichetta_cta_1 = get_sub_field('etichetta_cta_1');
                    $etichetta_cta_2 = get_sub_field('etichetta_cta_2');
                    $url_cta_1 = get_sub_field('url_cta_1');
                    $url_cta_2 = get_sub_field('url_cta_2');
                    $mostrare_box_catalogo = get_sub_field('mostrare_box_catalogo');
                    $mostrare_pulsante_contatti = get_sub_field('mostrare_pulsante_contatti');
                    $mostrare_pulsante_posaopera = get_sub_field('mostrare_pulsante_posaopera');
                    $mostrare_pulsante_progettazione = get_sub_field('mostrare_pulsante_progettazione');

                ?>

                    <section class="py-8" style="padding-bottom: 0px!important;">
                        <div class="container px-xl-3">
                            <div class="row">

                                <div class="col-lg-6 d-flex align-items-center">
                                    <div class="px-5 my-auto">
                                        <h3 class="internal-h3"><?php echo $titolo_sxb; ?></h3>
                                        <?php if ($sottotitolo_sxb): ?>
                                            <p class="text-uppercase cta-catalog-text"><?php echo $sottotitolo_sxb; ?></p>
                                        <?php endif; ?>
                                        <?php echo $testo_sxb; ?>
                                        <?php if ($url_cta_1): ?>
                                            <div class="d-flex justify-content-between align-items-center py-3 gap-3">
                                                <a href="<?php echo esc_url($url_cta_1); ?>" class="btn mb-2 btn-outline-primary" target="_blank" title="<?php echo $etichetta_cta_1; ?>"><?php echo $etichetta_cta_1; ?></a>
                                                <a href="<?php echo esc_url($url_cta_2); ?>" class="btn mb-2 btn-outline-primary" target="_blank" title="<?php echo $etichetta_cta_2; ?>"><?php echo $etichetta_cta_2; ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($mostrare_box_catalogo) : ?>
                                            <hr />
                                            <p class="cta-catalog-text"><strong><?php _e( 'CATALOGO', 'pietre-rapolano' ); ?></strong></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="text-uppercase cta-catalog-text" style="max-width: 60%;"><?php _e( 'Consulta il nostro catalogo e scopri tutte le nostre proposte', 'pietre-rapolano' ); ?></p>
                                                <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>" class="btn mb-2 btn-outline-primary" target="_blank"><?php _e( 'Vai allo shop', 'pietre-rapolano' ); ?></a>
                                            </div>
                                            <hr />
                                        <?php endif; ?>
                                        <?php if ( $mostrare_pulsante_contatti ) : ?>
    <div class="d-flex justify-content-between align-items-center py-3">
        <a
            href="<?php echo esc_url( apply_filters(
                'wpml_translate_single_string',
                'https://pdr.demo-dirweb.it/contatti/',
                'pietre-rapolano',
                'Contatti URL'
            ) ); ?>"
            class="btn mb-2 btn-outline-primary"
            target="_blank"
            title="<?php echo esc_attr( apply_filters(
                'wpml_translate_single_string',
                'Pagina contatti',
                'pietre-rapolano',
                'Contatti Title'
            ) ); ?>"
        >
            <?php echo esc_html( apply_filters(
                'wpml_translate_single_string',
                'CONTATTACI',
                'pietre-rapolano',
                'Contatti Text'
            ) ); ?>
        </a>
    </div>
<?php endif; ?>


<?php if ( $mostrare_pulsante_posaopera ) : ?>
    <div class="d-flex justify-content-between align-items-center py-3">
        <a
            href="<?php echo esc_url( apply_filters(
                'wpml_translate_single_string',
                'https://pdr.demo-dirweb.it/fornitura-e-posa-in-opera/',
                'pietre-rapolano',
                'Posa Opera URL'
            ) ); ?>"
            class="btn mb-2 btn-outline-primary"
            target="_blank"
            title="<?php echo esc_attr( apply_filters(
                'wpml_translate_single_string',
                'Pagina fornitura e posa in opera',
                'pietre-rapolano',
                'Posa Opera Title'
            ) ); ?>"
        >
            <?php echo esc_html( apply_filters(
                'wpml_translate_single_string',
                'FORNITURA E POSA IN OPERA',
                'pietre-rapolano',
                'Posa Opera Text'
            ) ); ?>
        </a>
    </div>
<?php endif; ?>


<?php if ( $mostrare_pulsante_progettazione ) : ?>
    <div class="d-flex justify-content-between align-items-center py-3">
        <a
            href="<?php echo esc_url( apply_filters(
                'wpml_translate_single_string',
                'https://pdr.demo-dirweb.it/progettazione/',
                'pietre-rapolano',
                'Progettazione URL'
            ) ); ?>"
            class="btn mb-2 btn-outline-primary"
            target="_blank"
            title="<?php echo esc_attr( apply_filters(
                'wpml_translate_single_string',
                'Pagina progettazione',
                'pietre-rapolano',
                'Progettazione Title'
            ) ); ?>"
        >
            <?php echo esc_html( apply_filters(
                'wpml_translate_single_string',
                'PROGETTAZIONE',
                'pietre-rapolano',
                'Progettazione Text'
            ) ); ?>
        </a>
    </div>
<?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <img title="<?php echo esc_attr($immagine_dxb['title']); ?>" class="align-left" src="<?php echo esc_url($immagine_dxb['url']); ?>" alt="<?php echo esc_attr($immagine_dxb['alt']); ?>" />
                                </div>
                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'txt_+_txt'):

                    // Case: TXT + TXT.
                    $titolo_sinistra = get_sub_field('titolo_sinistra');
                    $sottotitolo_sinistra = get_sub_field('sottotitolo_sinistra');
                    $testo_sinistra = get_sub_field('testo_sinistra');
                    $etichetta_cta_sinistra = get_sub_field('etichetta_cta_sinistra');
                    $cta_sinistra = get_sub_field('cta_sinistra');
                    $titolo_destra = get_sub_field('titolo_destra');
                    $sottotitolo_destra = get_sub_field('sottotitolo_destra');
                    $testo_destra = get_sub_field('testo_destra');
                    $etichetta_cta_destra = get_sub_field('etichetta_cta_destra');
                    $cta_destra = get_sub_field('cta_destra');
                    $mostrare_box_catalogo = get_sub_field('mostrare_box_catalogo');
                    $mostrare_box_catalogo_2 = get_sub_field('mostrare_box_catalogo_2');


                ?>

                    <section class="py-8" style="padding-bottom: 0px!important;">
                        <div class="container px-xl-3">
                            <div class="row">
                                <div class="col-lg-6 d-flex align-items-center">
                                    <div class="px-5 my-auto">
                                        <h3 class="internal-h3"><?php echo $titolo_sinistra; ?></h3>
                                        <?php if ($sottotitolo_sinistra): ?>
                                            <p class="text-uppercase cta-catalog-text"><?php echo $sottotitolo_sinistra; ?></p>
                                        <?php endif; ?>
                                        <?php echo $testo_sinistra; ?>
                                        <?php if ($cta_sinistra): ?>
                                            <div class="d-flex justify-content-between align-items-center py-3">
                                                <a href="<?php echo esc_url($cta_sinistra); ?>" class="btn mb-2 btn-outline-primary" target="_blank" title="<?php echo $etichetta_cta_sinistra; ?>"><?php echo $etichetta_cta_sinistra; ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($mostrare_box_catalogo) : ?>
                                            <hr />
                                            <p class="cta-catalog-text"><strong><?php _e( 'CATALOGO', 'pietre-rapolano' ); ?></strong></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="text-uppercase cta-catalog-text" style="max-width: 60%;"><?php _e( 'Consulta il nostro catalogo e scopri tutte le nostre proposte', 'pietre-rapolano' ); ?></p>
                                                <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>" class="btn mb-2 btn-outline-primary" target="_blank"><?php _e( 'Vai allo shop', 'pietre-rapolano' ); ?></a>
                                            </div>
                                            <hr />
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6 d-flex align-items-center">
                                    <div class="px-5 my-auto">
                                        <?php if ($titolo_destra): ?>
                                            <h3 class="internal-h3"><?php echo $titolo_destra; ?></h3>
                                        <?php endif; ?>
                                        <?php if ($sottotitolo_destra): ?>
                                            <p class="text-uppercase cta-catalog-text"><?php echo $sottotitolo_destra; ?></p>
                                        <?php endif; ?>
                                        <?php echo $testo_destra; ?>
                                        <?php if ($cta_destra): ?>
                                            <div class="d-flex justify-content-between align-items-center py-3">
                                                <a href="<?php echo esc_url($cta_destra); ?>" class="btn mb-2 btn-outline-primary" target="_blank" title="<?php echo $etichetta_cta_destra; ?>"><?php echo $etichetta_cta_destra; ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($mostrare_box_catalogo_2) : ?>
                                            <hr />
                                            <p class="cta-catalog-text"><strong><?php _e( 'CATALOGO', 'pietre-rapolano' ); ?></strong></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="text-uppercase cta-catalog-text" style="max-width: 60%;"><?php _e( 'Consulta il nostro catalogo e scopri tutte le nostre proposte', 'pietre-rapolano' ); ?></p>
                                                <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>" class="btn mb-2 btn-outline-primary" target="_blank"><?php _e( 'Vai allo shop', 'pietre-rapolano' ); ?></a>
                                            </div>
                                            <hr />
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <?php elseif (get_row_layout() == 'testo_centrato'):

                    // Case: TXT + TXT.
                    $titolo_centrato = get_sub_field('titolo_centrale_h2');
                    $testo_centrato = get_sub_field('contenuto');

                ?>

                    <section class="py-8">
                        <div class="container px-xl-3">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="px-5 my-auto">
                                        <h3 class="internal-h3 text-center"><?php echo $titolo_centrato; ?></h3>
                                        <?php echo $testo_centrato; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'gallery_fullwidth'):

                    // Case: Fullwidth gallery.
                    $titolo_gallery = get_sub_field('titolo_gallery');
                    $gallery = get_sub_field('gallery');

                ?>
                    <section id="gallery" class="bg-grey py-5">
                        <div class="container-fluid px-xl-3">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h3 class="text-center py-5"><?php echo $titolo_gallery; ?></h3>
                                    <hr class="divider my-3 mx-auto" />
                                    <?php
                                    if ($gallery && is_array($gallery)) :
                                        $slide_count = count($gallery);
                                        $group_size = 5;
                                        $page_count = ceil($slide_count / $group_size);
                                    ?>
                                        <div id="gallerySplide" class="py-5 splide custom-splide" aria-label="Gallery Carousel">
                                            <div class="splide__track">
                                                <ul class="splide__list">
                                                    <?php foreach ($gallery as $img): ?>
                                                        <li class="splide__slide text-center">
                                                            <a
                                                                href="<?php echo esc_url($img['url']); ?>"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#lightboxModal"
                                                                data-bs-img="<?php echo esc_url($img['url']); ?>"
                                                                data-bs-caption="<?php echo esc_attr($img['caption']); ?>"
                                                                class="gallery-img-link position-relative d-inline-block"
                                                                style="overflow:visible;">
                                                                <!-- Zoom Icon -->
                                                                <span class="zoom-icon" style="
                                            position: absolute;
                                            top: 16px;
                                            right: 16px;
                                            z-index: 2;
                                            display: none;
                                            transition: opacity 0.2s;
                                        ">
                                                                    <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/mage_zoom-in.svg" alt="Zoom" style="width:38px;height:38px;">
                                                                </span>
                                                                <img
                                                                    src="<?php echo esc_url($img['url']); ?>"
                                                                    alt="<?php echo esc_attr($img['alt']); ?>"
                                                                    class="img-fluid mb-3"
                                                                    style="width:380px; height:530px; object-fit:cover;">
                                                            </a>
                                                        </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>

                                        <!-- PAGINAZIONE CUSTOM SLIDE -->
                                        <div class="splide-pagination-custom mt-3 d-flex flex-column align-items-center">
                                            <div class="d-flex align-items-center justify-content-center">
                                                <button class="splide-arrow-custom prev" aria-label="Precedente"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-left.svg" /></button>
                                                <?php for ($i = 1; $i <= $page_count; $i++): ?>
                                                    <span class="splide-page-num<?php if ($i == 1) echo ' active'; ?>">
                                                        <?php echo sprintf('%02d', $i); ?>
                                                    </span>
                                                <?php endfor; ?>
                                                <button class="splide-arrow-custom next" aria-label="Successivo"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-right.svg" /></button>
                                            </div>
                                        </div>

                                        <!-- Bootstrap Lightbox Modal with navigation -->
                                        <div class="modal fade" id="lightboxModal" tabindex="-1" aria-labelledby="lightboxModalLabel" aria-hidden="true">
                                            <button type="button" class="btn btn-light position-absolute top-50 start-20 translate-middle-y ms-2" id="lightboxPrev" style="z-index:10;">&#8592;</button>
                                            <button type="button" class="btn btn-light position-absolute top-50 end-20 translate-middle-y me-2" id="lightboxNext" style="z-index:10;">&#8594;</button>
                                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                                <div class="bg-transparent border-0 position-relative">
                                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>

                                                    <div class="modal-body p-0 text-center">
                                                        <img src="" id="lightboxImage" class="img-fluid" style="max-width:100%;" alt="">
                                                        <p id="lightboxCaption" class="mt-3 text-light"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <script>
                                            document.addEventListener('DOMContentLoaded', function() {
                                                var splide = new Splide('#gallerySplide', {
                                                    type: 'loop',
                                                    perPage: 5,
                                                    perMove: 5,
                                                    gap: '1rem',
                                                    autoplay: true,
                                                    interval: 5000,
                                                    pauseOnHover: true,
                                                    arrows: false,
                                                    pagination: false,
                                                    breakpoints: {
                                                        1200: {
                                                            perPage: 3,
                                                            perMove: 3
                                                        },
                                                        768: {
                                                            perPage: 1,
                                                            perMove: 1
                                                        }
                                                    }
                                                }).mount();

                                                // Custom arrows
                                                document.querySelector('.splide-arrow-custom.prev').addEventListener('click', function() {
                                                    splide.go('<');
                                                });
                                                document.querySelector('.splide-arrow-custom.next').addEventListener('click', function() {
                                                    splide.go('>');
                                                });

                                                // Custom page numbers: scroll 5 slides per click
                                                var pageNums = document.querySelectorAll('.splide-page-num');
                                                pageNums.forEach(function(num, idx) {
                                                    num.addEventListener('click', function() {
                                                        splide.go(idx * 5);
                                                    });
                                                });
                                                splide.on('move', function(newIndex) {
                                                    var groupSize = 5;
                                                    var page = Math.floor(newIndex / groupSize);
                                                    pageNums.forEach(function(num, idx) {
                                                        num.classList.toggle('active', idx === page);
                                                    });
                                                });

                                                // Lightbox gallery logic
                                                var galleryLinks = Array.from(document.querySelectorAll('#gallerySplide a[data-bs-toggle="modal"]'));
                                                var currentIndex = 0;
                                                var lightboxModal = document.getElementById('lightboxModal');
                                                var lightboxImage = document.getElementById('lightboxImage');
                                                var lightboxCaption = document.getElementById('lightboxCaption');
                                                var lightboxPrev = document.getElementById('lightboxPrev');
                                                var lightboxNext = document.getElementById('lightboxNext');

                                                function showImage(idx) {
                                                    if (idx < 0) idx = galleryLinks.length - 1;
                                                    if (idx >= galleryLinks.length) idx = 0;
                                                    currentIndex = idx;
                                                    var link = galleryLinks[currentIndex];
                                                    var img = link.getAttribute('data-bs-img');
                                                    var caption = link.getAttribute('data-bs-caption') || '';
                                                    lightboxImage.src = img;
                                                    lightboxCaption.textContent = caption;
                                                }

                                                galleryLinks.forEach(function(link, idx) {
                                                    link.addEventListener('click', function(e) {
                                                        e.preventDefault();
                                                        showImage(idx);
                                                        var modal = bootstrap.Modal.getOrCreateInstance(lightboxModal);
                                                        modal.show();
                                                    });
                                                });

                                                lightboxPrev.addEventListener('click', function(e) {
                                                    e.preventDefault();
                                                    showImage(currentIndex - 1);
                                                });
                                                lightboxNext.addEventListener('click', function(e) {
                                                    e.preventDefault();
                                                    showImage(currentIndex + 1);
                                                });

                                                // Keyboard navigation
                                                function lightboxKeyHandler(e) {
                                                    if (e.key === 'ArrowLeft') {
                                                        showImage(currentIndex - 1);
                                                    } else if (e.key === 'ArrowRight') {
                                                        showImage(currentIndex + 1);
                                                    }
                                                }
                                                lightboxModal.addEventListener('shown.bs.modal', function() {
                                                    document.addEventListener('keydown', lightboxKeyHandler);
                                                });
                                                lightboxModal.addEventListener('hidden.bs.modal', function() {
                                                    lightboxImage.src = '';
                                                    lightboxCaption.textContent = '';
                                                    document.removeEventListener('keydown', lightboxKeyHandler);
                                                });

                                                // Show zoom icon on hover
                                                document.querySelectorAll('.gallery-img-link').forEach(function(link) {
                                                    link.addEventListener('mouseenter', function() {
                                                        var icon = this.querySelector('.zoom-icon');
                                                        if (icon) icon.style.display = 'block';
                                                    });
                                                    link.addEventListener('mouseleave', function() {
                                                        var icon = this.querySelector('.zoom-icon');
                                                        if (icon) icon.style.display = 'none';
                                                    });
                                                });
                                            });
                                        </script>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </section>

                <?php elseif (get_row_layout() == 'prodotti'):

                    // Case: Prodotti.
                    $prodotti = get_sub_field('prodotti');
                ?>
                    <section id="prodotti" class="py-8">
                        <div class="container px-xl-3">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h3 class="text-center"><?php _e( 'Scopri i nostri prodotti', 'pietre-rapolano' ); ?></h3>
                                    <p class="text-center"><?php _e( 'SCEGLI IL PRODOTTO E CALCOLA IL PREVENTIVO', 'pietre-rapolano' ); ?></p>
                                    <div class="clearx2"></div>
                                    <hr class="divider my-3 mx-auto">
                                    <div class="clearx2"></div>
                                    <?php
                                    if ($prodotti && is_array($prodotti)) :
                                    ?>
                                        <div id="prodottiSplide" class="splide custom-splide" aria-label="Prodotti Carousel">
                                            <div class="splide__track">
                                                <ul class="splide__list">
                                                    <?php foreach ($prodotti as $prodotto) :
                                                        $prodotto_id = $prodotto->ID;
                                                        $img_url = get_the_post_thumbnail_url($prodotto_id, 'full');
                                                        $titolo = get_the_title($prodotto_id);
                                                        $link = get_permalink($prodotto_id);
                                                    ?>
                                                        <li class="splide__slide text-center">
                                                            <?php if ($img_url): ?>
                                                                <a href="<?php echo esc_url($link); ?>">
                                                                    <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($titolo); ?>" class="img-fluid mb-3" style="max-height:350px;object-fit:cover;min-height:250px;">
                                                                </a>
                                                            <?php endif; ?>
                                                            <div class="prodotto-details">
                                                                <a href="<?php echo esc_url($link); ?>" class="prodotto-title d-block mt-2" style="font-weight:600;">
                                                                    <?php echo esc_html($titolo); ?>
                                                                </a>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>

                                    <?php endif; ?>
                                    <script>
                                        document.addEventListener('DOMContentLoaded', function() {
                                            var splide = new Splide('#prodottiSplide', {
                                                type: 'loop',
                                                perPage: 5,
                                                perMove: 1,
                                                gap: '2rem',
                                                autoplay: true,
                                                interval: 7000,
                                                pauseOnHover: true,
                                                arrows: false,
                                                pagination: false,
                                                breakpoints: {
                                                    1200: {
                                                        perPage: 3
                                                    },
                                                    768: {
                                                        perPage: 1
                                                    }
                                                }
                                            }).mount();
                                        });
                                    </script>
                                </div>
                            </div>
                        </div>
                    </section>

                    <?php elseif (get_row_layout() == 'lavori'):

                    // Case: Lavori.
                    // Recupera i progetti dal sottocampo relazione "tag_progetti_da_mostrare"
                    $progetti = get_sub_field('tag_progetti_da_mostrare');
                    if ($progetti && is_array($progetti)) :
                    ?>
                        <section id="progetti-sub" class="bg-grey py-8">
                            <div class="container px-xl-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <h3 class="text-center"><?php _e( 'Alcune nostre realizzazioni', 'pietre-rapolano' ); ?></h3>
                                        <p class="text-center"><?php _e( 'SCOPRI I PROGETTI', 'pietre-rapolano' ); ?></p>
                                        <hr class="divider my-3 mx-auto" />
                                        <div class="row justify-content-center">
                                            <?php if (!empty($progetti) && is_array($progetti)) : ?>
                                                <div id="progettiSplide" class="splide custom-splide" aria-label="Progetti Carousel">
                                                    <div class="splide__track">
                                                        <ul class="splide__list">
                                                            <?php foreach ($progetti as $progetto) :
                                                                $progetto_id = is_object($progetto) ? $progetto->ID : $progetto;
                                                                $acf_img = get_field('immagine_progetto', $progetto_id);

                                                                $bg_url = '';
                                                                if ($acf_img) {
                                                                    $bg_url = is_array($acf_img) ? $acf_img['url'] : $acf_img;
                                                                }
                                                            ?>
                                                                <li class="splide__slide">
                                                                    <a href="<?php echo esc_url(get_permalink($progetto_id)); ?>" class="text-decoration-none" style="color:white;">
                                                                        <div class="progetto-card">
                                                                            <div class="progetto-bg" style="background-image: url('<?php echo esc_url($bg_url); ?>');"></div>
                                                                            <div class="progetto-overlay"></div>
                                                                            <h5 class="progetto-title"><?php echo esc_html(get_the_title($progetto_id)); ?></h5>
                                                                            <span class="progetto-scopri">
                                                                                <?php _e( 'Scopri il progetto', 'pietre-rapolano' ); ?>
                                                                                <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/arrow-blog.svg"
                                                                                    alt="icona scopri" />
                                                                            </span>
                                                                        </div>
                                                                    </a>
                                                                </li>
                                                            <?php endforeach; ?>
                                                        </ul>
                                                    </div>
                                                </div>
     

                                                <script>
                                                    document.addEventListener('DOMContentLoaded', function() {
                                                        var splide = new Splide('#progettiSplide', {
                                                            type: 'loop',
                                                            perPage: 3,
                                                            perMove: 1,
                                                            gap: '2rem',
                                                            autoplay: true,
                                                            interval: 3000,
                                                            pauseOnHover: true,
                                                            arrows: true,
                                                            pagination: false,
                                                            breakpoints: {
                                                                1200: {
                                                                    perPage: 2
                                                                },
                                                                768: {
                                                                    perPage: 1
                                                                }
                                                            }
                                                        });
                                                        splide.mount();
                                                    });
                                                </script>
                                            <?php endif; ?>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    <?php
                    endif;
                    ?>

        <?php endif;

            // End loop.
            endwhile;
        endif; ?>

<?php endwhile;

else :
    _e('Sorry, no posts matched your criteria.', 'pietre-rapolano');
endif;

get_footer();
