<?php
/**
 * Template Name: Account Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center"><?php the_title(); ?></h1>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
				}
				?>
				<div class="clear"></div>
                <div class="clear"></div>
			</div>
		</div>
	</div>
</section>
<section class="bg-white">
    <div id="container-content-page" class="container">
    <div class="row">
        <div class="col-lg-12 py-5">
            <?php 

            if ( have_posts() ) : 
                while ( have_posts() ) : the_post();
                    the_content();
                endwhile;
            else :
                _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
            endif;
            ?>
        </div>
    </div>
</div>
</section>


<?php get_footer();