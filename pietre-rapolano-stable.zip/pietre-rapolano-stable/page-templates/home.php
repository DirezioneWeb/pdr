<?php
/**
 * Template Name: Home Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="hero" class="bg-light">
		<?php
			echo do_shortcode('[slider_video]');
		?> 
</section>
<section id="azienda" class="py-0"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto" id="mobile-full">
				<?php 
				$image = get_field('immagine_sezione_1');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
			<div class="col-lg-6 my-auto">
				<div class="px-8">
					<h2><?php echo (get_field('titolo_sezione_1')); ?></h2>
					<p><?php echo (get_field('testo_sezione_1')); ?></p>
					<a href="<?php echo (get_field('link_sezione_1')); ?>" title="Link azienda" class="btn mb-2 btn-outline-primary"><?php _e( 'VAI ALL\'AZIENDA', 'pietre-rapolano' ); ?></a>
                    <div class="clear"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="idee"> 
	<div class="container px-xl-3">
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-6 my-auto">
				<div class="px-7">
					<h2><?php echo (get_field('titolo_sezione_2')); ?></h2>
					<p><?php echo (get_field('testo_sezione_2')); ?></p>
                    <div class="clear"></div>
					<div class="row">

                        <!-- TRAVERTINO -->
                        <div class="col-md-6 mb-2">
                            <p class="uppercase" style="margin-bottom:0;">
                                <strong><?php echo esc_html__( 'Ambienti in travertino', 'pietre-rapolano' ); ?></strong>
                            </p>

                            <ul class="category-list">
                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/bagno/', 'pietre-rapolano', 'Bagno Travertino URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Bagno', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/cucina/', 'pietre-rapolano', 'Cucina Travertino URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Cucina', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/soggiorno/', 'pietre-rapolano', 'Soggiorno Travertino URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Soggiorno', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/piscine/', 'pietre-rapolano', 'Piscina Travertino URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Piscina & SPA', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/esterni/', 'pietre-rapolano', 'Esterni Travertino URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Esterni', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- MARMO -->
                        <div class="col-md-6 mb-2">
                            <p class="uppercase" style="margin-bottom:0;">
                                <strong><?php echo esc_html__( 'Ambienti in marmo', 'pietre-rapolano' ); ?></strong>
                            </p>

                            <ul class="category-list">
                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/bagni-in-marmo/', 'pietre-rapolano', 'Bagno Marmo URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Bagno', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/cucine-in-marmo/', 'pietre-rapolano', 'Cucina Marmo URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Cucina', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/soggiorni-in-marmo/', 'pietre-rapolano', 'Soggiorno Marmo URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Soggiorno', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- CATALOGO -->
                        <div class="col-md-12 mb-2">
                            <p class="uppercase" style="margin-bottom:0;">
                                <strong><?php echo esc_html__( 'Catalogo, materiali, finiture e colori', 'pietre-rapolano' ); ?></strong>
                            </p>

                            <ul class="category-list">
                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/catalogo/', 'pietre-rapolano', 'Catalogo URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Vedi tutti i prodotti', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- PIETRA -->
                        <div class="col-md-6 mb-2">
                            <p class="uppercase" style="margin-bottom:0;">
                                <strong><?php echo esc_html__( 'Ambienti in pietra', 'pietre-rapolano' ); ?></strong>
                            </p>

                            <ul class="category-list">
                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/caminetti-in-pietra/', 'pietre-rapolano', 'Caminetti URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Caminetti', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/copertine-e-cordoli/', 'pietre-rapolano', 'Copertine e Cordoli URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Copertine e Cordoli', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/pavimenti-e-rivestimenti-in-pietra/', 'pietre-rapolano', 'Pavimenti e Rivestimenti URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Pavimenti e Rivestimenti', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                 <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/scale-in-pietra-serena/', 'pietre-rapolano', 'Scale in Pietra Serena URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Scale', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/soglie-e-davanzali-in-pietra/', 'pietre-rapolano', 'Soglie e Davanzali URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Soglie e Davanzali', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- FALEGNAMERIA -->
                        <div class="col-md-6 mb-2">
                            <p class="uppercase" style="margin-bottom:0;">
                                <strong><?php echo esc_html__( 'Falegnameria', 'pietre-rapolano' ); ?></strong>
                            </p>

                            <ul class="category-list">
                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/falegnameria-artigianale/', 'pietre-rapolano', 'Falegnameria URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Falegnameria', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/arredi-bagno-in-legno/', 'pietre-rapolano', 'Arredi Bagno URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Arredi Bagno', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/arredi-cucina-in-legno/', 'pietre-rapolano', 'Arredi Cucina URL' ) ); ?>">
                                        <span><?php echo esc_html__( 'Arredi Cucina', 'pietre-rapolano' ); ?></span>
                                        <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/09/arrow-right-45.svg" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>

                    </div>

                    </div>
				</div>
			<div class="col-lg-6" id="mobile-full">
			<?php 
				$image = get_field('immagine_sezione_2');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" id="home-img" class="align-left responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
				<div class="clear"></div>
				<?php 
				$image = get_field('immagine_piccola_2');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" id="home-img-mini" class="align-left small-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<section id="progetti" class="py-5"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto" id="mobile-full">
				<?php 
				$image = get_field('immagine_sezione_3');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
			<div class="col-lg-6 my-auto">
				<div class="px-8">
					<h2><?php echo (get_field('titolo_sezione_3')); ?></h2>
					<p><?php echo (get_field('testo_sezione_3')); ?></p>
					<a href="<?php echo (get_field('link_sezione_3')); ?>" title="Link progetti" class="btn mb-2 btn-outline-primary"><?php _e( 'VAI AI PROGETTI', 'pietre-rapolano' ); ?></a>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="cta" class="py-10"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-light text-center"><?php echo (get_field('titolo_cta')); ?></h3>
					<p class="text-light text-center"><?php echo (get_field('testo_cta')); ?></p>
					<div class="mx-auto" style="width: 170px;"><a href="<?php echo (get_field('link_cta')); ?>" title="Link progetti" class="btn mb-2 btn-outline-light"><?php _e( 'VAI ALLO SHOP', 'pietre-rapolano' ); ?></a></div>
			</div>
		</div>
	</div>
</section>
<section id="blog" class="py-5 px-8"> 
	<div class="container-fluid px-xl-3">
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center py-5"><?php _e( 'News dal blog', 'pietre-rapolano' ); ?></h3>
                <?php
                $current_language = apply_filters('wpml_current_language', null);
                $args = [
                    'post_type' => 'post',
                    'posts_per_page' => 16,
                    'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                    'language' => $current_language
                ];
                $feedback_query = new WP_Query($args);

                if ($feedback_query->have_posts()) :
                    $slide_count = $feedback_query->post_count;
                ?>
    <div id="feedbackSplide" class="splide custom-splide" aria-label="Feedback Carousel">
        <div class="splide__track">
            <ul class="splide__list">
                <?php while ($feedback_query->have_posts()) : $feedback_query->the_post(); ?>
                    <li class="splide__slide">
                        <div class="article-card" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'large'); ?>');">
                            <div class="article-overlay">
                                <div class="article-category">
                                    <?php
                                    $category = get_the_category();
                                    if ($category) {
                                        echo esc_html($category[0]->name);
                                    }
                                    ?>
                                </div>
                                <div class="article-title">
                                    <?php the_title(); ?>
                                </div>
                                <div class="article-bottom">
                                    <span class="article-date">
                                        <?php echo get_the_date('j F Y'); ?>
                                    </span>
                                    <a href="<?php the_permalink(); ?>" class="article-link"><?php _e( 'Leggi di più', 'pietre-rapolano' ); ?></a>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endwhile; wp_reset_postdata(); ?>
            </ul>
        </div>
    </div>

    <!-- PAGINAZIONE CUSTOM SLIDE -->
	 <?php
                    $group_size = 5;
                    $page_count = ceil($slide_count / $group_size);
                ?>
    <div class="splide-pagination-custom mt-5 d-flex flex-column align-items-center">
    <div class="d-flex align-items-center justify-content-center">
        <button class="splide-arrow-custom prev" aria-label="Precedente"><img style="width: 14px;" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/left-arrow.svg"/></button>
        <?php for ($i = 1; $i <= $page_count; $i++): ?>
            <span class="splide-page-num<?php if ($i == 1) echo ' active'; ?>"><?php echo sprintf('%02d', $i); ?></span>
        <?php endfor; ?>
        <button class="splide-arrow-custom next" aria-label="Successivo"><img style="width: 14px;" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/right-arrow.svg"/></button>
        <span class="mx-2">|</span>
        <a href="<?php echo get_post_type_archive_link('post'); ?>" class="all-articles ms-1"><?php _e( 'Tutti gli articoli', 'pietre-rapolano' ); ?></a>
    </div>
</div>
<?php endif; ?>
					<script>
					document.addEventListener('DOMContentLoaded', function () {
  var splide = new Splide('#feedbackSplide', {
    type       : 'loop',
    perPage    : 4,
    perMove    : 1,
    gap        : '2rem',
    autoplay   : true,
    interval   : 5000,
    pauseOnHover: true,
    arrows     : false, // Disabilita le frecce native Splide
    pagination : false,
    breakpoints: {
        1200: { perPage: 3, perMove: 3 },
        993: { perPage: 3, perMove: 3 },
        992: { perPage: 2, perMove: 2 },
        768: { perPage: 1, perMove: 1 }
    }
  }).mount();

  // Gestione frecce custom
  document.querySelector('.splide-arrow-custom.prev').addEventListener('click', function() {
    splide.go('<');
  });
  document.querySelector('.splide-arrow-custom.next').addEventListener('click', function() {
    splide.go('>');
  });

  // Gestione numeri custom
  var pageNums = document.querySelectorAll('.splide-page-num');
  pageNums.forEach(function(num, idx) {
    num.addEventListener('click', function() {
      splide.go(idx);
    });
  });

  // Aggiorna attivo
  splide.on('move', function(newIndex){
    var total = pageNums.length;
    var realIndex = (newIndex % total + total) % total; // per evitare indici negativi
    pageNums.forEach(function(num, idx){
      num.classList.toggle('active', idx === realIndex);
    });
  });
});					</script>
			</div>
		</div>
	</div>
</section>
<section id="cta-footer" class="py-10"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12">
				<p class="text-center text-light lead"><?php _e( 'Richiedi informazioni, una consulenza o un preventivo', 'pietre-rapolano' ); ?></p>
                <div class="mx-auto" style="width: 170px;"><a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/contatti/', 'pietre-rapolano', 'Contatti URL' ) ); ?>" title="<?php echo esc_attr( apply_filters( 'wpml_translate_single_string', 'Link contatti', 'pietre-rapolano', 'Link contatti' ) ); ?>" class="btn mb-2 btn-outline-light"><?php _e( 'CONTATTACI', 'pietre-rapolano' ); ?></a></div>
			</div>
		</div>
	</div>
</section>    
    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
