<?php
/**
 * Template Name: About Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto">
				<h1 id="title-about" class="page-title"><?php the_title(); ?></h1>
				<div id="extender-about" class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p class="bread-about" id="breadcrumbs">','</p>' );
				}
				?>
			</div>
			<div class="col-lg-6 my-auto">
				
			</div>
		</div>
	</div>
</section>
<section id="sup-head"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 d-flex align-items-center">
				<div class="px-5 py-5">
					<h2><?php echo (get_field('titolo_blocco_1')); ?></h2>
					<?php echo (get_field('testo_blocco_1')); ?>
					
				</div>
			</div>
			<div class="col-lg-6">
			<video class="video-about" controls poster="<?php echo (get_field('immagine_video')); ?>" style="width: 100%;">
			  <source src="<?php echo (get_field('url_video_1')); ?>" type="video/mp4">
			  Your browser does not support the video tag.
			</video> 
				<div class="clear"></div>
				<?php 
				$image = get_field('immagine_piccola_1');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="align-left" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<section id="progetti" class="py-5"> 
	<div class="container px-xl-3">
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-6 my-auto" id="mobile-full">
				<?php 
				$image = get_field('immagine_2');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
			<div class="col-lg-6 my-auto">
				<div class="px-5">
					<div class="clear"></div>
					<h3><?php echo (get_field('titolo_blocco_2')); ?></h3>
					<?php echo (get_field('testo_blocco_2')); ?>
					<div class="clearx2"></div>
					<div class="cta-contact">
						<p class="cta-contact-text"><?php _e( 'Hai bisogno di maggiori informazioni?', 'pietre-rapolano' ); ?></p>
						<p class="cta-contact-text"><a href="<?php echo esc_url( apply_filters( 'wpml_translate_single_string', 'https://pdr.demo-dirweb.it/contatti/', 'pietre-rapolano', 'Contatti URL' ) ); ?>" title="<?php echo esc_attr( apply_filters( 'wpml_translate_single_string', 'Link contatti', 'pietre-rapolano', 'Link contatti' ) ); ?>" class="text-decoration-none"><u><?php _e( 'Contattaci', 'pietre-rapolano' ); ?> <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4.1499 9.92383L16.186 9.92383M16.186 9.92383L11.6725 14.7383M16.186 9.92383L11.6725 5.10938" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg></u></a></p>
<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="py-300 cta-background" style="background:url(<?php echo (get_field('immagine_fondo_cta')); ?> ) center right;background-repeat: no-repeat;background-size: cover;"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 col-xs-12">
				<h3 class="text-light"><?php echo (get_field('titolo_cta')); ?></h3>
					<p class="text-light"><?php echo (get_field('testo_cta')); ?></p>
			</div>
			<div class="col-lg-6 col-xs-12">
			</div>
		</div>
	</div>
</section>
<section class="bg-lght py-8"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 col-xs-12 my-auto">
				<div class="px-5 py-3">
				<h3><?php echo (get_field('titolo_blocco_3')); ?></h3>
					<?php echo (get_field('testo_blocco_3')); ?>
				</div>
			</div>
			<div class="col-lg-6 col-xs-12 my-auto" id="mobile-full">
				<?php 
				$image = get_field('immagine_3');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
			</div>
		</div>
		
		<div class="row flex-column-reverse flex-lg-row">
			<div class="col-lg-6 col-xs-12 my-auto" id="mobile-full">
				
				<?php 
				$image = get_field('immagine_4');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="aligncenter responsive-image" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
				<?php endif; ?>
				<?php 
				$image = get_field('immagine_5');
				if( !empty( $image ) ): ?>
				    <img title="<?php echo esc_attr($image['title']); ?>" class="float-end" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>"/>
				<?php endif; ?>

			</div>
			<div class="col-lg-6 col-xs-12 my-auto">
				<div class="clear"></div>
				<div class="px-5 py-3">
				<h3><?php echo (get_field('titolo_blocco_4')); ?></h3>
					<?php echo (get_field('testo_blocco_4')); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="team" class="bg-grey py-8"> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center py-5"><?php _e( 'La Squadra di Progettazione e Design', 'pietre-rapolano' ); ?></h3>
				<p class="text-center"><?php _e( 'Il nostro team dedicato di import/export, project manager e ufficio clienti collabora con te per sviluppare sempre nuove soluzioni di pavimentazione e rivestimento.', 'pietre-rapolano' ); ?></p>
				<div class="extender-mini my-3 mx-auto"></div>
			</div>
				<?php
				if (have_rows('membri_del_team')) :
				    $membri_del_team = get_field('membri_del_team');
				    $slide_count = count($membri_del_team);
				?>
					<?php while (have_rows('membri_del_team')) : the_row();
						$foto_membro = get_sub_field('foto_membro');
						$nome_membro = get_sub_field('nome_membro');
						$ruolo_membro = get_sub_field('ruolo_membro');
					?>
						<div id="feedbackSplide" class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
							<div class="team-card" style="background-image: url('<?php echo esc_url($foto_membro['url']); ?>');"></div>
							<div class="member-details">
								<h5 class="member-name"><?php echo esc_html($nome_membro); ?></h5>
								<p class="member-role"><?php echo esc_html($ruolo_membro); ?></p>
							</div>
						</div>
					<?php endwhile; ?>
				
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<section id="cta-footer-contact" class="py-150">
    <!-- Overlay per l'effetto blur -->
    <div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center text-light"><?php _e( 'Contattaci per informazioni', 'pietre-rapolano' ); ?></h3>
				<p class="text-center text-light uppercase"><?php _e( 'o per richiedere un preventivo personalizzato', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php 
				$current_lang = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'it';
				if ($current_lang == 'en') {
					echo do_shortcode('[contact-form-7 id="143fa53" title="Modulo di contatto CTA ENG"]');
				} elseif ($current_lang == 'de') {
					echo do_shortcode('[contact-form-7 id="acc043e" title="Modulo di contatto CTA DEU"]');
				} else {
					echo do_shortcode('[contact-form-7 id="5fbf157" title="Modulo di contatto CTA ITA"]');
				}
				?>
			</div>
		</div>
	</div>
</section>
    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();