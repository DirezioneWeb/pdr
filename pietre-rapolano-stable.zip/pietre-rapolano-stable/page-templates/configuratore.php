<?php
/**
 * Template Name: Configurator Template
 *
 * Template for displaying a page just with the header and footer area and a "naked" content area in between.
 * Good for landingpages and other types of pages where you want to add a lot of custom markup.
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); ?>

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-12 my-auto">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
				}
				?>
			</div>

		</div>
	</div>
</section>
<div class="clearx2"></div>
<div class="clearx2"></div>
<section> 
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 d-flex my-auto">
					<?php the_content();?>
			</div>
			
		</div>
	</div>
</section>
<div class="clearx2"></div>
<div class="clearx2"></div>

    <?php endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
endif;

get_footer();
