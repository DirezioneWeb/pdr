<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package picostrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
 
?>
<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto  text-center">
				<h1 class="page-title"><?php _e( 'Oops', 'pietre-rapolano' ); ?></h1>
				<h5 class="text-center"><?php _e( 'La pagina non esiste.<br/>Controlla di nuovo il link o usa la funzione di ricerca per trovare ciò che cerchi.', 'pietre-rapolano' ); ?></h5>
				<div class="clear"></div>
				<a class="btn btn-primary" href="<?php bloginfo('url') ?>" role="button"><?php _e( 'Continua lo shopping', 'pietre-rapolano' ); ?></a>
				<div class="clear"></div>
                <div class="clear"></div>
			</div>
		</div>
	</div>
</section>

	<div class="bg-transparent text-center w-100">
		<img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/07/404-page-1.jpg" class="responsive-image" alt="404 page not found"/>
		
	</div>

<?php
get_footer();
