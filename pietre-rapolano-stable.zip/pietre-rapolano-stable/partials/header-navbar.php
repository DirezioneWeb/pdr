<!-- ******************* The Navbar Area ******************* -->
<div id="wrapper-navbar" itemscope itemtype="http://schema.org/WebSite">

	<a class="skip-link visually-hidden-focusable" href="#theme-main">
    <?php esc_html_e( 'Skip to content', 'pietre-rapolano' ); ?>
</a>



	<nav data-bs-theme="<?php echo get_theme_mod('picostrap_header_navbar_color_scheme_attr', 'dark') ?>"
		class="navbar <?php echo get_theme_mod('picostrap_header_navbar_expand', 'navbar-expand-lg'); ?> <?php echo get_theme_mod('picostrap_header_navbar_position') . " " . get_theme_mod('picostrap_header_navbar_color_choice', 'bg-dark'); ?>"
		aria-label="Main Navigation">
		<div class="container-fluid">
			<div class="row align-items-center w-100">
				<div class="col-8 col-sm-4 col-md-4 col-lg-3 col-xl-3 col-xxl-2">
					<div id="logo-tagline-wrap">
						<!-- Your site title as branding in the menu -->
						<?php if (!has_custom_logo()) { ?>

							<?php if (is_front_page() && is_home()): ?>

								<div class="navbar-brand mb-0 h3"><a rel="home" href="<?php echo esc_url(home_url('/')); ?>"
										title="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>" itemprop="url">
										<?php bloginfo('name'); ?>
									</a></div>

							<?php else: ?>

								<a class="navbar-brand mb-0 h3" rel="home" href="<?php echo esc_url(home_url('/')); ?>"
									title="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>" itemprop="url">
									<?php bloginfo('name'); ?>
								</a>

							<?php endif; ?>


						<?php } else {
							the_custom_logo();
						} ?><!-- end custom logo -->


						<?php if (!get_theme_mod('header_disable_tagline')): ?>
							<small id="top-description" class="text-muted d-none d-md-block mt-n2">
								<?php bloginfo("description") ?>
							</small>
						<?php endif ?>


					</div> <!-- /logo-tagline-wrap -->

				</div>

				<div id="colonna-menu" class="col-lg-9 col-xl-9 col-xxl-7 d-none d-md-none d-lg-block">

					<div class="d-none d-lg-block">
						<?php echo (do_shortcode('[megamenu]')); ?>
					</div>

				</div>

				<div class="col-4 col-sm-8 col-md-8 col-lg-12 col-xl-12 col-xxl-3 header-right d-flex justify-content-center align-items-center" style="padding: 0;">
					<div id="level-icons" class="d-md-flex justify-content-end align-items-center w-100">
						<div class="search-icon">
							<a class="link-header" href="#" id="openSearchOverlay"
							   title="<?php echo esc_attr__( 'CERCA', 'pietre-rapolano' ); ?>">

							    <span class="search-text">
							        <?php echo esc_html__( 'CERCA', 'pietre-rapolano' ); ?>
							    </span>

							    <img style="margin-left:5px;"
							         src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/tabler_search.svg"
							         alt="<?php echo esc_attr__( 'CERCA', 'pietre-rapolano' ); ?>" />
							</a>

						</div>
						<div id="searchOverlay" class="search-overlay">
							<div class="container-fluid">
								<div class="row w-100">
									<div class="col-2">
										<div id="logo-tagline-wrap">
											<!-- Your site title as branding in the menu -->
											<?php if (!has_custom_logo()) { ?>

												<?php if (is_front_page() && is_home()): ?>

													<div class="navbar-brand mb-0 h3"><a rel="home" href="<?php echo esc_url(home_url('/')); ?>"
															title="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>" itemprop="url">
															<?php bloginfo('name'); ?>
														</a></div>

												<?php else: ?>

													<a class="navbar-brand mb-0 h3" rel="home" href="<?php echo esc_url(home_url('/')); ?>"
														title="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>" itemprop="url">
														<?php bloginfo('name'); ?>
													</a>

												<?php endif; ?>


											<?php } else {
												the_custom_logo();
											} ?><!-- end custom logo -->


											<?php if (!get_theme_mod('header_disable_tagline')): ?>
												<small id="top-description" class="text-muted d-none d-md-block mt-n2">
													<?php bloginfo("description") ?>
												</small>
											<?php endif ?>


										</div> <!-- /logo-tagline-wrap -->

									</div>

									<div class="col-7 col-lg-6 d-none d-lg-block" style="padding-top: 10%;">
										<?php echo (do_shortcode('[wd_asp id=1]')); ?>

									</div>
									<div class="col-3 col-lg-4 header-right d-flex justify-content-center" style="height: 53px;">
										<button id="closeSearchOverlay" class="close-button">&times;</button>
										<div class="d-none d-md-flex justify-content-end w-100">

											<?php
											$account_url = apply_filters(
											    'wpml_translate_single_string',
											    'https://pdr.demo-dirweb.it/mio-account/',
											    'pietre-rapolano',
											    'Account URL'
											);

											$account_text = apply_filters(
											    'wpml_translate_single_string',
											    'ACCOUNT',
											    'pietre-rapolano',
											    'Account Text'
											);

											if ( is_user_logged_in() ) {
											    echo '<a class="link-header" href="' . esc_url( $account_url ) . '" title="' . esc_attr( $account_text ) . '">' .
											            esc_html( $account_text ) .
											         '</a>';
											} else {
											    echo '<a class="link-header" href="' . esc_url( $account_url ) . '" title="' . esc_attr__( 'Login', 'pietre-rapolano' ) . '">' .
											            esc_html( $account_text ) .
											         '</a>';
											}
											?>

											<!-- Custom SVG Search Icon -->
											<a class="link-header"
											   href="<?php echo esc_url( apply_filters(
											       'wpml_translate_single_string',
											       'https://pdr.demo-dirweb.it/preferiti/',
											       'pietre-rapolano',
											       'Wishlist URL'
											   ) ); ?>"
											   title="<?php echo esc_attr__( 'Wishlist', 'pietre-rapolano' ); ?>">

											    <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/wishlist.svg"
											         alt="<?php echo esc_attr__( 'Wishlist', 'pietre-rapolano' ); ?>" />
											</a>

											<a class="link-header"
											   href="<?php echo esc_url( apply_filters(
											       'wpml_translate_single_string',
											       'https://pdr.demo-dirweb.it/carrello/',
											       'pietre-rapolano',
											       'Cart URL'
											   ) ); ?>"
											   title="<?php echo esc_attr__( 'Carrello', 'pietre-rapolano' ); ?>">

											    <img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/cart.svg"
											         alt="<?php echo esc_attr__( 'Carrello', 'pietre-rapolano' ); ?>" />

											    <span>(<?php echo WC()->cart->get_cart_contents_count(); ?>)</span>
											</a>

											<a class="link-header" href="#" title="Lingue">ITA</a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
						if (is_user_logged_in()) {
							echo '<a class="link-header" href="' . esc_url(apply_filters('wpml_translate_single_string', 'https://pdr.demo-dirweb.it/mio-account/', 'pietre-rapolano', 'Profile Link URL')) . '" title="Account">' . esc_html(apply_filters('wpml_translate_single_string', 'ACCOUNT', 'pietre-rapolano', 'Profile Link Text')) . '</a>';
						} else {
							echo '<a class="link-header" href="https://pdr.demo-dirweb.it/mio-account/" title="Login">ACCOUNT</a>';
						}
						?>
						<!-- Custom SVG Search Icon -->
						<a class="link-header" href="<?php echo esc_url( apply_filters(
											       'wpml_translate_single_string',
											       'https://pdr.demo-dirweb.it/preferiti/',
											       'pietre-rapolano',
											       'Wishlist URL'
											   ) ); ?>" title="Wishlist"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/wishlist.svg" /> </a>
						<a class="link-header" href="<?php echo esc_url( apply_filters(
											       'wpml_translate_single_string',
											       'https://pdr.demo-dirweb.it/carrello/',
											       'pietre-rapolano',
											       'Cart URL'
											   ) ); ?>" title="Carrello"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/cart.svg" /> <span>(<?php echo WC()->cart->get_cart_contents_count(); ?>)</span></a>


						<?php if ( function_exists( 'icl_get_languages' ) ) :
							$languages = icl_get_languages( 'skip_missing=0&orderby=code' );
							
							if ( ! empty( $languages ) ) :
								echo '<div class="wpml-language-switcher link-header dropdown">';
								
								// Find active language
								$active_lang = '';
								foreach ( $languages as $lang ) {
									if ( $lang['active'] ) {
										$active_lang = strtoupper( $lang['language_code'] );
										break;
									}
								}
								
								echo '<button class="btn btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">' . esc_html( $active_lang ) . '</button>';
								echo '<ul class="dropdown-menu">';
								
								foreach ( $languages as $lang ) {
									if ( ! $lang['active'] ) {
										echo '<li><a class="dropdown-item" href="' . esc_url( $lang['url'] ) . '" lang="' . esc_attr( $lang['language_code'] ) . '">' .
												esc_html( strtoupper( $lang['language_code'] ) ) .
											 '</a></li>';
									}
								}
								
								echo '</ul></div>';
							endif;
						endif;
						?>


						<div class="d-block d-lg-none">
							<?php echo (do_shortcode('[megamenu]')); ?>
						</div>
					</div>
				</div>

			</div>

		</div>

</div> <!-- .container -->
</nav> <!-- .site-navigation -->
</div><!-- #wrapper-navbar end -->