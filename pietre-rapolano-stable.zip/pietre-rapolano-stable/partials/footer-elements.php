<?php

if (is_active_sidebar( 'footerfull' )): ?>
    <div class="text-light wrapper bg-dark py-6" id="wrapper-footer-widgets">
        
        <div class="container mb-5">
            
            <div class="row">
                <?php dynamic_sidebar( 'footerfull' ); ?>
            </div>

        </div>
    </div>
<?php endif ?>

<div class="wrapper bg-dark py-1" id="wrapper-footer-colophon">
    <div class="container">

        <div class="row">

            <div class="col">

                <footer class="site-footer" id="colophon">

                    <div class="site-info text-light text-right">

                        <img style="max-width: 550px;" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/06/payment-cards.png"title="Payment Cards" />

                    </div><!-- .site-info -->

                </footer><!-- #colophon -->

            </div><!--col end -->

        </div><!-- row end -->

    </div><!-- container end -->

</div><!-- wrapper end -->

<div class="wrapper bg-dark py-3" id="wrapper-footer-colophon">
    <div class="container">

        <div class="row">

            <div class="col">

                <footer class="site-footer" id="colophon">

                    <div class="site-info text-right" style="color:#D9D9D9;font-size: 13px;">

                        <?php picostrap_site_info(); ?>

                    </div><!-- .site-info -->

                </footer><!-- #colophon -->

            </div><!--col end -->

        </div><!-- row end -->

    </div><!-- container end -->

</div><!-- wrapper end -->