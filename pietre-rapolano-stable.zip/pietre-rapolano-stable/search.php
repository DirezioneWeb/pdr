<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
?>
  
 <section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center"><?php 
        printf(
            /* translators: %s: query term */
            esc_html__( 'Search Results for: %s', 'picostrap5' ),
            '<span class="text-light">"' . get_search_query() . '"</span>'
        );
        ?></h1>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
				}
				?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</section>


<section class="album py-7 bg-light">
  <div class="container">
    <div class="row">
    <?php if ( have_posts() ) : ?>

<ul class="products row list-unstyled" style="display:flex;flex-wrap:wrap;">

<?php
while ( have_posts() ) :
    the_post();

    $post_type = get_post_type();
    $is_product = ( $post_type === 'product' && function_exists( 'wc_get_product' ) );

    $product = $is_product ? wc_get_product( get_the_ID() ) : null;

    // Dati comuni
    $link  = get_permalink();
    $title = get_the_title();
    $img   = get_the_post_thumbnail_url(
        get_the_ID(),
        $is_product ? 'woocommerce_thumbnail' : 'large'
    );

    // Classi
    if ( $is_product ) {
        $classes = wc_get_product_class( '', $product );
    } else {
        $classes = 'post-result';
    }

    $classes .= ' col-lg-3 col-md-4 col-sm-6 col-12 mb-4';
    ?>

    <li class="<?php echo esc_attr( $classes ); ?>" style="list-style:none;">

        <a href="<?php echo esc_url( $link ); ?>" class="woocommerce-LoopProduct-link" style="overflow:hidden;">
            <div
                class="zoom-effect"
                style="background-image:url('<?php echo esc_url( $img ); ?>');
                       background-size:cover;
                       background-position:center;
                       height:320px;
                       width:100%;">
            </div>
        </a>

        <a href="<?php echo esc_url( $link ); ?>" class="woocommerce-LoopProduct-link" style="display:block;text-decoration:none !important;">
            <h2 class="woocommerce-loop-product__title" style="font-size:1.1rem;margin-top:10px;">
                <?php echo esc_html( $title ); ?>
            </h2>

            <?php
            /* ==========================
             * SOLO PRODOTTI
             * ========================== */
            if ( $is_product ) :

                $is_catalog = get_field( 'prodotto_a_catalogo' );
                $sku        = $product->get_sku();

                // Dimensioni
                $length = (string) $product->get_length();
                $width  = (string) $product->get_width();
                $height = (string) $product->get_height();

                $dims = [];
                if ( $length !== '' ) $dims[] = $length . ' cm';
                if ( $width  !== '' ) $dims[] = $width  . ' cm';
                if ( $height !== '' ) $dims[] = $height . ' cm';

                if ( ! empty( $dims ) ) {
                    $prefix = ( $length !== '' && $width === '' && $height !== '' ) ? 'Ø ' : '';
                    echo '<div class="product-dimensions">Dimensioni: ' . esc_html( $prefix . implode( ' x ', $dims ) ) . '</div>';
                }

                if ( $sku ) {
                    echo '<p class="sku" style="font-size:11px;"><b>COD: ' . esc_html( $sku ) . '</b></p>';
                }

                // Prezzo
                if ( ! $is_catalog ) :
                    ?>
                    <span class="price" style="display:block;text-align:center;">
                        <?php
                        $prezzo_custom  = get_field( 'attiva_prezzo_custom' );
                        $standard_price = (float) $product->get_price();
                        $coeff          = get_field( 'prezzo_custom' );

                        if ( $prezzo_custom && $coeff ) :
                            $prezzo_coeff = round( $standard_price / $coeff, 2 );
                            echo 'Prezzo al ' . esc_html( get_field( 'unita_di_misura' ) ) . ' ';
                            echo number_format( $prezzo_coeff, 2, ',', '.' ) . get_woocommerce_currency_symbol();
                        else :
                            if ( $product->is_type( 'variable' ) ) {
                                echo __( 'A partire da', 'pdr' ) . ' ';
                            }

                            if ( $product->get_sale_price() ) {
                                echo number_format( (float) $product->get_sale_price(), 2, ',', '.' );
                                echo get_woocommerce_currency_symbol();
                                echo ' <span class="barrato">'
                                     . number_format( (float) $product->get_regular_price(), 2, ',', '.' )
                                     . get_woocommerce_currency_symbol()
                                     . '</span>';
                            } else {
                                echo number_format( $standard_price, 2, ',', '.' ) . get_woocommerce_currency_symbol();
                            }
                        endif;
                        ?>
                        + IVA
                    </span>
                <?php endif; ?>

            <?php endif; /* fine prodotto */ ?>

        </a>
    </li>

<?php endwhile; ?>

</ul>

<?php
do_action( 'woocommerce_after_shop_loop' );
else :
    echo '<p>' . __( 'Nessun risultato trovato.', 'pietre-rapolano' ) . '</p>';
endif;
?>
    </div>

    <div class="row">
      <div class="col lead text-center w-100">
        <div class="d-inline-block"><?php picostrap_pagination() ?></div>
      </div><!-- /col -->
    </div <!-- /row -->
  </div>
</section>
 
<?php get_footer();
