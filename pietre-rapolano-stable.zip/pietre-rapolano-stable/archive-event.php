<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
?>
  
 

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-6 my-auto">
				<h1 class="page-title"><?php the_archive_title() ?></h1>
				<div class="extender my-3"></div>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
				}
				?>
			</div>
			<div class="col-lg-6 my-auto">
				
			</div>
		</div>
	</div>
</section> 

<section class="album py-5">
  <div id="container-content-archive" class="container">
    <div class="row">
    <?php 
        if ( have_posts() ) : 
            while ( have_posts() ) : the_post();
              get_template_part('loops/cards');
            endwhile;
        else :
            _e( 'Sorry, no posts matched your criteria.', 'pietre-rapolano' );
        endif;
        ?>
    </div>

    <div class="row">
      <div class="col lead text-center w-100">
        <div class="d-inline-block"><?php picostrap_pagination() ?></div>
      </div><!-- /col -->
    </div> <!-- /row -->
  </div>
</section>
 
<?php get_footer();
