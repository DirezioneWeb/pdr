<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' ); ?>
<section id="head" class="bg-light">
    <div class="container px-xl-3">
        <div class="row">
            <div class="col-lg-12 my-auto">
                <div class="article-title text-center">SHOP</div>
                <h1 class="page-title text-center">
                    <?php
                    if ( is_shop() ) {
                        echo __( 'TUTTI I PRODOTTI', 'pietre-rapolano' );
                    } else {
                        woocommerce_page_title();
                    }
                    ?>
                </h1>
                <?php
                if ( function_exists('yoast_breadcrumb') ) {
                  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
                }
                ?>
                <div class="extender-mini my-3 mx-auto"></div>
                <div class="d-flex justify-content-center align-items-center w-100">
                    <button class="mb-2 d-flex align-items-center filter" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasFilter" aria-controls="offcanvasFilter">
                        <?php echo __('FILTRA', 'pietre-rapolano'); ?> <img class="mx-2 nopin" src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/07/lets-icons_filter.svg"/>
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="mt-3" id="woocommerce-wrapper">
    <div class="container-fluid">
        <div class="offcanvas offcanvas-end show-offcanvas-full" tabindex="-1" id="offcanvasFilter" aria-labelledby="offcanvasFilterLabel">
            <div class="offcanvas-header">
            <p class="offcanvas-title" id="offcanvasFilterLabel"><?php _e( 'FILTRI', 'pietre-rapolano' ); ?></p>
            <button type="button" class="btn-close text-white" data-bs-dismiss="offcanvas" aria-label="Close" style="filter: invert(1);"></button>
            </div>
            <div class="offcanvas-body" id="offcanvas-filtri">
            <?php echo do_shortcode('[searchandfilter field="Ordinamento"]'); ?>
            <?php echo do_shortcode('[searchandfilter field="Prezzo"]'); ?>
            <?php echo do_shortcode('[searchandfilter field="Categoria"]'); ?>
            <?php echo do_shortcode( '[searchandfilter field="Tipologia prodotti"]' ); ?>
            <?php echo do_shortcode('[searchandfilter field="Serie"]'); ?>
            <?php echo do_shortcode('[searchandfilter field="Finitura"]'); ?>
            <?php echo do_shortcode('[searchandfilter field="Materiale"]'); ?>
            <?php echo do_shortcode('[searchandfilter field="Materiale pietre"]'); ?>
            <?php echo do_shortcode( '[searchandfilter field="Taglio pietra"]' ); ?>
            <?php echo do_shortcode('[searchandfilter field="Forma"]'); ?>
            <?php echo do_shortcode( '[searchandfilter field="Tipologia lavabi"]' ); ?>
            <?php echo do_shortcode( '[searchandfilter field="Rubinetteria"]' ); ?>
            <?php echo do_shortcode( '[searchandfilter field="Installazione rubinetteria"]' ); ?>
            <div class="clear"></div>
            <?php echo do_shortcode('[searchandfilter field="Reset"]'); ?>
            <?php echo do_shortcode('[searchandfilter field="Submit"]'); ?>
            </div>
        </div>
        <div class="row">
            <div class="<?php if (is_active_sidebar( 'wc-sidebar' )) echo 'col-md-9 order-2'; else echo 'col'; ?>">
                <?php
                if ( woocommerce_product_loop() ) {

                    echo '<ul class="products row list-unstyled" style="display: flex; flex-wrap: wrap; margin-left: -15px; margin-right: -15px;">';

                    $i = 0;
                    if ( wc_get_loop_prop( 'total' ) ) {
                    while ( have_posts() ) {
                        the_post();
                        global $product;
                        $i++;

                        // Ottieni dati prodotto
                        $product_link = get_permalink();
                        $product_title = get_the_title();
                        $product_img = get_the_post_thumbnail_url( get_the_ID(), 'woocommerce_thumbnail' );
                        
                        // Controlla campo ACF
                        $prodotto_a_catalogo = get_field('prodotto_a_catalogo');
                        $product_price = ($prodotto_a_catalogo) ? '' : $product->get_price_html();
                        $product_sku = $product->get_sku(); // Ottieni SKU
                        $is_catalog = get_field('prodotto_a_catalogo');

                        $catalog = '';
                        
                        if($is_catalog == true){
                            $catalog = 'catalogo';
                        }

                        // Recupera misure WooCommerce
                        $length = (string) $product->get_length();
                        $width  = (string) $product->get_width();
                        $height = (string) $product->get_height();

                        // Classi prodotto
                        $classes = wc_get_product_class( '', $product );
                        $classes .= ' col-lg-3 col-12 col-md-4 col-sm-4 col-xs-6 mb-4';

                        echo '<li class="' . esc_attr( $classes ) . '" style="list-style: none; padding-left: 15px; padding-right: 15px;">';
                        echo do_shortcode("[ti_wishlists_addtowishlist loop=yes]");
                        echo '<a href="' . esc_url( $product_link ) . '" class="woocommerce-LoopProduct-link woocommerce-loop-product__link" style="display: block; position: relative; overflow: hidden;width: 100%;">';
                        echo '<div style="background-image: url(' . esc_url( $product_img ) . '); background-size: cover; background-position: center; height: 475px; width: 100%;" class="zoom-effect"></div>';
                        echo '</a>';
                        echo '<a href="' . esc_url( $product_link ) . '" class="woocommerce-LoopProduct-link woocommerce-loop-product__link" style="display: block; position: relative; overflow: hidden;">';
                        echo '<h2 class="woocommerce-loop-product__title" style="font-size: 1.1rem; margin-top: 10px;">' . esc_html( $product_title ) . '</h2>';?>
                        
                    <?php
                        

                        // Mostra dimensioni prodotto (con "Ø" se ci sono solo Lunghezza e Altezza)
                        $show_dimensions = false;
                        $dimensions_parts = array();

                        if ( $length !== '' ) {
                            $show_dimensions = true;
                        }
                        if ( $width !== '' ) {
                            $show_dimensions = true;
                        }
                        if ( $height !== '' ) {
                            $show_dimensions = true;
                        }

                        if ( $show_dimensions ) {
                            // Prefisso Ø se esistono solo Lunghezza e Altezza (width vuoto)
                            $prefix = ( $length !== '' && $width === '' && $height !== '' ) ? 'Ø ' : '';

                            // Ordine: lunghezza, larghezza, altezza (escludi valori vuoti)
                            if ( $length !== '' ) {
                                $dimensions_parts[] = $length . ' cm';
                            }
                            if ( $width !== '' ) {
                                $dimensions_parts[] = $width . ' cm';
                            }
                            if ( $height !== '' ) {
                                $dimensions_parts[] = $height . ' cm';
                            }

                            if ( ! empty( $dimensions_parts ) ) {
                                // Escape each part
                                $escaped_parts = array_map( 'esc_html', $dimensions_parts );
                                echo '<div class="product-dimensions" style="clear: both;">' . esc_html__( 'Dimensioni: ', 'pietre-rapolano' ) . esc_html( $prefix ) . implode( ' x ', $escaped_parts ) . '</div>';
                            }
                        }
                        echo '<p class="sku" style="font-size: 11px;"><b>COD: ' . esc_html( $product_sku ) . '</b></p>'; // Mostra SKU giustificato a destra
                       if($is_catalog == false){ ?>
                        <span class="price" style="display: block; text-align: center;">
                    <?php
                    $prezzo_custom = get_field('attiva_prezzo_custom');
                    $standard_price = $product->get_price();
                    $coeff = get_field('prezzo_custom');	            	
                    if($coeff):
                        $prezzo_coeff = round($standard_price / $coeff, 2);
                    endif;

                    if($prezzo_custom == true) : 
                        echo '<span class="price" style="text-align: center;">';
                        echo __('Prezzo al ', 'pdr'); 
                        echo ' ' . get_field('unita_di_misura') .'';
                        echo ' '.'<span>' . number_format($prezzo_coeff, 2, ',', '.');
                        echo get_woocommerce_currency_symbol().'</span>';
                        echo '</span>';
                    else:
                    ?>
                    <?php if( $product->is_type( 'variable' ) ) : ?>
                            <?php echo __('A partire da', 'pdr'); ?>
                            <?php endif; ?>	
                                                                    <?php
                                                                        $regular_price = number_format( (float) $product->get_regular_price(), 2, ',', '.');
                                                                        $standard_price = number_format( (float) $product->get_price(), 2, ',', '.'); 
                                    $sale_price = $product->get_sale_price(); 
                                                                        if($sale_price):
                                                                            echo number_format( (float) $sale_price, 2, ',', '.');
                                                                            echo get_woocommerce_currency_symbol();	            	
                                                                            echo '<span class="barrato"> ' . $regular_price . get_woocommerce_currency_symbol() . '</span>';
                                                                        else:
                                                                            echo $standard_price;
                                                                            echo get_woocommerce_currency_symbol();	            	
                                                                        endif;
                                    endif;        	
                    ?>
                     <?php echo __('IVA inclusa', 'pietre-rapolano'); ?></span>
                    <?php }
                        echo '</a>';
                        echo '</li>';
                    }
                    }

                    echo '</ul>';

                    /**
                     * Hook: woocommerce_after_shop_loop.
                     */
                    do_action( 'woocommerce_after_shop_loop' );
                } else {
                    /**
                     * Hook: woocommerce_no_products_found.
                     */
                    do_action( 'woocommerce_no_products_found' );
                }
                ?>
                <style>
                    .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart::before {
  font-size: 35px;
}
                </style>
            </div>
            <?php if (is_active_sidebar( 'wc-sidebar' )): ?>
                <div id="store-sidebar" class="col-md-3 order-1 pt-1 mb-4">
                    <?php do_action( 'woocommerce_sidebar' ); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'woocommerce_after_main_content' ); ?>
<div class="clear"></div>
<section id="cta-footer-contact" class="py-150">
    <!-- Overlay per l'effetto blur -->
    <div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
                <h3 class="text-center text-light"><?php _e( 'Contattaci per informazioni', 'pietre-rapolano' ); ?></h3>
                <p class="text-center text-light uppercase"><?php _e( 'o per richiedere un preventivo personalizzato', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php echo (do_shortcode('[contact-form-7 id="5fbf157" title="Modulo di contatto CTA ITA"]')); ?>
			</div>
		</div>
	</div>
</section>
<?php
get_footer( 'shop' );
?>
