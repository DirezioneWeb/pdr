<?php echo do_shortcode( '[calcolo_mq_prodotto]' ); ?>
<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     9.7.0
 */

use Automattic\WooCommerce\Enums\ProductType;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?>
<!--
<div class="product_meta">

	<?php do_action( 'woocommerce_product_meta_start' ); ?>

	<?php if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( ProductType::VARIABLE ) ) ) : ?>

		<span class="sku_wrapper"><?php esc_html_e( 'SKU:', 'woocommerce' ); ?> <span class="sku"><?php echo ( $sku = $product->get_sku() ) ? $sku : esc_html__( 'N/A', 'woocommerce' ); ?></span></span>

	<?php endif; ?>

	<?php echo wc_get_product_category_list( $product->get_id(), ', ', '<span class="posted_in">' . _n( 'Category:', 'Categories:', count( $product->get_category_ids() ), 'woocommerce' ) . ' ', '</span>' ); ?>

	<?php echo wc_get_product_tag_list( $product->get_id(), ', ', '<span class="tagged_as">' . _n( 'Tag:', 'Tags:', count( $product->get_tag_ids() ), 'woocommerce' ) . ' ', '</span>' ); ?>

	<?php do_action( 'woocommerce_product_meta_end' ); ?>

</div>
	-->
<?php
if (get_field('prodotto_con_ai')) : ?>
<div class="banner-ai container my-4">
	<div class="row">
		<div class="col-lg-9 col-md-9 col-xs-10">
			<p class="text-white uppercase" style="margin-bottom: 10px;font-size: 20px;"><strong><?php _e( 'CONFIGURA IL TUO AMBIENTE', 'pietre-rapolano' ); ?></strong></p>
			<p class="text-white"><?php _e( 'Scatta una foto e visualizza questo materiale sulla superfice che vuoi. Prova il nostro  configuratore per ambienti che sfrutta le potenza dell’intelligenza artificiale.', 'pietre-rapolano' ); ?>S</p>
		</div>
		<div class="col-lg-3 col-md-3 col-xs-2">
			<img src="https://pdr.demo-dirweb.it/wp-content/uploads/2025/07/ai-ico.svg" alt="Configuratore AI" />
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12 col-md-12 col-xs-12">
			<a href="<?php echo esc_url(get_field('url_piattaforma_ai')); ?>" class="btn bg-white uppercase" style="width: 100%;"><?php _e( 'Visualizza sulla tua superficie', 'pietre-rapolano' ); ?></a>
		</div>
	</div>
</div>
<?php endif; ?>
<?php echo(do_shortcode( '[pi_shipping_calculator]' )); ?>
<div class="pdf-and-share">
    <?php echo do_shortcode('[dkpdf-button]'); ?>
    <div class="social-share-icons">
        <?php 
        $url = urlencode( get_permalink() );
        $title = urlencode( get_the_title() );
        ?>
		<?php _e( 'Condividi su:', 'pietre-rapolano' ); ?> 
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $url; ?>" target="_blank" aria-label="Condividi su Facebook">
            <img src="https://pdr.demo-dirweb.it/wp-content/themes/pietre-rapolano/media/facebook.svg" alt="Facebook" style="width:20px; height:20px; margin-right:5px;">
        </a>
        <a href="https://twitter.com/intent/tweet?url=<?php echo $url; ?>&text=<?php echo $title; ?>" target="_blank" aria-label="Condividi su X">
            <img src="https://pdr.demo-dirweb.it/wp-content/themes/pietre-rapolano/media/twitter.svg" alt="Twitter" style="width:20px; height:20px; margin-right:5px;">
        </a>
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $url; ?>&title=<?php echo $title; ?>" target="_blank" aria-label="Condividi su LinkedIn">
            <img src="https://pdr.demo-dirweb.it/wp-content/themes/pietre-rapolano/media/linkedin.svg" alt="LinkedIn" style="width:20px; height:20px; margin-right:5px;">
        </a>
        <a href="https://pinterest.com/pin/create/button/?url=<?php echo $url; ?>&description=<?php echo $title; ?>" target="_blank" aria-label="Condividi su Pinterest">
            <img src="https://pdr.demo-dirweb.it/wp-content/themes/pietre-rapolano/media/pinterest.svg" alt="Pinterest" style="width:20px; height:20px; margin-right:5px;">
        </a>
    </div>
</div>
