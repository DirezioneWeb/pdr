<?php
/**
 * Single product short description
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/short-description.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $post;

$short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt );

if ( ! $short_description ) {
	return;
}

?>
<div class="woocommerce-product-details__short-description d-none d-sm-block d-md-block d-lg-block d-xxl-block" style="margin-bottom: 30px;">
	<div class="short-description-wrapper">
		<div class="short-description-content">
			<?php echo $short_description; // WPCS: XSS ok. ?>
		</div>
		<a href="#" class="short-description-toggle" style="display: none;">
			<span class="toggle-text-more"><?php echo esc_html__('Leggi di più &#8600;', 'pietre-rapolano'); ?></span>
			<span class="toggle-text-less" style="display: none;"><?php echo esc_html__('Leggi meno &#8599;', 'pietre-rapolano'); ?></span>
		</a>
	</div>
</div>

<style>
.short-description-wrapper {
	position: relative;
}

.short-description-content {
	overflow: hidden;
	transition: max-height 0.3s ease;
}

.short-description-content.collapsed {
	max-height: 300px;
	position: relative;
}

.short-description-content.collapsed::after {
	content: '';
	position: absolute;
	bottom: 0;
	left: 0;
	right: 0;
	height: 60px;
	background: linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,1));
	pointer-events: none;
}

.short-description-content.expanded {
	max-height: none;
}

.short-description-toggle {
	display: inline-block;
	margin-top: 10px;
	color: #000;
	text-decoration: none;
	font-weight: 600;
	cursor: pointer;
	transition: color 0.2s ease;
}

.short-description-toggle:hover {
	color: #000;
	text-decoration: underline;
}
</style>

<script>
(function() {
	// Wait for DOM to be ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initShortDescriptionToggle);
	} else {
		initShortDescriptionToggle();
	}

	function initShortDescriptionToggle() {
		var wrapper = document.querySelector('.short-description-wrapper');
		if (!wrapper) return;

		var content = wrapper.querySelector('.short-description-content');
		var toggle = wrapper.querySelector('.short-description-toggle');
		var toggleTextMore = wrapper.querySelector('.toggle-text-more');
		var toggleTextLess = wrapper.querySelector('.toggle-text-less');

		if (!content || !toggle) return;

		// Check the actual height of the content
		var actualHeight = content.scrollHeight;

		// If content height is greater than 300px, show the toggle
		if (actualHeight > 300) {
			content.classList.add('collapsed');
			toggle.style.display = 'inline-block';

			// Add click event to toggle
			toggle.addEventListener('click', function(e) {
				e.preventDefault();
				
				if (content.classList.contains('collapsed')) {
					// Expand
					content.classList.remove('collapsed');
					content.classList.add('expanded');
					toggleTextMore.style.display = 'none';
					toggleTextLess.style.display = 'inline';
				} else {
					// Collapse
					content.classList.remove('expanded');
					content.classList.add('collapsed');
					toggleTextMore.style.display = 'inline';
					toggleTextLess.style.display = 'none';
					
					// Scroll back to the description if needed
					var rect = wrapper.getBoundingClientRect();
					if (rect.top < 0) {
						wrapper.scrollIntoView({ behavior: 'smooth', block: 'start' });
					}
				}
			});
		}
	}
})();
</script>
