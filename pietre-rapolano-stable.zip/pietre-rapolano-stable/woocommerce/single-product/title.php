<?php
/**
 * Single Product title
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/title.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see        https://woocommerce.com/document/template-structure/
 * @package    WooCommerce\Templates
 * @version    1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! isset( $product ) || ! is_a( $product, 'WC_Product' ) ) {
    global $product;
    if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
        $product = wc_get_product( get_the_ID() );
    }
}
?>

<?php if ( $product && $product->get_sku() ) : ?>
    <div class="product-sku d-none d-sm-block d-md-block d-lg-block d-xxl-block">
        <?php _e( 'CODICE:', 'pietre-rapolano' ); ?> <?php echo esc_html( $product->get_sku() ); ?>
    </div>
<?php endif; ?>

<h1 class="product_title entry-title d-none d-sm-block d-md-block d-lg-block d-xxl-block"><?php the_title(); ?></h1>
