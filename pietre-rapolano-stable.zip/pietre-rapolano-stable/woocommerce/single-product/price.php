<?php
/**
 * Single Product Price
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

?>
<div class="clear"></div>
<?php 
    $prodotto_catalogo = get_field('prodotto_a_catalogo');
?>

<?php 
if (!$prodotto_catalogo) { // Mostra il prezzo solo se prodotto_a_catalogo è false
    $prezzo_custom   = get_field('attiva_prezzo_custom');
    $coeff           = get_field('prezzo_custom');
    $standard_price  = $product->get_price();

    if ($coeff) {
        $prezzo_coeff = round(($standard_price / $coeff), 2);
    }

    $unita = get_field('unita_di_misura');

    if ($prezzo_custom == true) : 
        echo '<p style="font-weight:500;margin-bottom: 0.5rem;">';
        echo '<span class="hidden coeff">' . $coeff . '</span>';
        echo '<span class="hidden price">' . $standard_price . '</span>';
        echo '<p style="font-weight:500;">' . __('Prezzo al ', 'pdr') . ' ';
        echo $unita . ' : </span>';
        echo '<span class="value">' . $prezzo_coeff . '</span>';
        echo get_woocommerce_currency_symbol();
        echo ' <span class="esc_iva">(' . round($prezzo_coeff * 0.82, 2) . get_woocommerce_currency_symbol() . __(' IVA escl.', 'pdr') . ')</span>';
        echo '</p>';
        echo '</p>';
    endif;

    $prezzo_conf = '';

    if ($prezzo_custom == true) : 
        $prezzo_conf = '<span class="prezzo_confezione">' . __('Prezzo a confezione', 'pdr') . ': </span>';
    endif;    

    $regular_price  = wc_format_decimal($product->get_regular_price(), 2, false);
    $standard_price = wc_format_decimal($product->get_price(), 2, false);
    $sale_price     = $product->get_sale_price();

    if ($sale_price) {
        $sale_price_decimal = wc_format_decimal($sale_price, 2, false);
        echo '<span class="prezzo">' . $prezzo_conf . $sale_price_decimal . get_woocommerce_currency_symbol() . ' </span>';
        echo '<span class="barrato">' . $regular_price . get_woocommerce_currency_symbol() . '</span>';
        echo ' <span class="esc_iva">';
        echo '(' . round(wc_get_price_excluding_tax($product), 2) . get_woocommerce_currency_symbol() . __(' IVA escl.', 'pdr') . ')';
        echo '</span>';
    } else {
        echo '<span class="prezzo">' . $prezzo_conf . $standard_price . get_woocommerce_currency_symbol() . '</span>';
        /*
        if ($product->is_type('variable')) {
            $regular_pricee = $product->get_variation_regular_price('max', true);
            echo '<span class="barrato eee">' . $regular_pricee . get_woocommerce_currency_symbol() . '</span>';  
        }
        */
        // var_dump($regular_price);

        echo ' <span class="esc_iva">';
        echo '(' . round(wc_get_price_excluding_tax($product), 2) . __(' IVA escl.', 'pdr') . ')';
        echo '</span>';
    }

    bbloomer_show_sale_percentage_loop();

    $regular_price = get_post_meta($product->get_id(), '_regular_price', true); 
    $sale_price    = get_post_meta($product->get_id(), '_sale_price', true);

    if (!empty($sale_price)) {
        $amount_saved    = $regular_price - $sale_price;
        $currency_symbol = get_woocommerce_currency_symbol();
        $percentage      = round((($regular_price - $sale_price) / $regular_price) * 100);
        ?>
        <p style="font-size: 18px; color: #6c6c6cff; text-align: left; margin-top: 10px;">
            <b>
                <?= __('Risparmio:', 'pdr') ?>
                <?php echo number_format($amount_saved, 2, '.', '') . " €"; ?>
                <?php // echo number_format($amount_saved,2, '.', '')." (". number_format($percentage,0, '', '')."%)"; ?>
            </b>
        </p>
        <?php        
    }
} // Fine controllo prodotto_a_catalogo
?>
<div class="clear"></div>
<?php
/**
 * Single product short description
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/short-description.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $post;

$short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt );

if ( ! $short_description ) {
	return;
}

?>

<div class="woocommerce-product-details__short-description d-block d-sm-none d-md-none d-lg-none d-xxl-none col-xs-12">
	<?php echo $short_description; // WPCS: XSS ok. ?>
	<div class="clear"></div>
</div>