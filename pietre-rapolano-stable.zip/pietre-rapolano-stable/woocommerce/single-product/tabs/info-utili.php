<?php

if ( ! defined( 'ABSPATH' ) ) {

	exit; // Exit if accessed directly

}

global $product;

$pulizia = $product->get_attribute( 'pulizia' );
$trattamento = $product->get_attribute( 'trattamento' );
$rubinetteria = $product->get_attribute( 'rubinetteria' );
$foro_scarico = $product->get_attribute( 'foro-di-scarico' );
$provenienza = $product->get_attribute( 'provenienza' );

/*Indicazioni generiche Pulizia*/


$terms = get_the_terms ( $product->get_id(), 'product_cat' );
			$primary_cat_id=get_post_meta($product->id,'_yoast_wpseo_primary_product_cat',true);
			if($primary_cat_id){
					$product_cat = get_term($primary_cat_id, 'product_cat');
    if($cat_id == '602' || $cat_id == '1246'){

        echo '<div class="pdr_tab_value trattamento">';
        echo '<h3>' . __('Trattamento', 'pdr') . '</h3>';
        echo '<p>';
								echo __('Il prodotto viene fornito già trattato con prodotto idro/oleo repellente; si consiglia di ripetere il trattamento una o due volte l’anno, per mantenerne inalterata la bellezza.', 'pdr');
        echo '</p>';
        echo '</div>';

    } else {

    	if($cat_id != '605' || $cat_id != '1244'){
								echo '<div class="pdr_tab_value trattamento">';
								echo '<h3>' . __('Trattamento', 'pdr') . '</h3>';
								echo '<p>';
								echo __('Per esaltare la bellezza di questo prodotto e semplificarne la pulizia si consiglia di trattare con prodotto idro/oleo repellente. Si raccomanda di ripetere il trattamento una o due volte l’anno per mantenere inalterata la bellezza.', 'pdr');
								echo '</p>';
								echo '</div>';
						
								echo '<div class="pdr_tab_value pulizia">';
        echo '<h3>' . __('Pulizia', 'pdr') . '</h3>';
        echo '<p>';
								echo __('Per la pulizia di questo prodotto usare sempre saponi neutri. Non usare anticalcare onde evitare di alterarne la finitura superficiale. I marmi, pietre i travertini sono composti da un\'alta percentuale di carbonato di calcio, attaccbile dai prodotti acidi.', 'pdr');
        echo '</p>';
        echo '</div>';
						
    	}
    }
 } else {
foreach ( $terms as $term ) {

    $cat_id = $term->term_id;  

    if($cat_id == '602'|| $cat_id == '1246'){

        echo '<div class="pdr_tab_value trattamento">';
        echo '<h3>' . __('Trattamento', 'pdr') . '</h3>';
        echo '<p>';
    	echo __('Il prodotto viene fornito già trattato con prodotto idro/oleo repellente; si consiglia di ripetere il trattamento una o due volte l’anno, per mantenerne inalterata la bellezza.', 'pdr');
        echo '</p>';
        echo '</div>';

    } else {

    	if($cat_id != '605' || $cat_id != '1244'){
            echo '<div class="pdr_tab_value trattamento">';
            echo '<h3>' . __('Trattamento', 'pdr') . '</h3>';
            echo '<p>';
    		echo __('Per esaltare la bellezza di questo prodotto e semplificarne la pulizia si consiglia di trattare con prodotto idro/oleo repellente. Si raccomanda di ripetere il trattamento una o due volte l’anno per mantenere inalterata la bellezza.', 'pdr');
            echo '</p>';
            echo '</div>';
    	}
    }
}

foreach ( $terms as $term ) {

    $cat_id = $term->term_id;  

   	if($cat_id != '605' || $cat_id != '1244'){

        echo '<div class="pdr_tab_value pulizia">';
        echo '<h3>' . __('Pulizia', 'pdr') . '</h3>';
        echo '<p>';
		echo __('Per la pulizia di questo prodotto usare sempre saponi neutri. Non usare anticalcare onde evitare di alterarne la finitura superficiale. I marmi, pietre i travertini sono composti da un\'alta percentuale di carbonato di calcio, attaccbile dai prodotti acidi.', 'pdr');
        echo '</p>';
        echo '</div>';

	}   

}

				

}

if($provenienza):
	echo '<div class="pdr_tab_value provenienza">';
	echo '<h3>'. __('Provenienza', 'pdr') .'</h3>';	

	$array_provenienza = (get_the_terms($product->get_id(), 'pa_provenienza' ));

	foreach ($array_provenienza as $single_provenienza) {
		echo '<p>';	
			//echo '<img src="'. get_stylesheet_directory_uri() . '/images/logo-' . $single_provenienza->slug . '.jpg" /><br/>' ;	
			echo $single_provenienza->description . '</p>';
		echo '</p>';	
	}

	echo '</div>';

endif;



