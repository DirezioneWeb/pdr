<?php
/**
 * Additional Information tab
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/additional-information.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author        WooThemes
 * @package       WooCommerce/Templates
 * @version       3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

/*
	Dimensioni
	Peso
	Formato
	Finitura
	Dimensioni imballo/scatola
	Allegato Pdf/Dwg
*/

global $product;

$peso = wc_format_weight($product->get_weight());
$dimensioni =  wc_format_dimensions($product->get_dimensions(false));
$trattamento = $product->get_attribute( 'trattamento' );
$formato = $product->get_attribute( 'formati-disponibili' );
$finitura = $product->get_attribute( 'finitura' );
$trattamento = $product->get_attribute( 'trattamento' );
$imballo = $product->get_attribute( 'imballo' );
$scheda_tecnica_pdf = get_field('scheda_tecnica_pdf');
$scheda_tecnica_pdf_due = get_field('scheda_tecnica_pdf_due');
$modello_variazione_altra_scheda_tecnica = get_field('modello_variazione_altra_scheda_tecnica');
$modello_variazione_scheda_tecnica = get_field('modello_variazione_scheda_tecnica');
$scheda_tecnica_dwg = get_field('scheda_tecnica_dwg');
$scheda_tecnica_dwg_due = get_field('scheda_tecnica_dwg_due');
$modello_scheda_dwg = get_field('modello_scheda_dwg');
$modello_scheda_dwg_ = get_field('modello_scheda_dwg_');
$scheda_tecnica_tre = get_field('scheda_tecnica_tre');
$scheda_tecnica_pdf_quattro = get_field('scheda_tecnica_pdf_quattro');
$scheda_tecnica_pdf_cinque = get_field('scheda_tecnica_pdf_cinque');
$modello_variazione_scheda_tecnica_tre = get_field('modello_variazione_scheda_tecnica_tre');
$modello_variazione_scheda_tecnica_quattro = get_field('modello_variazione_scheda_tecnica_quattro');
$modello_variazione_scheda_tecnica_cinque = get_field('modello_variazione_scheda_tecnica_cinque');
$modello_scheda_dwg_tre = get_field('modello_scheda_dwg_tre');
$scheda_tecnica_dwg_quattro = get_field('scheda_tecnica_dwg_quattro');
$scheda_tecnica_dwg_cinque = get_field('scheda_tecnica_dwg_quattro_cinque');
$modello_scheda_dwg_tre = get_field('modello_scheda_dwg_tre');
$modello_scheda_dwg_quattro = get_field('modello_scheda_dwg_quattro');
$modello_scheda_dwg_cinque = get_field('modello_scheda_dwg_cinque');
$link_3d_warehouse = get_field('link_3d_warehouse');
$rubinetteria = $product->get_attribute( 'rubinetteria' );
$foro_scarico = $product->get_attribute( 'foro-di-scarico' );
$taglio_pietra	= $product->get_attribute( 'taglio-pietra' );
$mosaico = $product->get_attribute( 'scatola-mosaico' );
$selezione_materiale = $product->get_attribute( 'selezione-materiale' );
$serie = $product->get_attribute( 'serie' );
$taglio_pietra = $product->get_attribute( 'taglio-pietra' );
$tipologia = $product->get_attribute( 'tipologia' );
$tipologia_prodotti = $product->get_attribute( 'tipologia-prodotti' );

// Dimensioni prodotto

$lunghezza_prodotto = get_field('lunghezza_prodotto');
$larghezza_prodotto = get_field('larghezza_prodotto');
$altezza_prodotto = get_field('altezza_prodotto');
$peso_prodotto = get_field('peso_prodotto');

// Dimensioni prodotto variabile
$lunghezza_variante_1 = get_field('lunghezza_variante_1');
$larghezza_variante_1 = get_field('larghezza_variante_1');
$altezza_variante_1 = get_field('altezza_variante_1');
$peso_variante_1 = get_field('peso_variante_1');
$lunghezza_variante_2 = get_field('lunghezza_variante_2');
$larghezza_variante_2 = get_field('larghezza_variante_2');
$altezza_variante_2 = get_field('altezza_variante_2');
$peso_variante_2 = get_field('peso_variante_2');
$lunghezza_variante_3 = get_field('lunghezza_variante_3');
$larghezza_variante_3 = get_field('larghezza_variante_3');
$altezza_variante_3 = get_field('altezza_variante_3');
$peso_variante_3 = get_field('peso_variante_3');
$lunghezza_variante_4 = get_field('lunghezza_variante_4');
$larghezza_variante_4 = get_field('larghezza_variante_4');
$altezza_variante_4 = get_field('altezza_variante_4');
$peso_variante_4 = get_field('peso_variante_4');
$lunghezza_variante_5 = get_field('lunghezza_variante_5');
$larghezza_variante_5 = get_field('larghezza_variante_5');
$altezza_variante_5 = get_field('altezza_variante_5');
$peso_variante_5 = get_field('peso_variante_5');

if($lunghezza_prodotto):
	echo '<div class="pietre-rapolano_tab_value ' . $lunghezza_prodotto . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="cta-contact-text">'. __('Dimensioni', 'pietre-rapolano') .'</p> <p><span>Ø</span> ' . $lunghezza_prodotto . 'cm</p>';
	} else {
		echo '<p class="cta-contact-text">'. __('Dimensioni', 'pietre-rapolano') .'</p> <p> ' . $lunghezza_prodotto . 'cm x ' . $larghezza_prodotto . 'cm x ' . $altezza_prodotto . 'cm</p>';
	}
	echo '</div>';
endif;

if($peso_prodotto):
	echo '<div class="pietre-rapolano_tab_value ' . $peso_prodotto . '">';
	echo '<p class="cta-contact-text">'. __('Peso', 'pietre-rapolano') .'</p><p>Kg ' . $peso_prodotto . '</p>';
	echo '</div>';
endif;

// Recupera le etichette dai formati disponibili
$formati_terms = get_the_terms($product->get_id(), 'pa_formati-disponibili');
$formato_labels = array();
if ($formati_terms && !is_wp_error($formati_terms)) {
	foreach ($formati_terms as $index => $term) {
		$formato_labels[$index + 1] = $term->name;
	}
}

// Variante 1
$label_variante_1 = isset($formato_labels[1]) ? $formato_labels[1] : 'Variante 1';
if($lunghezza_variante_1):
	echo '<div class="pietre-rapolano_tab_value variante_1 ' . $lunghezza_variante_1 . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_1 .'</p> <p><span>Ø</span> ' . $lunghezza_variante_1 . 'cm</p>';
	} else {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_1 .'</p> <p> ' . $lunghezza_variante_1 . 'cm x ' . $larghezza_variante_1 . 'cm x ' . $altezza_variante_1 . 'cm</p>';
	}
	echo '</div>';
endif;

if($peso_variante_1):
	echo '<div class="pietre-rapolano_tab_value variante_1 ' . $peso_variante_1 . '">';
	echo '<p class="cta-contact-text">'. __('Peso Variante', 'pietre-rapolano') . ' ' . $label_variante_1 .'</p><p>Kg ' . $peso_variante_1 . '</p>';
	echo '</div>';
endif;

// Variante 2
$label_variante_2 = isset($formato_labels[2]) ? $formato_labels[2] : 'Variante 2';
if($lunghezza_variante_2):
	echo '<div class="pietre-rapolano_tab_value variante_2 ' . $lunghezza_variante_2 . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_2 .'</p> <p><span>Ø</span> ' . $lunghezza_variante_2 . 'cm</p>';
	} else {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_2 .'</p> <p> ' . $lunghezza_variante_2 . 'cm x ' . $larghezza_variante_2 . 'cm x ' . $altezza_variante_2 . 'cm</p>';
	}
	echo '</div>';
endif;

if($peso_variante_2):
	echo '<div class="pietre-rapolano_tab_value variante_2 ' . $peso_variante_2 . '">';
	echo '<p class="cta-contact-text">'. __('Peso Variante', 'pietre-rapolano') . ' ' . $label_variante_2 .'</p><p>Kg ' . $peso_variante_2 . '</p>';
	echo '</div>';
endif;

// Variante 3
$label_variante_3 = isset($formato_labels[3]) ? $formato_labels[3] : 'Variante 3';
if($lunghezza_variante_3):
	echo '<div class="pietre-rapolano_tab_value variante_3 ' . $lunghezza_variante_3 . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_3 .'</p> <p><span>Ø</span> ' . $lunghezza_variante_3 . 'cm</p>';
	} else {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_3 .'</p> <p> ' . $lunghezza_variante_3 . 'cm x ' . $larghezza_variante_3 . 'cm x ' . $altezza_variante_3 . 'cm</p>';
	}
	echo '</div>';
endif;

if($peso_variante_3):
	echo '<div class="pietre-rapolano_tab_value variante_3 ' . $peso_variante_3 . '">';
	echo '<p class="cta-contact-text">'. __('Peso Variante', 'pietre-rapolano') . ' ' . $label_variante_3 .'</p><p>Kg ' . $peso_variante_3 . '</p>';
	echo '</div>';
endif;

// Variante 4
$label_variante_4 = isset($formato_labels[4]) ? $formato_labels[4] : 'Variante 4';
if($lunghezza_variante_4):
	echo '<div class="pietre-rapolano_tab_value variante_4 ' . $lunghezza_variante_4 . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_4 .'</p> <p><span>Ø</span> ' . $lunghezza_variante_4 . 'cm</p>';
	} else {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_4 .'</p> <p> ' . $lunghezza_variante_4 . 'cm x ' . $larghezza_variante_4 . 'cm x ' . $altezza_variante_4 . 'cm</p>';
	}
	echo '</div>';
endif;

if($peso_variante_4):
	echo '<div class="pietre-rapolano_tab_value variante_4 ' . $peso_variante_4 . '">';
	echo '<p class="cta-contact-text">'. __('Peso Variante', 'pietre-rapolano') . ' ' . $label_variante_4 .'</p><p>Kg ' . $peso_variante_4 . '</p>';
	echo '</div>';
endif;

// Variante 5
$label_variante_5 = isset($formato_labels[5]) ? $formato_labels[5] : 'Variante 5';
if($lunghezza_variante_5):
	echo '<div class="pietre-rapolano_tab_value variante_5 ' . $lunghezza_variante_5 . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_5 .'</p> <p><span>Ø</span> ' . $lunghezza_variante_5 . 'cm</p>';
	} else {
		echo '<p class="cta-contact-text">'. __('Dimensioni Variante', 'pietre-rapolano') . ' ' . $label_variante_5 .'</p> <p> ' . $lunghezza_variante_5 . 'cm x ' . $larghezza_variante_5 . 'cm x ' . $altezza_variante_5 . 'cm</p>';
	}
	echo '</div>';
endif;

if($peso_variante_5):
	echo '<div class="pietre-rapolano_tab_value variante_5 ' . $peso_variante_5 . '">';
	echo '<p class="cta-contact-text">'. __('Peso Variante', 'pietre-rapolano') . ' ' . $label_variante_5 .'</p><p>Kg ' . $peso_variante_5 . '</p>';
	echo '</div>';
endif;

if($formato):
	echo '<div class="pietre-rapolano_tab_value formati">';
	echo '<p class="cta-contact-text">'. __('Formati disponibili', 'pietre-rapolano') .'</p>';
	echo '<ul>';
	$array_formato = (get_the_terms($product->get_id(), 'pa_formati-disponibili' ));
	foreach ($array_formato as $single_formato) {
		echo '<li class="single_form">'. $single_formato->name;
		echo $single_formato->description . '</li>';
	}
	echo '</ul>';
	echo '</div>';
endif;

if($mosaico):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Scatola mosaico', 'pietre-rapolano') .'</p><p>' . $mosaico . '</p>';
	echo '</div>';
endif;

if($serie):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Serie', 'pietre-rapolano') .'</p><p>' . $serie . '</p>';
	echo '</div>';
endif;

if($taglio_pietra):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Taglio pietra', 'pietre-rapolano') .'</p><p>' . $taglio_pietra . '</p>';
	echo '</div>';
endif;

if($finitura):

	echo '<div class="pdr_tab_value">';

	echo '<p class="cta-contact-text">'. __('Finitura', 'pietre-rapolano') .'</p>';

	echo '<p>'. __('Il prodotto è disponibile nelle seguenti finiture:', 'pietre-rapolano');

	//echo $product->get_attribute('pa_finitura'); 	

	$array_finiture = (get_the_terms($product->get_id(), 'pa_finitura' ));

	foreach ($array_finiture as $single_finitura) {

		echo '<p class="single_fin"><strong>'. $single_finitura->name .'</strong>';

		echo $single_finitura->description . '</p>';

	}

	echo '</div>';

endif;

if($tipologia_prodotti):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Tipologia prodotti', 'pietre-rapolano') .'</p><p>' . $tipologia_prodotti . '</p>';
	echo '</div>';
endif;	

if($tipologia):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Tipologia', 'pietre-rapolano') .'</p><p>' . $tipologia . '</p>';
	echo '</div>';
endif;

if($selezione_materiale):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Selezione materiale', 'pietre-rapolano') .'</p><p>' . $selezione_materiale . '</p>';
	echo '</div>';
endif;

if($imballo):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Dimensioni imballo/scatola', 'pietre-rapolano') .'</p><p>' . $imballo . '</p>';
	echo '</div>';
endif;

if($rubinetteria):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Installazione rubinetteria', 'pietre-rapolano') .'</p>';
	$array_rubinetto = (get_the_terms($product->get_id(), 'pa_rubinetteria' ));
	foreach ($array_rubinetto as $single_rub) {
		echo '<p><strong>'. $single_rub->name .'</strong><br/>';
		echo $single_rub->description . '</p>';
	}
	echo '</div>';
endif;

if($foro_scarico):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Foro di scarico', 'pietre-rapolano') .'</p><p>' . $foro_scarico . '</p>';
	echo '</div>';
endif;

if($taglio_pietra):
	echo '<div class="pietre-rapolano_tab_value">';
	echo '<p class="cta-contact-text">'. __('Taglio pietra', 'pietre-rapolano') .'</p>';
	$array_taglio_pietra = (get_the_terms($product->get_id(), 'pa_taglio-pietra' ));
	foreach ($array_taglio_pietra as $single_taglio_pietra) {
		echo '<p><strong>'. $single_taglio_pietra->name .'</strong><br/>';
		echo $single_taglio_pietra->description . '</p>';
	}
	echo '</div>';
endif;

if($scheda_tecnica_pdf || $scheda_tecnica_pdf_due || $scheda_tecnica_dwg || $modello_variazione_scheda_tecnica || $modello_variazione_altra_scheda_tecnica || $link_3d_warehouse || $scheda_tecnica_dwg_due || $modello_scheda_dwg || $modello_scheda_dwg_ || $scheda_tecnica_tre || $scheda_tecnica_pdf_quattro || $scheda_tecnica_pdf_cinque || $modello_variazione_scheda_tecnica_tre || $modello_variazione_scheda_tecnica_quattro || $modello_variazione_scheda_tecnica_cinque || $scheda_tecnica_dwg_tre || $scheda_tecnica_dwg_quattro || $scheda_tecnica_dwg_cinque || $modello_scheda_dwg_tre || $modello_scheda_dwg_quattro || $modello_scheda_dwg_cinque):
	echo '<div class="pietre-rapolano_tab_value schede_tecniche">';
	echo '<p class="cta-contact-text">'. __('Schede tecniche', 'pietre-rapolano') .'</p>';
	if($scheda_tecnica_pdf):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_pdf .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/pdf.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda PDF', 'pietre-rapolano') .'</span>';
		if($modello_variazione_scheda_tecnica):		
			echo ''. $modello_variazione_scheda_tecnica .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_pdf_due):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_pdf_due .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/pdf.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda PDF', 'pietre-rapolano') .'</span>';
		if($modello_variazione_altra_scheda_tecnica):		
			echo ''. $modello_variazione_altra_scheda_tecnica .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_tre):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_tre .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/pdf.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda PDF', 'pietre-rapolano') .'</span>';
		if($modello_variazione_scheda_tecnica_tre):		
			echo ''. $modello_variazione_scheda_tecnica_tre .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_pdf_quattro):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_pdf_quattro .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/pdf.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda PDF', 'pietre-rapolano') .'</span>';
		if($modello_variazione_scheda_tecnica_quattro):		
			echo ''. $modello_variazione_scheda_tecnica_quattro .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_pdf_cinque):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_pdf_cinque .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/pdf.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda PDF', 'pietre-rapolano') .'</span>';
		if($modello_variazione_scheda_tecnica_cinque):		
			echo ''. $modello_variazione_scheda_tecnica_cinque .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_dwg):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_dwg .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/dwg.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda DWG', 'pietre-rapolano') .'</span>';
		if($modello_scheda_dwg):		
			echo ''. $modello_scheda_dwg .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_dwg_due):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_dwg_due .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/dwg.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda DWG', 'pietre-rapolano') .'</span>';
		if($modello_scheda_dwg_):		
			echo ''. $modello_scheda_dwg_ .'';	
		endif;		
		echo '</a>';
	endif;

	if($scheda_tecnica_dwg_tre):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_dwg_tre .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/dwg.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda DWG', 'pietre-rapolano') .'</span>';
		if($modello_scheda_dwg_tre):		
			echo ''. $modello_scheda_dwg_tre .'';	
		endif;		
		echo '</a>';
	endif;

	if($scheda_tecnica_dwg_quattro):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_dwg_quattro .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/dwg.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda DWG', 'pietre-rapolano') .'</span>';
		if($modello_scheda_dwg_quattro):		
			echo ''. $modello_scheda_dwg_quattro .'';	
		endif;		
		echo '</a>';
	endif;

	if($scheda_tecnica_dwg_cinque):		
		echo '<a style="margin-right:15px;" href="'. $scheda_tecnica_dwg_cinque .'"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/dwg.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Scheda DWG', 'pietre-rapolano') .'</span>';
		if($modello_scheda_dwg_cinque):		
			echo ''. $modello_scheda_dwg_cinque .'';	
		endif;		
		echo '</a>';
	endif;

	if($link_3d_warehouse):		
		echo '<a style="margin-right:15px;" href="'. $link_3d_warehouse .'" target="_blank"><img src="https://pdr.demo-dirweb.it/wp-content/uploads/2026/01/tech.svg" style="width: 25px;margin-right: 5px;"/><span>'. __('Modello Sketchup', 'pietre-rapolano') .'</span></a>';	
	endif;

	echo '</div>';
endif;
