<?php
/**
 * Description tab
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/description.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 2.0.0
 */
defined('ABSPATH') || exit;
global $post;
$heading = apply_filters('woocommerce_product_description_heading', __('Description', 'woocommerce'));
if (!defined('ABSPATH')) { exit; }
global $product;
$pulizia = $product->get_attribute('pulizia');
$trattamento = $product->get_attribute('trattamento');
$rubinetteria = $product->get_attribute('rubinetteria');
$foro_scarico = $product->get_attribute('foro-di-scarico');
$provenienza = $product->get_attribute('provenienza');
$lavorazione = $product->get_attribute('provenienza-e-lavorazione');
$materiale = $product->get_attribute('material');
$colore = $product->get_attribute('colore');
$terms = get_the_terms($product->get_id(), 'product_cat');
$primary_cat_id = get_post_meta($product->get_id(), '_yoast_wpseo_primary_product_cat', true);
$allowed_categories = [82, 147, 123, 143, 153, 211, 90, 676, 546, 551];
$exclusion_pairs = [
    90 => [937, 938],
    546 => [939, 940],
    551 => [941, 942]
];

$current_cat_ids = [];
if ($primary_cat_id) {
    $current_cat_ids[] = (int) $primary_cat_id;
}
if ($terms && !is_wp_error($terms)) {
    foreach ($terms as $term) {
        $current_cat_ids[] = (int) $term->term_id;
    }
}
$current_cat_ids = array_unique($current_cat_ids);

$has_exclusion = false;
foreach ($exclusion_pairs as $parent_cat => $subs) {
    if (in_array($parent_cat, $current_cat_ids)) {
        foreach ($subs as $sub_cat) {
            if (in_array($sub_cat, $current_cat_ids)) {
                $has_exclusion = true;
                break 2;
            }
        }
    }
}

$show_trattamento_standard = false;
$show_trattamento_fornito = false;
$show_pulizia = false;

if (!$has_exclusion) {
    foreach ($current_cat_ids as $cat_id) {
        if ($cat_id == 147 || $cat_id == 676) {
            $show_trattamento_fornito = true;
        } elseif (in_array($cat_id, $allowed_categories)) {
            $show_trattamento_standard = true;
            $show_pulizia = true;
        }
    }
}

if ($show_trattamento_fornito) {
    echo '<div class="pdr_tab_value trattamento">';
    echo '<p class="cta-contact-text">' . __('Trattamento', 'pdr') . '</p>';
    echo '<p>' . __('Il prodotto viene fornito già trattato con prodotto idro/oleo repellente; si consiglia di ripetere il trattamento una o due volte l’anno, per mantenerne inalterata la bellezza.', 'pdr') . '</p>';
    echo '</div>';
}

if ($show_trattamento_standard) {
    echo '<div class="pdr_tab_value trattamento">';
    echo '<p class="cta-contact-text">' . __('Trattamento', 'pdr') . '</p>';
    echo '<p>' . __('Per esaltare la bellezza di questo prodotto e semplificarne la pulizia si consiglia di trattare con prodotto idro/oleo repellente. Si raccomanda di ripetere il trattamento una o due volte l’anno per mantenere inalterata la bellezza.', 'pdr') . '</p>';
    echo '</div>';
}

if ($show_pulizia) {
    echo '<div class="pdr_tab_value pulizia">';
    echo '<p class="cta-contact-text">' . __('Pulizia', 'pdr') . '</p>';
    echo '<p>' . __('Per la pulizia di questo prodotto usare sempre saponi neutri. Non usare anticalcare onde evitare di alterarne la finitura superficiale. I marmi, pietre i travertini sono composti da un\'alta percentuale di carbonato di calcio, attaccabile dai prodotti acidi.', 'pdr') . '</p>';
    echo '</div>';
}
if ($provenienza):
    echo '<div class="pdr_tab_value provenienza">';
    echo '<p class="cta-contact-text">' . __('Provenienza', 'pdr') . '</p>';
    $array_provenienza = (get_the_terms($product->get_id(), 'pa_provenienza'));
    foreach ($array_provenienza as $single_provenienza) {
        echo '<p>' . $single_provenienza->description . '</p>';
    }
    echo '</div>';
endif;

if ($lavorazione):
    echo '<div class="pdr_tab_value provenienza">';
    echo '<p class="cta-contact-text">' . __('Provenienza e lavorazione', 'pdr') . '</p>';
    $array_lavorazione = (get_the_terms($product->get_id(), 'pa_provenienza-e-lavorazione'));
    foreach ($array_lavorazione as $single_lavorazione) {
        echo '<p>' . $single_lavorazione->description . '</p>';
    }
    echo '</div>';
endif;

if ($materiale):
    echo '<div class="pdr_tab_value materiale">';
    echo '<p class="cta-contact-text">' . __('Materiale', 'pdr') . '</p>';
    echo '<p>' . $materiale . '</p>';
    echo '</div>';
endif;

if($colore):
	echo '<div class="pdr_tab_value colore">';
	echo '<p class="cta-contact-text">' . __('Colore', 'pdr') . '</p>';
	echo '<p>' . $colore . '</p>';
	echo '</div>';
endif;
