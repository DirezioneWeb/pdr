<?php
/**
 * Additional Information tab
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/additional-information.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author        WooThemes
 * @package       WooCommerce/Templates
 * @version       3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

/*
	Dimensioni
	Peso
	Formato
	Finitura
	Dimensioni imballo/scatola
	Allegato Pdf/Dwg
*/

global $product;

$peso = wc_format_weight($product->get_weight());
$dimensioni =  wc_format_dimensions($product->get_dimensions(false));
$trattamento = $product->get_attribute( 'trattamento' );
$formato = $product->get_attribute( 'formati-disponibili' );
$finitura = $product->get_attribute( 'finitura' );
$trattamento = $product->get_attribute( 'trattamento' );
$imballo = $product->get_attribute( 'imballo' );
$scheda_tecnica_pdf = get_field('scheda_tecnica_pdf');
$scheda_tecnica_pdf_due = get_field('scheda_tecnica_pdf_due');
$modello_variazione_altra_scheda_tecnica = get_field('modello_variazione_altra_scheda_tecnica');
$modello_variazione_scheda_tecnica = get_field('modello_variazione_scheda_tecnica');
$scheda_tecnica_dwg = get_field('scheda_tecnica_dwg');
$scheda_tecnica_dwg_due = get_field('scheda_tecnica_dwg_due');
$modello_scheda_dwg = get_field('modello_scheda_dwg');
$modello_scheda_dwg_ = get_field('modello_scheda_dwg_');
$scheda_tecnica_tre = get_field('scheda_tecnica_tre');
$scheda_tecnica_pdf_quattro = get_field('scheda_tecnica_pdf_quattro');
$scheda_tecnica_pdf_cinque = get_field('scheda_tecnica_pdf_cinque');
$modello_variazione_scheda_tecnica_tre = get_field('modello_variazione_scheda_tecnica_tre');
$modello_variazione_scheda_tecnica_quattro = get_field('modello_variazione_scheda_tecnica_quattro');
$modello_variazione_scheda_tecnica_cinque = get_field('modello_variazione_scheda_tecnica_cinque');
$modello_scheda_dwg_tre = get_field('modello_scheda_dwg_tre');
$scheda_tecnica_dwg_quattro = get_field('scheda_tecnica_dwg_quattro');
$scheda_tecnica_dwg_cinque = get_field('scheda_tecnica_dwg_quattro_cinque');
$modello_scheda_dwg_tre = get_field('modello_scheda_dwg_tre');
$modello_scheda_dwg_quattro = get_field('modello_scheda_dwg_quattro');
$modello_scheda_dwg_cinque = get_field('modello_scheda_dwg_cinque');
$link_3d_warehouse = get_field('link_3d_warehouse');
$rubinetteria = $product->get_attribute( 'rubinetteria' );
$foro_scarico = $product->get_attribute( 'foro-di-scarico' );
$taglio_pietra	= $product->get_attribute( 'taglio-pietra' );

if($dimensioni):
	echo '<div class="pdr_tab_value ' . $dimensioni . '">';
	if ( get_field('lavabo_ovale')  ) {
		echo '<p class="sottotitolo">'. __('Dimensioni', 'pdr') .'</p> <p><span>Ø</span> ' . $dimensioni . '</p>';
	} else {
		echo '<p class="sottotitolo">'. __('Dimensioni', 'pdr') .'</p> <p> ' . $dimensioni . '</p>';
	}
	echo '</div>';
endif;

if($product->has_weight()):
	echo '<div class="pdr_tab_value ' . $peso . '">';
	echo '<h3>'. __('Peso', 'pdr') .'</h3><p>' . $peso . '</p>';
	echo '</div>';
endif;

if($formato):
	echo '<div class="pdr_tab_value formati">';
	echo '<h3>'. __('Formato', 'pdr') .'</h3>';
	echo '<ul>';
	$array_formato = (get_the_terms($product->get_id(), 'pa_formati-disponibili' ));
	foreach ($array_formato as $single_formato) {
		echo '<li class="single_form">'. $single_formato->name;
		echo $single_formato->description . '</li>';
	}
	echo '</ul>';
	echo '</div>';
endif;

if($finitura):
	echo '<div class="pdr_tab_value">';
	echo '<h3>'. __('Finitura', 'pdr') .'</h3>';
	echo '<p>'. __('Il prodotto è disponibile nelle seguenti finiture:', 'pdr');
	$array_finiture = (get_the_terms($product->get_id(), 'pa_finitura' ));
	foreach ($array_finiture as $single_finitura) {
		echo '<p class="single_fin"><strong>'. $single_finitura->name .'</strong>';
		echo $single_finitura->description . '</p>';
	}
	echo '</div>';
endif;

if($imballo):
	echo '<div class="pdr_tab_value">';
	echo '<h3>'. __('Dimensioni imballo/scatola', 'pdr') .'</h3><p>' . $imballo . '</p>';
	echo '</div>';
endif;

if($rubinetteria):
	echo '<div class="pdr_tab_value">';
	echo '<h3>'. __('Installazione rubinetteria', 'pdr') .'</h3>';
	$array_rubinetto = (get_the_terms($product->get_id(), 'pa_rubinetteria' ));
	foreach ($array_rubinetto as $single_rub) {
		echo '<p><strong>'. $single_rub->name .'</strong><br/>';
		echo $single_rub->description . '</p>';
	}
	echo '</div>';
endif;

if($foro_scarico):
	echo '<div class="pdr_tab_value">';
	echo '<h3>'. __('Foro di scarico', 'pdr') .'</h3><p>' . $foro_scarico . '</p>';
	echo '</div>';
endif;

if($taglio_pietra):
	echo '<div class="pdr_tab_value">';
	echo '<h3>'. __('Taglio pietra', 'pdr') .'</h3>';
	$array_taglio_pietra = (get_the_terms($product->get_id(), 'pa_taglio-pietra' ));
	foreach ($array_taglio_pietra as $single_taglio_pietra) {
		echo '<p><strong>'. $single_taglio_pietra->name .'</strong><br/>';
		echo $single_taglio_pietra->description . '</p>';
	}
	echo '</div>';
endif;

if($scheda_tecnica_pdf || $scheda_tecnica_pdf_due || $scheda_tecnica_dwg || $modello_variazione_scheda_tecnica || $modello_variazione_altra_scheda_tecnica || $link_3d_warehouse || $scheda_tecnica_dwg_due || $modello_scheda_dwg || $modello_scheda_dwg_ || $scheda_tecnica_tre || $scheda_tecnica_pdf_quattro || $scheda_tecnica_pdf_cinque || $modello_variazione_scheda_tecnica_tre || $modello_variazione_scheda_tecnica_quattro || $modello_variazione_scheda_tecnica_cinque || $scheda_tecnica_dwg_tre || $scheda_tecnica_dwg_quattro || $scheda_tecnica_dwg_cinque || $modello_scheda_dwg_tre || $modello_scheda_dwg_quattro || $modello_scheda_dwg_cinque):
	echo '<div class="pdr_tab_value schede_tecniche">';
	echo '<h3>'. __('Schede tecniche', 'pdr') .'</h3>';
	if($scheda_tecnica_pdf):		
		echo '<a href="'. $scheda_tecnica_pdf .'"><i class="far fa-file-pdf"></i><span>'. __('Scheda PDF', 'pdr') .'</span>';
		if($modello_variazione_scheda_tecnica):		
			echo ''. $modello_variazione_scheda_tecnica .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_pdf_due):		
		echo '<a href="'. $scheda_tecnica_pdf_due .'"><i class="far fa-file-pdf"></i><span>'. __('Scheda PDF', 'pdr') .'</span>';
		if($modello_variazione_altra_scheda_tecnica):		
			echo ''. $modello_variazione_altra_scheda_tecnica .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_tre):		
		echo '<a href="'. $scheda_tecnica_tre .'"><i class="far fa-file-pdf"></i><span>'. __('Scheda PDF', 'pdr') .'</span>';
		if($modello_variazione_scheda_tecnica_tre):		
			echo ''. $modello_variazione_scheda_tecnica_tre .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_pdf_quattro):		
		echo '<a href="'. $scheda_tecnica_pdf_quattro .'"><i class="far fa-file-pdf"></i><span>'. __('Scheda PDF', 'pdr') .'</span>';
		if($modello_variazione_scheda_tecnica_quattro):		
			echo ''. $modello_variazione_scheda_tecnica_quattro .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_pdf_cinque):		
		echo '<a href="'. $scheda_tecnica_pdf_cinque .'"><i class="far fa-file-pdf"></i><span>'. __('Scheda PDF', 'pdr') .'</span>';
		if($modello_variazione_scheda_tecnica_cinque):		
			echo ''. $modello_variazione_scheda_tecnica_cinque .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_dwg):		
		echo '<a href="'. $scheda_tecnica_dwg .'"><i class="far fa-file-alt"></i><span>'. __('Scheda DWG', 'pdr') .'</span>';
		if($modello_scheda_dwg):		
			echo ''. $modello_scheda_dwg .'';	
		endif;		
		echo '</a>';	
	endif;

	if($scheda_tecnica_dwg_due):		
		echo '<a href="'. $scheda_tecnica_dwg_due .'"><i class="far fa-file-alt"></i><span>'. __('Scheda DWG', 'pdr') .'</span>';
		if($modello_scheda_dwg_):		
			echo ''. $modello_scheda_dwg_ .'';	
		endif;		
		echo '</a>';
	endif;

	if($scheda_tecnica_dwg_tre):		
		echo '<a href="'. $scheda_tecnica_dwg_tre .'"><i class="far fa-file-alt"></i><span>'. __('Scheda DWG', 'pdr') .'</span>';
		if($modello_scheda_dwg_tre):		
			echo ''. $modello_scheda_dwg_tre .'';	
		endif;		
		echo '</a>';
	endif;

	if($scheda_tecnica_dwg_quattro):		
		echo '<a href="'. $scheda_tecnica_dwg_quattro .'"><i class="far fa-file-alt"></i><span>'. __('Scheda DWG', 'pdr') .'</span>';
		if($modello_scheda_dwg_quattro):		
			echo ''. $modello_scheda_dwg_quattro .'';	
		endif;		
		echo '</a>';
	endif;

	if($scheda_tecnica_dwg_cinque):		
		echo '<a href="'. $scheda_tecnica_dwg_cinque .'"><i class="far fa-file-alt"></i><span>'. __('Scheda DWG', 'pdr') .'</span>';
		if($modello_scheda_dwg_cinque):		
			echo ''. $modello_scheda_dwg_cinque .'';	
		endif;		
		echo '</a>';
	endif;

	if($link_3d_warehouse):		
		echo '<a href="'. $link_3d_warehouse .'" target="_blank"><i class="fa fa-cube" aria-hidden="true"></i><span>'. __('Modello Sketchup', 'pdr') .'</span></a>';	
	endif;

	echo '</div>';
endif;
