<?php
/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/dashboard.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$allowed_html = array(
	'a' => array(
		'href' => array(),
	),
);
?>

<p>
	<?php
	printf(
		/* translators: 1: user display name 2: logout url */
		wp_kses( __( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'woocommerce' ), $allowed_html ),
		'<strong>' . esc_html( $current_user->display_name ) . '</strong>',
		esc_url( wc_logout_url() )
	);
	?>
</p>

<p>
	<?php
	/* translators: 1: Orders URL 2: Address URL 3: Account URL. */
	$dashboard_desc = __( 'qui troverai un riepilogo dello stato del tuo account e gli accessi rapidi alle azioni più utilizzate.', 'woocommerce' );
	if ( wc_shipping_enabled() ) {
		/* translators: 1: Orders URL 2: Addresses URL 3: Account URL. */
		$dashboard_desc = __( 'qui troverai un riepilogo dello stato del tuo account e gli accessi rapidi alle azioni più utilizzate.', 'woocommerce' );
	}
	printf(
		wp_kses( $dashboard_desc, $allowed_html ),
		esc_url( wc_get_endpoint_url( 'orders' ) ),
		esc_url( wc_get_endpoint_url( 'edit-address' ) ),
		esc_url( wc_get_endpoint_url( 'edit-account' ) )
	);
	?>
</p>
<div class="clear"></div>
<div class="container">
	<div class="row">
		<!-- ORDINI -->
		<div class="col-lg-4 col-md-4 col-xs-12">
			<div class="bg-grey py-3 px-3">
				<p class="etichetta"><?php _e( 'ORDINI', 'pietre-rapolano' ); ?></p>
				<ul>
					<?php
					$current_user_id = get_current_user_id();
					$args = array(
						'numberposts' => 3,
						'meta_key'    => '_customer_user',
						'meta_value'  => $current_user_id,
						'post_type'   => 'shop_order',
						'post_status' => array('wc-completed', 'wc-processing', 'wc-on-hold')
					);
					$recent_orders = get_posts($args);
					if ($recent_orders) {
						foreach ($recent_orders as $order_post) {
							$order = wc_get_order($order_post->ID);
							echo '<li>';
							echo 'Ordine <a href="' . esc_url($order->get_view_order_url()) . '">#' . $order->get_order_number() . '</a> - ' . wc_format_datetime($order->get_date_created()) . '<br>';
							echo 'Totale: ' . $order->get_formatted_order_total();
							echo '</li>';
						}
					} else {
						echo '<li>Nessun ordine recente.</li>';
					}
					?>
				</ul>
				<a href="<?php echo esc_url( wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) ); ?>" class="btn btn-link p-0">Visualizza tutti gli ordini</a>
			</div>
		</div>
		<!-- INDIRIZZO DEFAULT -->
		<div class="col-lg-4 col-md-4 col-xs-12">
			<div class="bg-grey py-3 px-3">
				<p class="etichetta"><?php _e( 'INDIRIZZO DI DEFAULT', 'pietre-rapolano' ); ?></p>
				<?php
				$customer = new WC_Customer($current_user_id);
				$address = $customer->get_billing_address_1();
				$city = $customer->get_billing_city();
				$postcode = $customer->get_billing_postcode();
				$country = $customer->get_billing_country();
				if ($address) {
					echo '<address>';
					echo esc_html($address) . '<br>';
					echo esc_html($postcode) . ' ' . esc_html($city) . '<br>';
					echo esc_html($country);
					echo '</address>';
				} else {
					echo '<p>Nessun indirizzo salvato.</p>';
				}
				?>
				<a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address', '', wc_get_page_permalink( 'myaccount' ) ) ); ?>" class="btn btn-link p-0">Modifica indirizzo</a>
			</div>
		</div>
		<!-- METODI DI PAGAMENTO -->
		<div class="col-lg-4 col-md-4 col-xs-12">
			<div class="bg-grey py-3 px-3">
				<p class="etichetta"><?php _e( 'METODI DI PAGAMENTO', 'pietre-rapolano' ); ?></p>
				<ul>
					<?php
					$payment_tokens = WC_Payment_Tokens::get_customer_tokens($current_user_id);
					if ($payment_tokens) {
						foreach ($payment_tokens as $token) {
							$gateway = $token->get_gateway_id();
							$type = $token->get_type();
							$last4 = $token->get_last4();
							$brand = method_exists($token, 'get_brand') ? $token->get_brand() : '';
							echo '<li>';
							echo esc_html(ucfirst($type)) . ' ';
							if ($brand) echo esc_html($brand) . ' ';
							if ($last4) echo '•••• ' . esc_html($last4);
							echo '</li>';
						}
					} else {
						echo '<li>Nessun metodo di pagamento salvato.</li>';
					}
					?>
				</ul>
				<a href="<?php echo esc_url( wc_get_endpoint_url( 'payment-methods', '', wc_get_page_permalink( 'myaccount' ) ) ); ?>" class="btn btn-link p-0"><?php _e( 'Gestisci i metodi di pagamento', 'pietre-rapolano' ); ?></a>
			</div>
		</div>
	</div>
</div>

<?php
	/**
	 * My Account dashboard.
	 *
	 * @since 2.6.0
	 */
	do_action( 'woocommerce_account_dashboard' );

	/**
	 * Deprecated woocommerce_before_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_before_my_account' );

	/**
	 * Deprecated woocommerce_after_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_after_my_account' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
