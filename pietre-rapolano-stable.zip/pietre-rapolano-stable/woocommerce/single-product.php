<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header( 'shop' ); ?>
<section id="head-shop" class="bg-light">
    <div class="container-fluid px-xl-7">
        <div class="row">
            <div class="col-lg-12 my-auto">
                <?php
                if ( function_exists('yoast_breadcrumb') ) {
                  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: start;display: flex;">','</p>' );
                }
                ?>
            </div>
        </div>
    </div>
</section>



		<?php while ( have_posts() ) : ?>
			<?php the_post(); ?>

			<?php wc_get_template_part( 'content', 'single-product' ); ?>

		<?php endwhile; // end of the loop. ?>

	<?php
		/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		do_action( 'woocommerce_after_main_content' );
	?>

	<?php
		/**
		 * woocommerce_sidebar hook.
		 *
		 * @hooked woocommerce_get_sidebar - 10
		 */
		do_action( 'woocommerce_sidebar' );
	?>

<?php
// Store the original product object to restore it later
$original_product = $product;

if ($original_product && !empty($original_product->get_upsell_ids())) :
    $upsells = $original_product->get_upsell_ids();

    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => 5,
        'post__in'       => $upsells,
        'orderby'        => 'post__in'
    );
    $upsell_query = new WP_Query($args);

    if ($upsell_query->have_posts()) : ?>
        
        <section class="bg-light py-6">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
                        <h4 class="text-center wp-block-heading has-large-font-size"><?php echo esc_html( __( 'Potrebbero interessarti anche…', 'pietre-rapolano' ) ); ?></h4>
                        <hr class="divider my-3 mx-auto">
                        <div class="clear"></div>
                        <ul class="products row list-unstyled" style="display:flex; flex-wrap:wrap; margin-left:-15px; margin-right:-15px;">
                            <?php while ($upsell_query->have_posts()) : $upsell_query->the_post(); 
                                // Get the upsell product object from the post
                                $upsell_product = wc_get_product(get_the_ID());
                                
                                $product_link  = get_permalink();
                                $product_title = get_the_title();
                                $product_img   = get_the_post_thumbnail_url(get_the_ID(), 'woocommerce_thumbnail');
                                $product_price = $upsell_product->get_price_html();
                                $product_sku   = $upsell_product->get_sku();
                                $length = $upsell_product->get_length();
                                $width  = $upsell_product->get_width();
                                $height = $upsell_product->get_height();

                                $classes = wc_get_product_class('', $upsell_product);
                                $classes .= ' col-6 col-sm-6 col-md-4 col-lg-3 mb-4';
                            ?>
                                <li class="<?php echo esc_attr($classes); ?>" style="list-style:none; padding-left:15px; padding-right:15px;">
                                    <a href="<?php echo esc_url($product_link); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                        <img src="<?php echo esc_url($product_img); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="<?php echo esc_attr($product_title); ?>" />
                                        <h2 class="woocommerce-loop-product__title" style="font-size: 1.1rem; margin-top: 10px;"><?php echo esc_html($product_title); ?></h2>
                                        
                                        <?php if ($upsell_product->get_price() > 0) : ?>
                                            <p class="price" style="text-align:center;"><?php echo $product_price; ?></p>
                                        <?php endif; ?>

                                        <?php if ($product_sku) : ?>
                                            <p class="sku">COD: <?php echo esc_html($product_sku); ?></p>
                                        <?php endif; ?>

                                        <?php
                                        $dimensions_parts = array();
                                        if ($length !== '') $dimensions_parts[] = $length . ' cm';
                                        if ($width  !== '') $dimensions_parts[] = $width . ' cm';
                                        if ($height !== '') $dimensions_parts[] = $height . ' cm';

                                        if (!empty($dimensions_parts)) {
                                            echo '<div class="product-dimensions">' . esc_html__( 'Dimensioni: ', 'pietre-rapolano' ) . esc_html(implode(' x ', $dimensions_parts)) . '</div>';
                                        }
                                        ?>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>

                        <?php 
                        wp_reset_postdata();
                        // Restore the original product object
                        $product = $original_product;
                        ?>
                    </div>
                </div>
            </div>
        </section>

    <?php endif;
endif;
?>

<?php
// Ottieni i cross-sell del carrello (controlla se WC()->cart esiste)
$cross_sells = WC()->cart ? WC()->cart->get_cross_sells() : array();

if (!empty($cross_sells)) :

    // Query per i prodotti cross-sell
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => 5,
        'post__in'       => $cross_sells,
        'orderby'        => 'post__in'
    );

    $cross_sell_query = new WP_Query($args);

    if ($cross_sell_query->have_posts()) : ?>

        <section class="bg-grey py-6">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
                        <h4 class="text-center wp-block-heading has-large-font-size"><?php echo esc_html( __( 'Altri clienti hanno acquistato', 'pietre-rapolano' ) ); ?></h4>
                        <hr class="divider my-3 mx-auto">

                        <ul class="products row list-unstyled" style="display:flex; flex-wrap:wrap; margin-left:-15px; margin-right:-15px;">

                            <?php while ($cross_sell_query->have_posts()) : $cross_sell_query->the_post();
                                // Get the cross-sell product object from the post
                                $cross_sell_product = wc_get_product(get_the_ID());

                                $product_link  = get_permalink();
                                $product_title = get_the_title();
                                $product_img   = get_the_post_thumbnail_url(get_the_ID(), 'woocommerce_thumbnail');
                                $product_price = $cross_sell_product->get_price_html();

                                $classes  = wc_get_product_class('', $cross_sell_product);
                                $classes .= ' col-12 col-sm-6 col-md-3 mb-4';
                            ?>
                                <li class="<?php echo esc_attr($classes); ?>" style="list-style:none; padding-left:15px; padding-right:15px;">
                                    <a href="<?php echo esc_url($product_link); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                        <img src="<?php echo esc_url($product_img); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="<?php echo esc_attr($product_title); ?>" />
                                        <h2 class="woocommerce-loop-product__title" style="font-size:1.1rem; margin-top:10px;"><?php echo esc_html($product_title); ?></h2>
                                        <span class="price" style="width:100%;display:block;text-align:center;"><?php echo $product_price; ?></span>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>

                        <?php wp_reset_postdata(); ?>
                    </div>
                </div>
            </div>
        </section>

    <?php endif;
endif;
?>


<?php
get_footer( 'shop' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
