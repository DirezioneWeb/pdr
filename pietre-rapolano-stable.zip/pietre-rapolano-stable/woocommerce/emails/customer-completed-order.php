<?php
/**
 * Customer completed order email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/customer-completed-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates\Emails
 * @version 9.8.0
 */

use Automattic\WooCommerce\Utilities\FeaturesUtil;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$email_improvements_enabled = FeaturesUtil::feature_is_enabled( 'email_improvements' );

/*
 * @hooked WC_Emails::email_header() Output the email header
 */
do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php echo $email_improvements_enabled ? '<div class="email-introduction">' : ''; ?>
<p>
<?php
if ( ! empty( $order->get_billing_first_name() ) ) {
	/* translators: %s: Customer first name */
	printf( esc_html__( 'Hi %s,', 'woocommerce' ), esc_html( $order->get_billing_first_name() ) );
} else {
	printf( esc_html__( 'Hi,', 'woocommerce' ) );
}
?>
</p>
<?php if ( $email_improvements_enabled ) : ?>
	<p><?php esc_html_e( 'We’ve successfully processed your order, and it’s on its way to you.', 'woocommerce' ); ?></p>
	<p><?php esc_html_e( 'Here’s a reminder of what you’ve ordered:', 'woocommerce' ); ?></p>
<?php else : ?>
	<p><?php esc_html_e( 'We have finished processing your order.', 'woocommerce' ); ?></p>
<?php endif; ?>
<?php echo $email_improvements_enabled ? '</div>' : ''; ?>

<?php

/*
 * @hooked WC_Emails::order_details() Shows the order details table.
 * @hooked WC_Structured_Data::generate_order_data() Generates structured data.
 * @hooked WC_Structured_Data::output_structured_data() Outputs structured data.
 * @since 2.5.0
 */
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

/*
 * @hooked WC_Emails::order_meta() Shows order meta data.
 */
do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

/*
 * @hooked WC_Emails::customer_details() Shows customer details
 * @hooked WC_Emails::email_address() Shows email address
 */
do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

if( ICL_LANGUAGE_CODE == 'it' ) {
printf( __( "<p style='color:#000;'><span style='font-size:16px'><strong>Attenzione:</strong></span><br>Tutte le nostre spedizioni viaggiano con corrieri assicurati, ma in caso di problemi abbiamo necessità che venga segnalata eventuale anomalia sui documenti di consegna la momento della ricezione.Altrimenti l'assicurazione non rimborserà danno.<p>", 'pdr' ));
	
printf( __( "<p style='color:#000;margin-bottom:30px'><span style='font-size:16px'></strong>Attention:<strong></span><br>All our shipments travel with insured couriers, but in case of problems we need you to report any anomaly on the delivery documents at the moment of receipt.Otherwise the insurance will not reimburse damage.<p>", 'dw' ));	
	
} else if( ICL_LANGUAGE_CODE == 'de' ) {
printf( __( "<p style='color:#000'><span style='font-size:16px'><strong>Attenzione:<strong</span>><br>Tutte le nostre spedizioni viaggiano con corrieri assicurati, ma in caso di problemi abbiamo necessità che venga segnalata eventuale anomalia sui documenti di consegna la momento della ricezione.Altrimenti l'assicurazione non rimborserà danno.<p>", 'pdr' ));
	
printf( __( "<p style='color:#000;margin-bottom:30px'><span style='font-size:16px'><strong>Attention:<strong></span><br>All our shipments travel with insured couriers, but in case of problems we need you to report any anomaly on the delivery documents at the moment of receipt.Otherwise the insurance will not reimburse damage.<p>", 'dw' ));	
	
} else {
printf( __( "<p style='color:#000;margin-bottom:30px'><span style='font-size:16px'><strong>Attention:<strong></span><br>All our shipments travel with insured couriers, but in case of problems we need you to report any anomaly on the delivery documents at the moment of receipt.Otherwise the insurance will not reimburse damage.<p>", 'dw' ));	
}
/**
 * Show user-defined additional content - this is set in each email's settings.
 */
if ( $additional_content ) {
	echo $email_improvements_enabled ? '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td class="email-additional-content">' : '';
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
	echo $email_improvements_enabled ? '</td></tr></table>' : '';
}

/*
 * @hooked WC_Emails::email_footer() Output the email footer
 */
do_action( 'woocommerce_email_footer', $email );
