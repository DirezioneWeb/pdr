<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
?>
  
 

<section id="head" class="bg-light">
	<div class="container px-xl-3">
		<div class="row">
			<div class="col-lg-12 my-auto">
				<h1 class="page-title text-center"><?php _e( 'Blog', 'pietre-rapolano' ); ?></h1>
				<?php
				if ( function_exists('yoast_breadcrumb') ) {
				  yoast_breadcrumb( '<p id="breadcrumbs" style="justify-content: center;display: flex;">','</p>' );
				}
				?>
				<div class="extender-mini my-3 mx-auto"></div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<?php echo (do_shortcode('[wd_asp id=2]')); ?>
			</div>
			<div class="col-lg-6 d-flex justify-content-end">
				<form method="get" class="select-category" action="<?php echo esc_url(home_url('/')); ?>">
				  <select class="form-control input-lg btn btn-outline-primary" name="cat" onchange="this.form.submit()" style="text-align: left;min-width: 288px;">
				    <option value=""><?php _e( 'CATEGORIA', 'pietre-rapolano' ); ?></option>
				    <?php
				    $categories = get_categories(array(
				      'orderby' => 'name',
				      'order'   => 'ASC'
				    ));
				    foreach ($categories as $category) {
				      echo '<option value="' . esc_attr($category->term_id) . '"';
				      if (isset($_GET['cat']) && $_GET['cat'] == $category->term_id) echo ' selected';
				      echo '>' . esc_html($category->name) . '</option>';
				    }
				    ?>
				  </select>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67"/>
</svg>
				</form>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</section>

<section class="album py-5 bg-light">
  <div class="container">
    <div class="row g-4">
    <?php
    $i = 1;
    if (have_posts()) :
      while (have_posts()) : the_post();
        // Determina la classe della colonna in base alla posizione
        if ($i == 1) {
          $col = 'col-lg-8 col-md-12 col-xs-12';
        } elseif ($i == 2 || $i == 3) {
          $col = 'col-lg-4 col-md-6 col-xs-12';
          // Apri il contenitore per i due articoli in col-4
          if ($i == 2) echo '<div id="column-2" class="col-lg-4 col-md-12 col-xs-12">';
        } elseif ($i == 4 || $i == 5) {
          $col = 'col-lg-6 col-md-6 col-xs-12';
        } else {
          $col = 'col-lg-4 col-md-6 col-xs-12';
        }
        // Output per i primi 5 articoli
        if ($i == 1 || $i == 4 || $i == 5 || $i > 5) {
      echo '<div class="' . $col . '">';
      ?>
      <div class="article-card"
        <?php
          if($i == 1) echo 'id="first-article"';
          if($i == 4 || $i == 5) echo ' id="col6-article"';
        ?>
        style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>');">
            <div class="article-overlay">
              <div class="article-category"<?php if($i > 1) echo ' style="font-weight:400;"'; ?>>
                <?php
                $category = get_the_category();
                if ($category) {
                  echo esc_html($category[0]->name);
                }
                ?>
              </div>
              <div class="article-title" <?php if($i == 1 || $i == 4 || $i == 5)  ?> >
                   <a href="<?php the_permalink(); ?>" style="text-decoration:none;"><?php the_title(); ?></a>
              </div>
              <div class="article-bottom">
                <span class="article-date">
                  <?php echo get_the_date('j F Y'); ?>
                </span>
                <a href="<?php the_permalink(); ?>" class="article-link"><?php _e( 'Leggi di più', 'pietre-rapolano' ); ?></a>
              </div>
            </div>
          </div>
          <?php
          echo '</div>';
        }
        // Output per articolo 2 e 3 (nella stessa col-4, uno sotto l'altro)
        if ($i == 2 || $i == 3) {
          ?>
          <div class="flex-fill" style="margin-bottom: 15px;">
            <div class="article-card" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>');">
              <div class="article-overlay">
                <div class="article-category" style="font-weight:400;">
                  <?php
                  $category = get_the_category();
                  if ($category) {
                    echo esc_html($category[0]->name);
                  }
                  ?>
                </div>
                <div class="article-title">
                   <a href="<?php the_permalink(); ?>" style="text-decoration:none;"><?php the_title(); ?></a>
                </div>
                <div class="article-bottom">
                  <span class="article-date">
                    <?php echo get_the_date('j F Y'); ?>
                  </span>
                  <a href="<?php the_permalink(); ?>" class="article-link"><?php _e( 'Leggi di più', 'pietre-rapolano' ); ?></a>
                </div>
              </div>
            </div>
          </div>
          <?php
          // Chiudi il contenitore dopo il terzo articolo
          if ($i == 3) echo '</div>';
        }
        $i++;
      endwhile;
    endif;
    ?>
  </div>

    <div class="row">
      <div class="col lead text-center w-100">
        <div class="d-inline-block"><?php picostrap_pagination() ?></div>
      </div><!-- /col -->
    </div> <!-- /row -->
  </div>
</section>
 <section id="cta-footer-contact" class="py-150">
    <!-- Overlay per l'effetto blur -->
    <div class="overlay"></div>
	<div class="container px-xl-3" style="position: relative; z-index: 2;"> <!-- Contenuto sopra l'overlay -->
		<div class="row">
			<div class="col-lg-12">
				<h3 class="text-center text-light"><?php _e( 'Contattaci per informazioni', 'pietre-rapolano' ); ?></h3>
				<p class="text-center text-light uppercase"><?php _e( 'o per richiedere un preventivo personalizzato', 'pietre-rapolano' ); ?></p>
				<div class="clearx2"></div>
				<?php echo (do_shortcode('[contact-form-7 id="5fbf157" title="Modulo di contatto CTA ITA"]')); ?>
			</div>
		</div>
	</div>

<?php get_footer();
